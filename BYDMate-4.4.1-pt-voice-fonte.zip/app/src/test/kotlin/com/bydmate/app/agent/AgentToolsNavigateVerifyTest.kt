package com.bydmate.app.agent

import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.DispatchResult
import com.bydmate.app.data.repository.PlaceRepository
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

/** Verifies the navigate foreground verification loop introduced by Fix A. */
class AgentToolsNavigateVerifyTest {

    private val dispatcher = mockk<ActionDispatcher>(relaxed = true)
    private val places = mockk<PlaceRepository>(relaxed = true)
    private val weather = mockk<WeatherClient>(relaxed = true)

    init {
        // A relaxed mock answers "" for String?, which would read as a pinned navigator.
        every { dispatcher.willOpenPinned(any()) } returns null
    }

    private fun tools() = agentTools(
        actionDispatcher = dispatcher,
        placeRepository = places,
        weatherClient = weather,
    )

    private fun call(name: String, args: String) = AgentToolCall("1", name, args)

    /** Dispatcher succeeds but the Navigator never surfaces: error must explain the situation. */
    @Test fun `navigate error when navigator never surfaces`() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { false }
            it.naviVerifyAttempts = 2
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.has("error"))
        assertTrue(out.getString("error").contains("не вышел на передний план"))
    }

    /** Seam returns false on the first poll, true on the second: dispatch must be reported ok. */
    @Test fun `navigate ok when navigator surfaces on second attempt`() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val callCount = AtomicInteger(0)
        val t = tools().also {
            it.naviForegroundCheck = { callCount.incrementAndGet() >= 2 }
            it.naviVerifyAttempts = 3
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.getBoolean("ok"))
    }

    /** When dispatch itself fails the foreground seam must never be invoked. */
    @Test fun `verification skipped when dispatch fails`() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "Нет приложения для обработки: x")
        val t = tools().also {
            it.naviForegroundCheck = { throw AssertionError("must not be called") }
            it.naviVerifyAttempts = 1
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.has("error"))
        assertFalse(out.has("ok"))
    }

    /** When home shortcut dispatch succeeds but Navigator never surfaces, the error must say
     *  "не вышел на передний план" rather than the generic "адрес не найден" fallback. */
    @Test fun `home shortcut failure reports foreground reason`() = runTest {
        coEvery { places.getAllSnapshot() } returns emptyList()
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { false }
            it.naviVerifyAttempts = 1
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"destination":"домой"}""")))
        assertTrue(out.has("error"))
        assertTrue(out.getString("error").contains("не вышел на передний план"))
        assertFalse(out.getString("error").contains("адрес не найден"))
    }

    /** #305: a route pinned to Waze is proven by Waze reaching the front, not the Navigator. */
    @Test fun `waze route waits for waze`() = runTest {
        every { dispatcher.willOpenPinned(any()) } returns "com.waze"
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { false }
            it.pinnedForegroundCheck = { _, pkg -> pkg == "com.waze" }
            it.naviVerifyAttempts = 2
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.toString(), out.optBoolean("ok"))
    }

    @Test fun `waze never surfacing names waze in the error`() = runTest {
        every { dispatcher.willOpenPinned(any()) } returns "com.waze"
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { true }
            it.pinnedForegroundCheck = { _, _ -> false }
            it.naviVerifyAttempts = 2
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.has("error"))
        assertTrue(out.getString("error"), out.getString("error").contains("Waze не вышел на передний план"))
    }

    /** #190: 2GIS had the same defect - the check now waits for its package as well. */
    @Test fun `2gis route waits for 2gis`() = runTest {
        every { dispatcher.willOpenPinned(any()) } returns "ru.dublgis.dgismobile"
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { false }
            it.pinnedForegroundCheck = { _, pkg -> pkg == "ru.dublgis.dgismobile" }
            it.naviVerifyAttempts = 2
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"lat":55.0,"lon":37.0}""")))
        assertTrue(out.toString(), out.optBoolean("ok"))
    }

    /** Home/Work always opens Yandex Navigator's own shortcut, so that is what the check waits for. */
    @Test fun `waze chosen home shortcut waits for the navigator`() = runTest {
        coEvery { places.getAllSnapshot() } returns emptyList()
        every { dispatcher.willOpenPinned(match { it.has("shortcut") }) } returns null
        every { dispatcher.willOpenPinned(match { !it.has("shortcut") }) } returns "com.waze"
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools().also {
            it.naviForegroundCheck = { true }
            it.pinnedForegroundCheck = { _, _ -> throw AssertionError("must wait for the Navigator") }
            it.naviVerifyAttempts = 1
            it.naviVerifyIntervalMs = 1L
        }
        val out = JSONObject(t.execute(call("navigate_to", """{"destination":"домой"}""")))
        assertTrue(out.toString(), out.optBoolean("ok"))
    }
}
