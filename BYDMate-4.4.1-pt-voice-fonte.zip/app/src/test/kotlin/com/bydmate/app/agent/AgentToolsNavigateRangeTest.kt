package com.bydmate.app.agent

import android.content.Context
import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.AutomationEngine
import com.bydmate.app.data.automation.DispatchResult
import com.bydmate.app.data.local.dao.ChargeDao
import com.bydmate.app.data.local.dao.RuleDao
import com.bydmate.app.data.local.dao.TripDao
import com.bydmate.app.data.remote.OpenRouterClient
import com.bydmate.app.data.repository.PlaceRepository
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.domain.battery.BatteryStateRepository
import com.bydmate.app.domain.calculator.RangeCalculator
import com.bydmate.app.voice.VoiceGate
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentToolsNavigateRangeTest {

    private val gate = mockk<VoiceGate>(relaxed = true)
    private val battery = mockk<BatteryStateRepository>(relaxed = true)
    private val range = mockk<RangeCalculator>(relaxed = true)
    private val tripDao = mockk<TripDao>(relaxed = true)
    private val chargeDao = mockk<ChargeDao>(relaxed = true)
    private val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        .also { io.mockk.every { it.willOpenPinned(any()) } returns null }
    private val ruleDao = mockk<RuleDao>(relaxed = true)
    private val engine = mockk<AutomationEngine>(relaxed = true)
    private val places = mockk<PlaceRepository>(relaxed = true)
    private val weather = mockk<WeatherClient>(relaxed = true)
    private val exa = mockk<ExaSearchClient>(relaxed = true)
    private val openRouterClient = mockk<OpenRouterClient>(relaxed = true)
    private val settingsRepository = mockk<SettingsRepository>(relaxed = true)
    private val contactLookup = mockk<ContactLookup>(relaxed = true)

    private val context = mockk<Context>(relaxed = true)

    private val tools = agentTools(
        gate = gate,
        batteryStateRepository = battery,
        rangeCalculator = range,
        tripDao = tripDao,
        chargeDao = chargeDao,
        actionDispatcher = dispatcher,
        ruleDao = ruleDao,
        automationEngine = engine,
        placeRepository = places,
        weatherClient = weather,
        exaSearchClient = exa,
        openRouterClient = openRouterClient,
        settingsRepository = settingsRepository,
        contactLookup = contactLookup,
        context = context,
    ).also {
        it.nowMs = { 1_000_000_000_000L }
        it.naviForegroundCheck = { true }
        it.naviVerifyAttempts = 1
        it.naviVerifyIntervalMs = 1L
    }

    private fun call(name: String, args: String) = AgentToolCall("1", name, args)

    @Test fun navigate_to_route_appends_range_assessment() = runTest {
        // car at 55.75,37.62 (Moscow); target ~Tver direction, straight ~150 km
        tools.locationProvider = { 55.75 to 37.62 }
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(soc = 80, totalElec = 1234.5)
        coEvery { range.estimate(80, 1234.5) } returns 320.0
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)

        val out = JSONObject(tools.execute(call("navigate_to",
            """{"destination":"точка","lat":57.0,"lon":36.0}""")))

        assertTrue(out.getBoolean("ok"))
        assertEquals("route", out.getString("mode"))
        assertTrue(out.has("distance_km"))
        assertEquals(320, out.getInt("range_km"))
        assertTrue(out.has("enough"))
        assertTrue(out.has("reserve_km"))
        // distance_km is straight-line × road factor, not the Navigator's routed distance —
        // the note keeps the LLM from voicing it as an exact figure (field report 2026-07-14)
        assertTrue(out.getString("note").contains("примерн"))
        assertTrue(out.getString("note").contains("get_route_info"))
    }

    @Test fun navigate_to_adds_charge_note_when_not_enough() = runTest {
        tools.locationProvider = { 55.75 to 37.62 }
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(soc = 20, totalElec = 1234.5)
        coEvery { range.estimate(20, 1234.5) } returns 60.0
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)

        val out = JSONObject(tools.execute(call("navigate_to",
            """{"destination":"точка","lat":57.0,"lon":36.0}""")))

        assertTrue(out.getBoolean("ok"))          // navigation itself is NOT blocked
        assertFalse(out.getBoolean("enough"))
        assertTrue(out.has("charge_note"))
    }

    @Test fun navigate_to_works_without_gps_or_snapshot() = runTest {
        tools.locationProvider = { null }
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)

        val out = JSONObject(tools.execute(call("navigate_to",
            """{"destination":"точка","lat":57.0,"lon":36.0}""")))

        assertTrue(out.getBoolean("ok"))
        assertFalse(out.has("distance_km"))
        assertFalse(out.has("charge_note"))
    }

    @Test fun `search_on_map dispatches navigate action with query payload`() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(success = true)
        val out = JSONObject(tools.execute(call("search_on_map",
            """{"query":"кофейня рядом"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("search", out.getString("mode"))
        coVerify { dispatcher.dispatch(match {
            it.kind == "navigate" && JSONObject(it.payload!!).getString("query") == "кофейня рядом"
        }, null) }
    }

    @Test fun `search_on_map without query returns error`() = runTest {
        val out = JSONObject(tools.execute(call("search_on_map", """{}""")))
        assertTrue(out.has("error"))
    }

}
