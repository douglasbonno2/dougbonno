package com.bydmate.app.hud

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.bydmate.app.data.vehicle.BatchReadItem
import com.bydmate.app.data.vehicle.HelperBootstrap
import com.bydmate.app.data.vehicle.HelperClient
import com.bydmate.app.data.vehicle.HudNaviReply
import com.bydmate.app.diagnostics.TraceRecorder
import com.bydmate.app.helper.HelperBinderProtocol
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import io.mockk.verifyOrder
import kotlin.random.Random
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.yield
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * The HUD check against a fake car and a fake gateway, on virtual time: step order and markers,
 * the log lines the check promises, the restore after a throw or a cancel, and the refusals.
 */
@RunWith(RobolectricTestRunner::class)
class HudCheckTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    @get:Rule val trace = TraceRecorder()

    @Before fun clear() {
        context.getSharedPreferences(HudController.PREFS_NAME, Context.MODE_PRIVATE).edit().clear().commit()
    }

    /** The car at rest with a W-HUD, HUD layout 1, no navigation. */
    private class FakeCar {
        val state = mutableMapOf(
            HudCheck.HUD_TYPE to 1, HudArming.NAVI to 4, HudArming.SCREEN to 1, HudArming.CLUSTER to 0,
            HudArming.CAN_NAVI to 0, HudArming.ISA to 0,
        )
        val calls = mutableListOf<String>()
        var bufferFailsOn: String? = null
        /** A write for which this is true comes back -1, refused. */
        var refuse: (String) -> Boolean = { false }
        /** Called right before each write goes on the timeline. */
        var beforeWrite: (String) -> Unit = {}
        val helper: HelperClient = mockk(relaxed = true)

        init {
            coEvery { helper.readBatch(any()) } answers {
                firstArg<List<BatchReadItem>>().map { 0 to (state[it.dev to it.fid] ?: 0) }
            }
            // yield() like the real client's IO hop: a cancelled caller cannot write.
            coEvery { helper.writeStatus(any(), any(), any(), any()) } coAnswers {
                yield()
                val call = "set ${arg<Int>(0)}/${arg<Int>(1)}=${arg<Int>(2)}"
                beforeWrite(call)
                calls += call
                if (refuse(call)) return@coAnswers -1
                state[arg<Int>(0) to arg<Int>(1)] = arg(2)
                1
            }
            coEvery { helper.writeBufferStatus(any(), any(), any()) } answers {
                val text = String(arg<ByteArray>(2), Charsets.UTF_16LE)
                calls += "buf ${arg<Int>(0)}/${arg<Int>(1)}=$text"
                check(text != bufferFailsOn) { "buffer write failed" }
                0
            }
            coEvery { helper.hudNaviStatus(any()) } coAnswers {
                yield()
                val status = firstArg<Int>()
                if (status != HelperBinderProtocol.HUD_NAVI_PROBE) {
                    calls += "sdk $status"
                    state[HudArming.NAVI] = status
                }
                HudNaviReply(HelperBinderProtocol.HUD_NAVI_CALLED, 0)
            }
        }
    }

    private fun gateway(): HudSomeIpBridge = mockk<HudSomeIpBridge>(relaxed = true).also {
        coEvery { it.bind() } returns true
        every { it.startService(any()) } returns 0
        every { it.fireEvent(any(), any()) } returns 0
    }

    private class Setup(
        val check: HudCheck,
        val car: FakeCar,
        val bridge: HudSomeIpBridge,
        val controller: HudController,
        val lines: MutableList<String>,
    )

    private fun setup(
        car: FakeCar = FakeCar(),
        controller: HudController? = null,
        guided: Boolean = false,
        speed: Int? = 0,
        gatewayPresent: Boolean = true,
    ): Setup {
        val bootstrap = mockk<HelperBootstrap>()
        coEvery { bootstrap.ensureRunning() } returns true
        val ctl = controller ?: HudController(context, car.helper, bootstrap)
        val bridge = gateway()
        val lines = mutableListOf<String>()
        val check = HudCheck(context, car.helper, bootstrap, ctl).apply {
            bridgeFactory = { bridge }
            this.gatewayPresent = { gatewayPresent }
            guidanceActive = { guided }
            speedKmh = { speed }
            fingerprint = "BYD/test:12"
            log = { lines += it }
        }
        return Setup(check, car, bridge, ctl, lines)
    }

    private fun Setup.probeLines() = lines.filter { it.startsWith("hudprobe:") }

    // --- a full run ---

    @Test fun `four steps draw their markers in order and the restore puts the car back`() = runTest {
        val s = setup()
        s.check.run()
        val probe = s.probeLines()
        assertEquals(
            "hudprobe: census fw=BYD/test:12 gateway=present sdk_navi=present hudType(951058453@1023)=1 " +
                "navi(1138753594@1007)=4 screen(1276174357@1023)=1 canNavi(1083203624@1014)=0 " +
                "isa(1262485592@1014)=0 cluster(1086337074@1007)=0",
            probe[0],
        )
        // 20 s of frames every 300 ms: 67 fires.
        assertEquals("hudprobe: step=1 chan=someip-ui7 armed=false start_rc=0 fire_rc={0:67} marker=111m", probe[1])
        assertEquals(
            "hudprobe: arm via=sdk navi rc=0 screen rc=1 canNavi rc=1 isa rc=1 readback navi=2 screen=3 canNavi=1 isa=1",
            probe[2],
        )
        assertEquals("hudprobe: step=2 chan=someip-ui7 armed=true start_rc=0 fire_rc={0:67} marker=222m", probe[3])
        assertEquals(
            "hudprobe: step=3 chan=can icon st=1/1 dist st=1 road st=0 readback icon=7 dist=333 marker=333m",
            probe[4],
        )
        // Step 4 must show its family alone: the CAN fields are blanked before it, not again after.
        assertEquals("hudprobe: can clear icon st=1/1 dist st=1 road st=0 readback icon=0 dist=0", probe[5])
        // 20 s of the LAUNCHER_MAP_CN set every 200 ms: 100 of each event.
        assertEquals("hudprobe: step=4 chan=someip-lmcn services=$LMCN_STARTED fire=$LMCN_FIRED marker=444m", probe[6])
        assertEquals("hudprobe: lmcn stop fire=$LMCN_STOP_FIRED services=$LMCN_STARTED", probe[7])
        assertEquals("hudprobe: restore navi rc=0 screen=1 rc=1 ok=true canNavi rc=1 isa rc=1 via=sdk readback navi=4 screen=1 canNavi=0 isa=0", probe[8])
        assertEquals(9, probe.size)

        // Step 1 wrote nothing; step 2 armed; step 3 wrote the CAN fields and blanked them before
        // step 4; the restore closed the status, put the layout back and cleared canNavi and isa.
        assertEquals(
            listOf("sdk 2", "set 1023/1276174357=3", "set 1014/1083203624=1", "set 1014/1262485592=1",
                "set 1007/1139806224=7", "set 1007/1139806256=7", "set 1007/1139806232=333", "buf 1007/1140461576=BYDMATE 3"),
            s.car.calls.take(8),
        )
        assertEquals(
            listOf("set 1007/1139806224=0", "set 1007/1139806256=0", "set 1007/1139806232=0", "buf 1007/1140461576= "),
            s.car.calls.drop(s.car.calls.lastIndexOf("buf 1007/1140461576=BYDMATE 3") + 1).take(4),
        )
        assertEquals(
            listOf("sdk 4", "set 1023/1276174357=1", "set 1014/1083203624=0", "set 1014/1262485592=0"),
            s.car.calls.takeLast(4),
        )
        assertEquals(1, s.car.calls.count { it == "buf 1007/1140461576= " })
        assertEquals(1, s.car.state[HudArming.SCREEN])
        assertEquals(4, s.car.state[HudArming.NAVI])
        verifyOrder {
            s.bridge.startService(HudSomeIpBridge.SERVICE_ID_NAVI)
            s.bridge.fireEvent(HudSomeIpBridge.TOPIC_NAVI, any())
            s.bridge.stopService(HudSomeIpBridge.SERVICE_ID_NAVI)
            s.bridge.unbind()
        }
        assertEquals(HudCheck.State.Done, s.check.state.value)
        assertFalse(s.controller.armingPaused)
    }

    @Test fun `the SOME IP steps carry their own distance and road`() = runTest {
        val frames = mutableListOf<ByteArray>()
        val s = setup()
        every { s.bridge.fireEvent(HudSomeIpBridge.TOPIC_NAVI, capture(frames)) } returns 0
        s.check.run()
        val step1 = HudProtobufBuilder.buildFrameSafe(2, 111, "BYDMATE 1", null, 0, 0, HudIconLoader.iconFor(2), null)
        val step2 = HudProtobufBuilder.buildFrameSafe(2, 222, "BYDMATE 2", null, 0, 0, HudIconLoader.iconFor(2), null)
        assertTrue(frames.take(67).all { it.contentEquals(step1) })
        assertTrue(frames.drop(67).take(67).all { it.contentEquals(step2) })
        // One clear frame before the CAN step, one in the restore.
        assertEquals(67 + 67 + 2, frames.size)
    }

    @Test fun `no gateway still runs the CAN step`() = runTest {
        val s = setup(gatewayPresent = false)
        s.check.run()
        val probe = s.probeLines()
        assertTrue(probe[0].contains("gateway=absent"))
        assertEquals("hudprobe: step=1 chan=someip-ui7 armed=false start_rc=absent fire_rc={} marker=111m", probe[1])
        assertTrue(probe[4].startsWith("hudprobe: step=3 chan=can "))
        verify(exactly = 0) { s.bridge.fireEvent(any(), any()) }
    }

    @Test fun `a bound projection lends its gateway and keeps its service`() = runTest {
        val car = FakeCar()
        val productBridge = gateway()
        val controller = mockk<HudController>(relaxed = true)
        every { controller.boundBridge } returns productBridge
        val s = setup(car = car, controller = controller)
        s.check.run()
        assertTrue(s.probeLines()[1].contains("start_rc=shared"))
        verify(atLeast = 1) { productBridge.fireEvent(HudSomeIpBridge.TOPIC_NAVI, any()) }
        verify(exactly = 0) { productBridge.stopService(HudSomeIpBridge.SERVICE_ID_NAVI) }
        // Step 4's services are the check's own on that binding, and it stops them again.
        HudLauncherMapCnFrames.SERVICE_IDS.forEach { id ->
            verifyOrder {
                productBridge.startService(id)
                productBridge.stopService(id)
            }
        }
        verify(exactly = 0) { productBridge.unbind() }
        verify(exactly = 0) { s.bridge.startService(any()) }
        // The product's arming stands aside for the check and comes back after it.
        verifyOrder {
            controller.armingPaused = true
            controller.armingPaused = false
        }
    }

    // --- step 4: the LAUNCHER_MAP_CN family ---

    /** A gateway that puts its calls on the car's timeline, so their order against the car's
     *  writes shows; fires are listed by topic only. */
    private fun Setup.timeline() {
        every { bridge.startService(any()) } answers { car.calls += "start 0x${firstArg<Long>().toString(16)}"; 0 }
        every { bridge.stopService(any()) } answers { car.calls += "stop 0x${firstArg<Long>().toString(16)}"; 0 }
        every { bridge.fireEvent(any(), any()) } answers {
            val topic = firstArg<Long>()
            if (topic != HudSomeIpBridge.TOPIC_NAVI) car.calls += "fire 0x${topic.toString(16)}"
            0
        }
    }

    @Test fun `step 4 starts the six services, sends the set every 200 ms and cleans up while the status is raised`() = runTest {
        val s = setup()
        s.timeline()
        s.check.run()
        val calls = s.car.calls
        // After step 3's CAN writes: the six services in OpenBYD's order, then the frames.
        val starts = calls.filter { it.startsWith("start ") }
        assertEquals(
            listOf("start 0xb010a00010000", "start 0xb000700070000", "start 0xb820282020000", "start 0xb000c000c0000",
                "start 0xb000d000d0000", "start 0xb000e000e0000", "start 0xb001700170000"),
            starts,
        )
        // The CAN fields are blank before the family's services start.
        assertTrue(calls.indexOf("start 0xb000700070000") > calls.indexOf("buf 1007/1140461576= "))
        assertEquals(1000, calls.count { it.startsWith("fire ") } - 3)
        // The restore: the off events and the six stops, then the status and layout.
        val stopAt = calls.indexOfLast { it == "fire 0x4001700178003" } + 1
        assertEquals(
            listOf("fire 0x4000d000d8001", "fire 0x4000d000d8005", "fire 0x4000e000e8001",
                "stop 0xb000700070000", "stop 0xb820282020000", "stop 0xb000c000c0000",
                "stop 0xb000d000d0000", "stop 0xb000e000e0000", "stop 0xb001700170000",
                "sdk 4", "set 1023/1276174357=1", "set 1014/1083203624=0", "set 1014/1262485592=0",
                "stop 0xb010a00010000"),
            calls.drop(stopAt),
        )
        assertEquals(HudCheck.State.Done, s.check.state.value)
    }

    @Test fun `step 4 frames are the ported set with a left turn, 444 m and one route id`() = runTest {
        val s = setup()
        val sent = mutableListOf<Pair<Long, ByteArray>>()
        every { s.bridge.fireEvent(any(), any()) } answers {
            if (firstArg<Long>() != HudSomeIpBridge.TOPIC_NAVI) sent += firstArg<Long>() to secondArg<ByteArray>()
            0
        }
        s.check.random = Random(7)
        s.check.nowMs = { 1_700_000_000_000L }
        s.check.run()
        val routeId = HudLauncherMapCnFrames.newRouteId(Random(7))
        val tick = { counter: Int ->
            HudLauncherMapCnFrames.update(1, 444, 15_000, 900, HudLauncherMapCnFrames.Position.DEFAULT, routeId, counter, 1_700_000_000_000L)
        }
        val expected = (0 until 100).flatMap { tick(it) } + HudLauncherMapCnFrames.stop(routeId, 1_700_000_000_000L)
        assertEquals(expected.map { it.topic }, sent.map { it.first })
        expected.zip(sent).forEach { (e, a) -> assertTrue(e.payload.contentEquals(a.second)) }
    }

    @Test fun `step 4 traces every service start and stop with its id and rc`() = runTest {
        val s = setup()
        every { s.bridge.startService(0xB820282020000L) } returns 11
        s.check.run()
        val services = trace.events().filter { it.contains("probe-service") }
        // The six of step 4 and the navigation service of steps 1 and 2, each started and stopped.
        assertEquals(14, services.size)
        assertTrue(services.any { it.contains("op=start") && it.contains("id=0xb010a00010000") && it.contains("rc=0") })
        assertTrue(services.any { it.contains("op=stop") && it.contains("id=0xb010a00010000") })
        assertTrue(services.any { it.contains("op=start") && it.contains("id=0xb820282020000") && it.contains("rc=11") })
        assertTrue(services.any { it.contains("op=stop") && it.contains("id=0xb001700170000") && it.contains("rc=0") })
        val step = trace.events().single { it.contains("probe-step") && it.contains("step=4") }
        listOf("chan=someip-lmcn", "started=5/6", "marker=444").forEach { assertTrue("$it in $step", step.contains(it)) }
        assertEquals(10, trace.events().count { it.contains("probe-fire") })
        assertTrue(s.probeLines().any { it.contains("services={0xb000700070000:0,0xb820282020000:11,") })
    }

    @Test fun `no gateway skips step 4`() = runTest {
        val s = setup(gatewayPresent = false)
        s.check.run()
        assertTrue(s.probeLines().contains("hudprobe: step=4 chan=someip-lmcn services=absent fire={} marker=444m"))
        verify(exactly = 0) { s.bridge.startService(any()) }
        verify(exactly = 0) { s.bridge.stopService(any()) }
        assertEquals(HudCheck.State.Done, s.check.state.value)
    }

    @Test fun `a check cancelled in step 4 still stops the six services and restores`() = runTest {
        val s = setup()
        s.timeline()
        val job = launch { s.check.run() }
        advanceTimeBy(70_000)   // inside step 4
        assertEquals(HudCheck.State.Step(4), s.check.state.value)
        job.cancel()
        job.join()
        HudLauncherMapCnFrames.SERVICE_IDS.forEach { verify { s.bridge.stopService(it) } }
        assertTrue(s.car.calls.containsAll(listOf("fire 0x4000d000d8001", "fire 0x4000d000d8005", "fire 0x4000e000e8001")))
        assertEquals("hudprobe: restore navi rc=0 screen=1 rc=1 ok=true canNavi rc=1 isa rc=1 via=sdk readback navi=4 screen=1 canNavi=0 isa=0", s.probeLines().last())
        assertEquals(4, s.car.state[HudArming.NAVI])
        assertEquals(1, s.car.state[HudArming.SCREEN])
        verify { s.bridge.unbind() }
        assertEquals(HudCheck.State.Done, s.check.state.value)
        assertFalse(s.controller.armingPaused)
    }

    @Test fun `moving off in step 4 stops the frames and the services and restores`() = runTest {
        val s = setup()
        s.timeline()
        s.check.speedKmh = { if (testScheduler.currentTime >= 70_000) 20 else 0 }
        val fireTimes = mutableListOf<Long>()
        every { s.bridge.fireEvent(any(), any()) } answers { fireTimes += testScheduler.currentTime; 0 }
        s.check.run()
        assertTrue(s.probeLines().contains("hudprobe: aborted reason=moving step=4"))
        // Past the look that saw the speed only the restore's off events and clear frame go out.
        assertTrue(fireTimes.count { it > 71_000 } <= 4)
        HudLauncherMapCnFrames.SERVICE_IDS.forEach { verify { s.bridge.stopService(it) } }
        assertEquals(4, s.car.state[HudArming.NAVI])
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.MOVING), s.check.state.value)
    }

    @Test fun `a route starting in step 4 with the product live stops the six services and leaves the status`() = runTest {
        val product = LiveProduct()
        every { product.bridge.startService(any()) } returns 0
        val s = setup(controller = product.controller)
        routeStartsAt(70_000, s)
        s.check.run()
        assertHandedOver(s, product, step = 4)
        HudLauncherMapCnFrames.SERVICE_IDS.forEach { verify { product.bridge.stopService(it) } }
        verify(exactly = 0) { product.bridge.stopService(HudSomeIpBridge.SERVICE_ID_NAVI) }
        assertEquals(
            listOf("set 1007/1139806224=0", "set 1007/1139806256=0", "set 1007/1139806232=0", "buf 1007/1140461576= "),
            s.car.calls.takeLast(4),
        )
    }

    // --- the restore always runs ---

    @Test fun `a step that throws still restores`() = runTest {
        val car = FakeCar().apply { bufferFailsOn = "BYDMATE 3" }
        val s = setup(car = car)
        s.check.run()
        val probe = s.probeLines()
        assertTrue(probe.contains("hudprobe: aborted IllegalStateException"))
        assertEquals("hudprobe: restore navi rc=0 screen=1 rc=1 ok=true canNavi rc=1 isa rc=1 via=sdk readback navi=4 screen=1 canNavi=0 isa=0", probe.last())
        assertEquals(1, car.state[HudArming.SCREEN])
        assertEquals(4, car.state[HudArming.NAVI])
        assertEquals(0, car.state[HudArming.CAN_NAVI])
        assertEquals(0, car.state[HudArming.ISA])
        verify { s.bridge.unbind() }
        assertEquals(HudCheck.State.Done, s.check.state.value)
        assertFalse(s.controller.armingPaused)
    }

    @Test fun `a cancelled check still restores`() = runTest {
        val s = setup()
        val job = launch { s.check.run() }
        advanceTimeBy(30_000)   // inside step 2, armed
        assertEquals(HudCheck.State.Step(2), s.check.state.value)
        job.cancel()
        job.join()
        assertEquals("hudprobe: restore navi rc=0 screen=1 rc=1 ok=true canNavi rc=1 isa rc=1 via=sdk readback navi=4 screen=1 canNavi=0 isa=0", s.probeLines().last())
        assertEquals(1, s.car.state[HudArming.SCREEN])
        verify { s.bridge.stopService(HudSomeIpBridge.SERVICE_ID_NAVI) }
        verify { s.bridge.unbind() }
        assertEquals(HudCheck.State.Done, s.check.state.value)
        assertFalse(s.controller.armingPaused)
    }

    @Test fun `cancelled before arming restores nothing it did not write`() = runTest {
        val s = setup()
        val job = launch { s.check.run() }
        advanceTimeBy(5_000)   // inside step 1
        job.cancel()
        job.join()
        assertEquals("hudprobe: restore navi rc=skipped screen=na rc=skipped ok=true", s.probeLines().last())
        assertTrue(s.car.calls.isEmpty())
    }

    private fun canClearEvents() = trace.events().filter { it.contains("probe-can-clear") }

    @Test fun `the CAN clear before step 4 is traced with its statuses`() = runTest {
        val s = setup()
        s.check.run()
        val events = canClearEvents()
        assertEquals(1, events.size)
        val line = events.single()
        listOf("icon=1", "ahead=1", "dist=1", "road=0", "rb-icon=", "rb-dist=").forEach { assertTrue("$it in $line", line.contains(it)) }
        assertFalse(line.contains("ok=false"))
    }

    @Test fun `a CAN clear that throws is traced, step 4 still runs and the restore tries it again`() = runTest {
        val car = FakeCar().apply { bufferFailsOn = " " }
        val s = setup(car = car)
        s.check.run()
        val events = canClearEvents()
        assertEquals(2, events.size)
        events.forEach { line -> assertTrue(line, line.contains("error=IllegalStateException") && line.contains("ok=false")) }
        assertTrue(s.probeLines().any { it.startsWith("hudprobe: step=4 chan=someip-lmcn services={") })
        assertTrue(s.probeLines().contains("hudprobe: can clear failed IllegalStateException"))
        assertEquals(4, car.state[HudArming.NAVI])
        assertEquals(HudCheck.State.Done, s.check.state.value)
    }

    @Test fun `a refused CAN clear before step 4 is repeated in the restore, before the family stops and the disarm`() = runTest {
        val car = FakeCar()
        var refusals = 1
        car.refuse = { it == "set 1007/1139806232=0" && refusals-- > 0 }
        val s = setup(car = car)
        s.timeline()
        s.check.run()
        val calls = car.calls
        assertEquals(2, calls.count { it == "set 1007/1139806232=0" })
        assertTrue(s.probeLines().any { it.startsWith("hudprobe: can clear") && it.endsWith(" ok=false") })
        val restoreClear = calls.lastIndexOf("buf 1007/1140461576= ")
        assertTrue(calls.toString(), restoreClear > calls.indexOf("start 0xb000700070000"))
        assertTrue(calls.toString(), restoreClear < calls.indexOf("stop 0xb000700070000"))
        assertTrue(calls.indexOf("stop 0xb001700170000") < calls.indexOf("sdk 4"))
        assertFalse(prefs().contains(HudWayChannels.KEY_CAN_LEFT))
        assertEquals(HudCheck.State.Done, s.check.state.value)
    }

    @Test fun `a CAN clear the car keeps refusing leaves its marker for the next start`() = runTest {
        val car = FakeCar().apply { refuse = { it == "set 1007/1139806232=0" } }
        val s = setup(car = car)
        s.check.run()
        assertEquals(2, car.calls.count { it == "set 1007/1139806232=0" })
        assertTrue(prefs().getBoolean(HudWayChannels.KEY_CAN_LEFT, false))
        assertEquals(4, car.state[HudArming.NAVI])
    }

    // --- what a process death mid-check would leave ---

    @Test fun `step 3 keeps its CAN marker on disk before its first write, the accepted clear drops it`() = runTest {
        val car = FakeCar()
        val kept = mutableListOf<Boolean>()
        car.beforeWrite = { if (it == "set 1007/1139806224=7") kept += prefs().contains(HudWayChannels.KEY_CAN_LEFT) }
        val s = setup(car = car)
        val job = launch { s.check.run() }
        advanceTimeBy(50_000)   // inside step 3
        assertEquals(HudCheck.State.Step(3), s.check.state.value)
        assertTrue(prefs().getBoolean(HudWayChannels.KEY_CAN_LEFT, false))
        job.join()
        assertTrue(kept.isNotEmpty() && kept.all { it })
        assertFalse(prefs().contains(HudWayChannels.KEY_CAN_LEFT))
    }

    @Test fun `step 4 keeps the family marker with its route id before the first start, the answered stops drop it`() = runTest {
        val s = setup()
        s.check.random = Random(7)
        val kept = mutableListOf<Long?>()
        every { s.bridge.startService(any()) } answers {
            val id = firstArg<Long>()
            if (id != HudSomeIpBridge.SERVICE_ID_NAVI) {
                kept += prefs().takeIf { it.contains(HudWayChannels.KEY_LMCN_LEFT) }?.getLong(HudWayChannels.KEY_LMCN_LEFT, 0L)
            }
            0
        }
        val job = launch { s.check.run() }
        advanceTimeBy(70_000)   // inside step 4
        assertEquals(HudCheck.State.Step(4), s.check.state.value)
        assertFalse(prefs().contains(HudWayChannels.KEY_CAN_LEFT))
        job.join()
        assertEquals(List(6) { HudLauncherMapCnFrames.newRouteId(Random(7)) }, kept)
        assertFalse(prefs().contains(HudWayChannels.KEY_LMCN_LEFT))
    }

    @Test fun `a family off event that threw leaves the family marker for the next start`() = runTest {
        val s = setup()
        every { s.bridge.fireEvent(0x4000d000d8005L, any()) } returns -2
        s.check.run()
        HudLauncherMapCnFrames.SERVICE_IDS.forEach { verify { s.bridge.stopService(it) } }
        assertTrue(prefs().contains(HudWayChannels.KEY_LMCN_LEFT))
    }

    @Test fun `a family stop that threw leaves the family marker for the next start`() = runTest {
        val s = setup()
        every { s.bridge.stopService(HudLauncherMapCnFrames.SERVICE_IDS.last()) } returns -2
        s.check.run()
        assertTrue(prefs().contains(HudWayChannels.KEY_LMCN_LEFT))
    }

    @Test fun `a check that never reached step 3 traces no CAN clear`() = runTest {
        val s = setup()
        val job = launch { s.check.run() }
        advanceTimeBy(5_000)   // inside step 1
        job.cancel()
        job.join()
        assertTrue(canClearEvents().isEmpty())
    }

    // --- a route that starts during the check ---

    /** A projection running with its arming: the check shares its gateway. */
    private class LiveProduct {
        val bridge: HudSomeIpBridge = mockk(relaxed = true)
        val frames = mutableListOf<ByteArray>()
        val controller: HudController = mockk(relaxed = true)

        init {
            every { bridge.fireEvent(any(), capture(frames)) } returns 0
            every { controller.boundBridge } returns bridge
            every { controller.armingLive } returns true
        }

        fun clearFrames() = frames.count { it.contentEquals(HudProtobufBuilder.buildClearFrame(0)) }
    }

    private fun TestScope.routeStartsAt(ms: Long, s: Setup) {
        s.check.guidanceActive = { testScheduler.currentTime >= ms }
    }

    /** What every hand-over leaves: no restore clear frame, no disarm, the pause lifted. */
    private fun assertHandedOver(s: Setup, product: LiveProduct, step: Int) {
        val probe = s.probeLines()
        assertTrue(probe.contains("hudprobe: aborted reason=guidance step=$step"))
        assertTrue(s.car.calls.none { it == "sdk 4" || (it.startsWith("set 1023/") && !it.endsWith("=3")) })
        assertTrue(s.car.calls.none { it == "set 1014/1083203624=0" || it == "set 1014/1262485592=0" })
        assertEquals(HudCheck.State.RouteStarted, s.check.state.value)
        verifyOrder {
            product.controller.armingPaused = true
            product.controller.armingPaused = false
        }
    }

    @Test fun `a route starting in step 1 ends the check and leaves nothing to undo`() = runTest {
        val product = LiveProduct()
        val s = setup(controller = product.controller)
        routeStartsAt(5_000, s)
        s.check.run()
        assertHandedOver(s, product, step = 1)
        assertEquals(0, product.clearFrames())
        assertTrue(product.frames.size <= 5_000 / 300 + 1)   // no test frame after the route came
        assertTrue(s.car.calls.isEmpty())
        assertFalse(prefs().contains(HudArming.KEY_AS_FOUND))
    }

    @Test fun `a route starting in step 2 leaves the armed status and the kept layout to the projection`() = runTest {
        val product = LiveProduct()
        val times = mutableListOf<Long>()
        every { product.bridge.fireEvent(any(), any()) } answers {
            product.frames += secondArg<ByteArray>(); times += testScheduler.currentTime; 0
        }
        val s = setup(controller = product.controller)
        routeStartsAt(25_000, s)
        s.check.run()
        assertHandedOver(s, product, step = 2)
        assertTrue(times.count { it >= 25_000 } <= 1)   // no test frame after the route, one in flight at most
        assertEquals(0, product.clearFrames())
        assertEquals("hudprobe: restore handover armed=true asfound=1", s.probeLines().last())
        assertEquals(1, prefs().getInt(HudArming.KEY_AS_FOUND, -1))
        assertEquals(3, s.car.state[HudArming.SCREEN])
        assertEquals(2, s.car.state[HudArming.NAVI])
    }

    @Test fun `a route starting in step 3 blanks the CAN fields and nothing else`() = runTest {
        val product = LiveProduct()
        val s = setup(controller = product.controller)
        routeStartsAt(45_000, s)
        s.check.run()
        assertHandedOver(s, product, step = 3)
        assertEquals(1, product.clearFrames())   // the one before the CAN step, none in the restore
        assertEquals(
            listOf("set 1007/1139806224=0", "set 1007/1139806256=0", "set 1007/1139806232=0", "buf 1007/1140461576= "),
            s.car.calls.takeLast(4),
        )
        assertEquals(1, prefs().getInt(HudArming.KEY_AS_FOUND, -1))
    }

    @Test fun `without a running projection a route start still gets the full restore`() = runTest {
        val s = setup()   // HUD projection off: nobody else would close the status
        val times = mutableListOf<Long>()
        every { s.bridge.fireEvent(any(), any()) } answers { times += testScheduler.currentTime; 0 }
        routeStartsAt(25_000, s)
        s.check.run()
        assertTrue(times.count { it >= 25_000 } <= 1)   // past the route only the restore's clear frame
        assertTrue(s.probeLines().contains("hudprobe: aborted reason=guidance step=2"))
        assertEquals(
            listOf("sdk 4", "set 1023/1276174357=1", "set 1014/1083203624=0", "set 1014/1262485592=0"),
            s.car.calls.takeLast(4),
        )
        verify { s.bridge.fireEvent(HudSomeIpBridge.TOPIC_NAVI, match { it.contentEquals(HudProtobufBuilder.buildClearFrame(0)) }) }
        verify { s.bridge.unbind() }
        assertEquals(HudCheck.State.RouteStarted, s.check.state.value)
        assertFalse(s.controller.armingPaused)
        assertFalse(prefs().contains(HudArming.KEY_AS_FOUND))
    }

    private fun prefs() = context.getSharedPreferences(HudController.PREFS_NAME, Context.MODE_PRIVATE)

    // --- the notice a check that did not run through leaves, once ---

    @Test fun `a refusal leaves one notice, and a dismissed one stays gone while the state stays refused`() = runTest {
        val s = setup(guided = true)
        assertEquals(null, s.check.notice.value)
        s.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.GUIDANCE), s.check.notice.value)
        s.check.dismissNotice()
        // The state keeps the hint line; read again, it is no new notice.
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.GUIDANCE), s.check.state.value)
        assertEquals(null, s.check.notice.value)
    }

    @Test fun `every refused tap is a new notice, the same reason included`() = runTest {
        val s = setup(speed = 6)
        repeat(3) {
            s.check.run()
            assertEquals(HudCheck.State.Refused(HudCheck.Refusal.MOVING), s.check.notice.value)
            s.check.dismissNotice()
        }
    }

    @Test fun `no link, a route mid-check and moving off mid-check each leave their notice`() = runTest {
        val noLink = setup(speed = null)
        noLink.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.NO_LINK), noLink.check.notice.value)
        val route = setup()
        routeStartsAt(25_000, route)
        route.check.run()
        assertEquals(HudCheck.State.RouteStarted, route.check.notice.value)
        val moving = setup()
        moving.check.speedKmh = { if (testScheduler.currentTime >= 30_000) 20 else 0 }
        moving.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.MOVING), moving.check.notice.value)
    }

    @Test fun `a check that ran through leaves no notice, and a new check drops an old one`() = runTest {
        val s = setup(guided = true)
        s.check.run()
        s.check.guidanceActive = { false }
        s.check.run()
        assertEquals(HudCheck.State.Done, s.check.state.value)
        assertEquals(null, s.check.notice.value)
    }

    // --- the question at the end ---

    @Test fun `a check that ran to the end asks which number the glass showed`() = runTest {
        val s = setup()
        assertFalse(s.check.askAnswer.value)
        s.check.run()
        assertTrue(s.check.askAnswer.value)
    }

    @Test fun `a check without a gateway still asks`() = runTest {
        val s = setup(gatewayPresent = false)
        s.check.run()
        assertTrue(s.check.askAnswer.value)
    }

    @Test fun `the number seen picks the way`() = runTest {
        val s = setup()
        listOf(111 to 1, 222 to 2, 333 to 2, 444 to 3).forEach { (seen, way) ->
            s.check.run()
            assertEquals(way, s.check.answer(seen))
            assertEquals(way, s.controller.mode())
            assertFalse(s.check.askAnswer.value)
            assertTrue(trace.events().any { it.contains("probe-answer") && it.contains("seen=$seen") && it.contains("way=$way") })
        }
    }

    @Test fun `nothing seen keeps the way and says so in the trace`() = runTest {
        val s = setup()
        s.controller.setMode(HudController.MODE_NAVI_STATUS)
        s.check.run()
        assertEquals(null, s.check.answer(null))
        assertEquals(HudController.MODE_NAVI_STATUS, s.controller.mode())
        assertFalse(s.check.askAnswer.value)
        assertTrue(trace.events().any { it.contains("probe-answer") && it.contains("seen=none") && it.contains("way=2") })
    }

    @Test fun `a check that did not run to the end does not ask`() = runTest {
        // Times are relative: the cases share one virtual clock.
        val cases = listOf<Pair<String, suspend TestScope.() -> HudCheck>>(
            "refused" to { setup(speed = 6).check.also { it.run() } },
            "cancelled in step 4" to {
                val s = setup()
                val job = launch { s.check.run() }
                advanceTimeBy(70_000)   // inside step 4
                job.cancel()
                job.join()
                assertEquals("cancelled in step 4", HudCheck.State.Done, s.check.state.value)
                s.check
            },
            "a route mid-check" to {
                val s = setup()
                routeStartsAt(testScheduler.currentTime + 25_000, s)
                s.check.also { it.run() }
            },
            "moving off mid-check" to {
                val s = setup()
                val t0 = testScheduler.currentTime
                s.check.speedKmh = { if (testScheduler.currentTime - t0 >= 30_000) 20 else 0 }
                s.check.also { it.run() }
            },
            "a step threw" to { setup(car = FakeCar().apply { bufferFailsOn = "BYDMATE 3" }).check.also { it.run() } },
            "a new check drops an unanswered question" to {
                val s = setup()
                s.check.run()
                assertTrue("first check asks", s.check.askAnswer.value)
                s.check.speedKmh = { 6 }
                s.check.also { it.run() }
            },
        )
        cases.forEach { (label, run) -> assertFalse("case: $label", run().askAnswer.value) }
    }

    // --- refusals ---

    @Test fun `a refused check starts no service`() = runTest {
        val s = setup(speed = 6)
        s.check.run()
        verify(exactly = 0) { s.bridge.startService(any()) }
    }

    @Test fun `refuses during real guidance`() = runTest {
        val s = setup(guided = true)
        s.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.GUIDANCE), s.check.state.value)
        assertEquals(listOf("hudprobe: refused reason=guidance"), s.probeLines())
        assertNothingTouched(s)
    }

    @Test fun `refuses above 5 km per hour`() = runTest {
        val s = setup(speed = 6)
        s.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.MOVING), s.check.state.value)
        assertEquals(listOf("hudprobe: refused reason=moving"), s.probeLines())
        assertNothingTouched(s)
    }

    @Test fun `5 km per hour is still standing`() = runTest {
        val s = setup(speed = 5)
        s.check.run()
        assertEquals(HudCheck.State.Done, s.check.state.value)
    }

    @Test fun `refuses when the speed is unknown`() = runTest {
        val s = setup(speed = null)
        s.check.run()
        assertEquals(HudCheck.State.Refused(HudCheck.Refusal.NO_LINK), s.check.state.value)
        assertEquals(listOf("hudprobe: refused reason=no_link"), s.probeLines())
        assertNothingTouched(s)
    }

    private companion object {
        const val LMCN_STARTED = "{0xb000700070000:0,0xb820282020000:0,0xb000c000c0000:0,0xb000d000d0000:0," +
            "0xb000e000e0000:0,0xb001700170000:0}"
        const val LMCN_FIRED = "{0x4000700078001:{0:100},0x482028202800b:{0:100},0x4000700078003:{0:100}," +
            "0x4000c000c8001:{0:100},0x4000c000c8003:{0:100},0x4000d000d8001:{0:100},0x4000d000d8002:{0:100}," +
            "0x4000d000d8005:{0:100},0x4000e000e8001:{0:100},0x4001700178003:{0:100}}"
        const val LMCN_STOP_FIRED = "{0x4000d000d8001:{0:1},0x4000d000d8005:{0:1},0x4000e000e8001:{0:1}}"
    }

    private fun assertNothingTouched(s: Setup) {
        coVerify(exactly = 0) { s.car.helper.writeStatus(any(), any(), any(), any()) }
        coVerify(exactly = 0) { s.car.helper.hudNaviStatus(any()) }
        coVerify(exactly = 0) { s.car.helper.writeBufferStatus(any(), any(), any()) }
        verify(exactly = 0) { s.bridge.fireEvent(any(), any()) }
        assertFalse(s.controller.armingPaused)
    }
}
