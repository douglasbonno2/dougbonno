package com.bydmate.app.agent

import android.content.Context
import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.AutomationEngine
import com.bydmate.app.data.automation.DispatchResult
import com.bydmate.app.data.automation.VoiceFireResult
import com.bydmate.app.data.local.dao.ChargeDao
import com.bydmate.app.data.local.dao.RuleDao
import com.bydmate.app.data.local.dao.TripDao
import com.bydmate.app.data.local.entity.ActionDef
import com.bydmate.app.data.local.entity.RuleEntity
import com.bydmate.app.data.repository.PlaceRepository
import com.bydmate.app.data.remote.OpenRouterClient
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.domain.battery.BatteryStateRepository
import com.bydmate.app.domain.calculator.RangeCalculator
import com.bydmate.app.voice.VoiceGate
import io.mockk.clearMocks
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentToolsControlTest {

    private val gate = mockk<VoiceGate>()
    private val battery = mockk<BatteryStateRepository>()
    private val range = mockk<RangeCalculator>()
    private val tripDao = mockk<TripDao>()
    private val chargeDao = mockk<ChargeDao>()
    private val dispatcher = mockk<ActionDispatcher>()
    private val ruleDao = mockk<RuleDao>()
    private val engine = mockk<AutomationEngine>()
    private val places = mockk<PlaceRepository>()
    private val weather = mockk<WeatherClient>()
    private val exa = mockk<ExaSearchClient>()
    private val openRouterClient = mockk<OpenRouterClient>()
    private val settingsRepository = mockk<SettingsRepository>()
    private val contactLookup = mockk<ContactLookup>()

    private val context = mockk<Context>(relaxed = true)

    private fun tools() = agentTools(
        gate = gate,
        batteryStateRepository = battery,
        rangeCalculator = range,
        tripDao = tripDao,
        chargeDao = chargeDao,
        actionDispatcher = dispatcher,
        ruleDao = ruleDao,
        automationEngine = engine,
        placeRepository = places,
        weatherClient = weather,
        exaSearchClient = exa,
        openRouterClient = openRouterClient,
        settingsRepository = settingsRepository,
        contactLookup = contactLookup,
        context = context,
    )

    private fun call(name: String, args: String) = AgentToolCall("1", name, args)

    // SAFETY: null snapshot + window-open command must never reach the dispatcher.
    @Test fun window_open_with_null_snapshot_fails_closed() = runTest {
        every { gate.vehicleSnapshot() } returns null
        val out = JSONObject(tools().execute(
            call("vehicle_control", """{"command":"车窗全开"}""")))
        assertTrue(out.has("error"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    @Test fun non_window_command_with_null_snapshot_dispatches() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            call("vehicle_control", """{"command":"关闭空调"}""")))
        assertTrue(out.getBoolean("ok"))
    }

    @Test fun dispatcher_block_reason_propagates() = runTest {
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(speed = 100)
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "Заблокировано: скорость выше 80 км/ч")
        val out = JSONObject(tools().execute(
            call("vehicle_control", """{"command":"车窗全开"}""")))
        assertEquals("Заблокировано: скорость выше 80 км/ч", out.getString("error"))
    }

    @Test fun vehicle_control_dispatches_kind_param() = runTest {
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(speed = 0)
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        tools().execute(call("vehicle_control", """{"command":"设置温度22"}"""))
        coVerify { dispatcher.dispatch(match { it.kind == "param" && it.command == "设置温度22" }, any()) }
    }

    @Test fun media_volume_passes_op_as_payload() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        tools().execute(call("media_volume", """{"op":"+2"}"""))
        coVerify { dispatcher.dispatch(match { it.kind == "media_volume" && it.payload == "+2" }, null) }
    }

    @Test fun run_automation_matches_name_case_insensitive() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { ruleDao.getEnabled() } returns listOf(
            RuleEntity(id = 7, name = "Проветрить", triggers = "[]", actions = "[]"))
        coEvery { engine.fireVoiceRule(7, null) } returns VoiceFireResult.Fired
        val out = JSONObject(tools().execute(
            call("run_automation", """{"name":"проветрить"}""")))
        assertTrue(out.getBoolean("ok"))
    }

    @Test fun run_automation_park_required_maps_to_error() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { ruleDao.getEnabled() } returns listOf(
            RuleEntity(id = 7, name = "Фрунк", triggers = "[]", actions = "[]"))
        coEvery { engine.fireVoiceRule(7, null) } returns VoiceFireResult.ParkRequired
        val out = JSONObject(tools().execute(
            call("run_automation", """{"name":"Фрунк"}""")))
        assertTrue(out.has("error"))
    }

    @Test fun run_automation_unknown_name_reports_error() = runTest {
        coEvery { ruleDao.getEnabled() } returns emptyList()
        val out = JSONObject(tools().execute(
            call("run_automation", """{"name":"нет такой"}""")))
        assertTrue(out.has("error"))
        coVerify(exactly = 0) { engine.fireVoiceRule(any(), any()) }
    }

    @Test fun vehicle_control_schema_has_readable_enum_no_chinese() = runTest {
        coEvery { ruleDao.getEnabled() } returns emptyList()
        coEvery { settingsRepository.getString(SettingsRepository.KEY_EXA_API_KEY, "") } returns "exa-key"
        val arr = tools().schemas()
        var found = false
        for (i in 0 until arr.length()) {
            val fn = arr.getJSONObject(i).getJSONObject("function")
            if (fn.getString("name") == "vehicle_control") {
                val commandProp = fn.getJSONObject("parameters").getJSONObject("properties").getJSONObject("command")
                val enum = commandProp.getJSONArray("enum")
                val ids = (0 until enum.length()).map { enum.getString(it) }
                assertTrue(ids.contains("windows_close_all"))
                assertTrue(ids.none { it.contains("车窗") })
                assertTrue(!fn.getString("description").contains("车窗"))
                found = true
            }
        }
        assertTrue(found)
    }

    @Test fun vehicle_control_dispatches_readable_id() = runTest {
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(speed = 0)
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        tools().execute(call("vehicle_control", """{"command":"windows_close_all"}"""))
        coVerify { dispatcher.dispatch(match { it.kind == "param" && it.command == "车窗关闭" }, any()) }
    }

    @Test fun vehicle_control_unknown_command_reports_russian_error_no_chinese() = runTest {
        every { gate.vehicleSnapshot() } returns null
        val out = JSONObject(tools().execute(
            call("vehicle_control", """{"command":"nonsense_command"}""")))
        val error = out.getString("error")
        assertTrue(error.contains("nonsense_command"))
        assertTrue(!error.any { it.code > 0x2E80 })
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    @Test fun vehicle_control_raw_chinese_still_dispatches_for_compat() = runTest {
        every { gate.vehicleSnapshot() } returns AgentToolsReadTest.snapshot(speed = 0)
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            call("vehicle_control", """{"command":"车窗关闭"}""")))
        assertTrue(out.getBoolean("ok"))
        coVerify { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) }
    }

    // --- П7 origin-based defense: confirm gate for dangerous agent actions ---

    @Test fun vehicle_control_unlock_is_dangerous_and_confirms() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools()
        t.confirmScope = CoroutineScope(Dispatchers.Unconfined)
        var gateInvoked = false
        t.confirmGate = { _, _, _, onConfirm, _ -> gateInvoked = true; onConfirm(); true }
        val out = JSONObject(t.execute(call("vehicle_control", """{"command":"车门解锁"}""")))
        assertTrue(gateInvoked)
        assertEquals("ожидает подтверждения на экране", out.getString("status"))
        coVerify { dispatcher.dispatch(match { it.command.contains("车门解锁") }, any()) }
    }

    @Test fun vehicle_control_close_window_is_not_dangerous_dispatches_directly() = runTest {
        every { gate.vehicleSnapshot() } returns null
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools()
        var gateInvoked = false
        t.confirmGate = { _, _, _, _, _ -> gateInvoked = true; true }
        val out = JSONObject(t.execute(call("vehicle_control", """{"command":"车窗关闭"}""")))
        assertTrue(out.getBoolean("ok"))
        assertFalse(gateInvoked)
        coVerify(exactly = 1) { dispatcher.dispatch(any(), any()) }
    }

    @Test fun vehicle_control_unlock_fail_closed_when_overlay_cannot_show() = runTest {
        every { gate.vehicleSnapshot() } returns null
        val t = tools()
        t.confirmGate = { _, _, _, _, _ -> false }
        val out = JSONObject(t.execute(call("vehicle_control", """{"command":"车门解锁"}""")))
        assertFalse(out.getBoolean("ok"))
        assertTrue(out.has("error"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // T9 IMPORTANT-1: confirm-gate must dispatch against LIVE data, not the stale snapshot
    // captured at tool-call time. gate.vehicleSnapshot() returns a non-null standstill snapshot
    // (stale); TrackingService.lastData.value is null in unit tests (no public setter —
    // see AutomationEngineButtonPressTest.kt:110). After the fix, onConfirm dispatches via
    // TrackingService.lastData.value (null), NOT the non-null stale snapshot.
    @Test fun vehicle_control_unlock_dispatches_live_data_not_stale_snapshot_at_confirm_time() = runTest {
        val staleSnapshot = AgentToolsReadTest.snapshot(speed = 0)
        every { gate.vehicleSnapshot() } returns staleSnapshot
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools()
        t.confirmScope = CoroutineScope(Dispatchers.Unconfined)
        t.confirmGate = { _, _, _, onConfirm, _ -> onConfirm(); true }
        t.execute(call("vehicle_control", """{"command":"车门解锁"}"""))
        // Live data (null) must reach the dispatcher, not the non-null staleSnapshot.
        coVerify { dispatcher.dispatch(any(), null) }
    }

    // --- set_sentry ---

    @Test fun set_sentry_on_false_is_dangerous_and_confirms() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
        val t = tools()
        t.confirmScope = CoroutineScope(Dispatchers.Unconfined)
        var gateInvoked = false
        t.confirmGate = { _, _, _, onConfirm, _ -> gateInvoked = true; onConfirm(); true }
        val out = JSONObject(t.execute(call("set_sentry", """{"on":false}""")))
        assertTrue(gateInvoked)
        assertEquals("ожидает подтверждения на экране", out.getString("status"))
        coVerify { dispatcher.dispatch(match { it.kind == "sentry" && it.payload == "0" }, null) }
    }

    @Test fun set_sentry_on_false_fail_closed_when_overlay_cannot_show() = runTest {
        val t = tools()
        t.confirmGate = { _, _, _, _, _ -> false }
        val out = JSONObject(t.execute(call("set_sentry", """{"on":false}""")))
        assertFalse(out.getBoolean("ok"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // --- set_sentry / set_hotspot / set_screen (#275): on=true/false dispatches the payload, a missing "on" never dispatches ---

    private class OnOffCase(val label: String, val tool: String, val args: String, val payload: String?)

    @Test fun set_sentry_hotspot_screen_dispatch_payload_or_refuse_without_on() = runTest {
        val cases = listOf(
            OnOffCase("sentry on", "set_sentry", """{"on":true}""", "1"),
            OnOffCase("sentry without on", "set_sentry", """{}""", null),
            OnOffCase("hotspot on", "set_hotspot", """{"on":true}""", "1"),
            OnOffCase("hotspot off", "set_hotspot", """{"on":false}""", "0"),
            OnOffCase("hotspot without on", "set_hotspot", """{}""", null),
            OnOffCase("screen off", "set_screen", """{"on":false}""", "0"),
            OnOffCase("screen on", "set_screen", """{"on":true}""", "1"),
            OnOffCase("screen without on", "set_screen", """{}""", null),
        )
        for (c in cases) {
            clearMocks(dispatcher)
            coEvery { dispatcher.dispatch(any(), any()) } returns DispatchResult(true)
            val out = JSONObject(tools().execute(call(c.tool, c.args)))
            if (c.payload != null) {
                val kind = c.tool.removePrefix("set_")
                assertTrue("case: ${c.label}: $out", out.getBoolean("ok"))
                coVerify { dispatcher.dispatch(match { it.kind == kind && it.payload == c.payload }, null) }
            } else {
                assertTrue("case: ${c.label}: $out", out.has("error"))
                assertFalse("case: ${c.label}: $out", out.getString("error").contains("неизвестный инструмент"))
                coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
            }
        }
    }

    // Parity: every tool the model is shown must have an execute() branch, so a schema entry can
    // never be a tool that answers "неизвестный инструмент". Replaces the per-tool schema-listing tests.
    @Test fun every_schema_tool_is_known_to_execute() = runTest {
        coEvery { ruleDao.getEnabled() } returns emptyList()
        coEvery { settingsRepository.getString(SettingsRepository.KEY_EXA_API_KEY, "") } returns "exa-key"
        val tools = tools()
        val schemas = tools.schemas()
        val names = (0 until schemas.length())
            .map { schemas.getJSONObject(it).getJSONObject("function").getString("name") }
        assertTrue("schema is empty", names.isNotEmpty())
        for (name in names) {
            val reply = tools.execute(call(name, "{}"))
            assertFalse("$name is in the schema but execute() does not know it: $reply",
                reply.contains("неизвестный инструмент"))
        }
    }

    private fun screenRule(action: String) =
        """{"name":"Сон","trigger":{"kind":"param","param":"SOC","operator":"<","value":"20"},"actions":[$action]}"""

    @Test fun create_automation_screen_off_persists_payload_0() = runTest {
        coEvery { ruleDao.getAllList() } returns emptyList()
        coEvery { ruleDao.getCount() } returns 0
        val saved = slot<RuleEntity>()
        coEvery { ruleDao.insert(capture(saved)) } returns 1L

        tools().execute(call("create_automation", screenRule("""{"kind":"screen","on":false}""")))

        val action = ActionDef.listFromJson(saved.captured.actions).first()
        assertEquals("screen", action.kind)
        assertEquals("0", action.payload)
    }

    @Test fun create_automation_screen_missing_on_reports_error_no_insert() = runTest {
        coEvery { ruleDao.getAllList() } returns emptyList()

        val out = JSONObject(tools().execute(call("create_automation", screenRule("""{"kind":"screen"}"""))))

        assertTrue(out.getString("error"), out.getString("error").contains("screen"))
        coVerify(exactly = 0) { ruleDao.insert(any()) }
    }
}
