package com.bydmate.app.voice

import com.bydmate.app.data.vehicle.CommandTranslator

/**
 * The Russian golden corpus (test resource voice/ru_commands_golden.tsv): utterances in
 * the exact form GigaAM emits (lowercase, no punctuation, numbers as words) pinned to
 * the command string the offline parser must produce. Pure, so the scoring can run
 * outside JUnit too.
 */
object RuGoldenCorpus {

    const val UNRECOGNIZED = "UNRECOGNIZED"

    data class Row(val utterance: String, val expected: String, val category: String, val danger: Boolean)

    fun load(): List<Row> {
        val stream = requireNotNull(javaClass.classLoader?.getResourceAsStream("voice/ru_commands_golden.tsv"))
        return parse(stream.bufferedReader(Charsets.UTF_8).readText())
    }

    fun parse(tsv: String): List<Row> = tsv.lines()
        .drop(1)
        .filter { it.isNotBlank() }
        .map { line ->
            val cols = line.split('\t')
            Row(cols[0], cols[1], cols[2], cols.getOrNull(3) == "danger")
        }

    /** One comparable string per parse result: commands joined with "+" in dispatch order. */
    fun render(result: ParseResult): String = when (result) {
        is ParseResult.Command -> result.commands.joinToString("+")
        is ParseResult.RelativeTemp -> "TEMP:" + if (result.sign > 0) "+1" else "-1"
        is ParseResult.Volume -> "VOL:" + result.payload
        is ParseResult.Ask -> "ASK:" + result.question.id
        ParseResult.Music -> "MUSIC"
        is ParseResult.Navigate -> (if (result.go) "NAVIGATE:" else "ROUTE:") + result.shortcut
        ParseResult.OpenNavigator -> "OPEN_NAVIGATOR"
        ParseResult.Unrecognized -> UNRECOGNIZED
    }

    fun actual(row: Row): String = render(NluParser.parse(row.utterance))

    /**
     * Aperture share each command leaves per opening (window door or sunroof), taken from
     * the real write the translator produces. Sunroof enum: 1 open, 3 half, 5 vent (tilt),
     * 6 comfort (treated as fully open), 2 close.
     */
    fun apertures(rendered: String): Map<String, Int> {
        if (rendered == UNRECOGNIZED || rendered.startsWith("TEMP:") || rendered.startsWith("VOL:")) return emptyMap()
        val out = LinkedHashMap<String, Int>()
        rendered.split('+').flatMap { CommandTranslator.resolve(it) }.forEach { w ->
            aperture(w.actionName, w.value)?.let { (target, pct) -> out[target] = pct }
        }
        return out
    }

    private fun aperture(name: String, value: Int): Pair<String, Int>? = when {
        name.startsWith("sunroof_") -> "sunroof" to sunroofShare(value)
        !name.startsWith("window_") -> null
        name.endsWith("_open") -> name.removeSuffix("_open") to 100
        name.endsWith("_close") -> name.removeSuffix("_close") to 0
        name.endsWith("_pos") -> name.removeSuffix("_pos") to value
        else -> null
    }

    private fun sunroofShare(value: Int): Int = when (value) {
        1, 6 -> 100
        3 -> 50
        5 -> 7
        else -> 0
    }

    /** True when [actual] opens some aperture wider than [expected] asks for (or at all
     *  when the expectation does not touch it). */
    fun doesMoreThanExpected(expected: String, actual: String): Boolean {
        val want = apertures(expected)
        return apertures(actual).any { (target, pct) -> pct > (want[target] ?: 0) }
    }

    // Copied from VoiceDictionary.FILLERS, not referenced: this oracle must stay independent of
    // the production filler list, so a change there cannot silently blind it.
    private val FILLERS = setOf("пожалуйста", "можешь", "мне", "слушай", "эй", "спасибо", "хочу", "я")

    /** The share the utterance itself names ("на сорок процентов", "на треть", "чуть"), the
     *  smallest when it names several, or null. Read here on its own, independent of the
     *  dictionary, so a template that widens a spoken share fails the corpus. Fillers are
     *  dropped first (like the dictionary matcher does) so one between a preposition and its
     *  number, e.g. "на пожалуйста пятьдесят", does not hide the number from [numberShare].
     *  Number words are still read via the production [VoiceNormalizer.digits] table: the
     *  corpus draws its numbers from the same Russian number words the dictionary accepts,
     *  so a second, hand-copied table would only duplicate that table's own risk of drift. */
    fun spokenShare(utterance: String): Int? {
        val w = VoiceNormalizer.digits(VoiceNormalizer.tokens(utterance).filterNot { it in FILLERS })
        return w.indices.mapNotNull { shareAt(w, it) }.minOrNull()
    }

    private val VENT_WORDS = setOf("чуть", "немного", "немножко", "слегка", "щелочку", "щелку")

    private val QUARTER = setOf("четверть", "четверти")

    /** "3 четверти" is 75; any other number is a share only after на/до or before процент*. */
    private fun numberShare(number: Int, prev: String?, next: String?): Int? = when {
        next in QUARTER -> number * 25
        prev == "на" || prev == "до" || next?.startsWith("процент") == true -> number
        else -> null
    }

    private fun shareAt(w: List<String>, i: Int): Int? {
        val t = w[i]
        val prev = w.getOrNull(i - 1)
        val next = w.getOrNull(i + 1)
        VoiceNormalizer.number(t)?.let { return numberShare(it, prev, next) }
        return when {
            t in QUARTER -> 25.takeIf { prev == null || VoiceNormalizer.number(prev) == null }
            t in setOf("треть", "трети") -> 33
            t == "наполовину" || t.startsWith("половин") -> 50
            t == "пол" -> 50.takeIf { prev == "на" || next?.startsWith("окн") == true }
            t in VENT_WORDS -> 10
            t == "полностью" || t == "конца" && prev == "до" -> 100
            else -> null
        }
    }

    /** True when [actual] opens some aperture wider than the share the utterance names,
     *  whatever the expected string was rounded to. */
    fun opensWiderThanSpoken(utterance: String, actual: String): Boolean {
        val limit = spokenShare(utterance) ?: return false
        return apertures(actual).values.any { it > limit }
    }

    data class Score(val category: String, val correct: Int, val total: Int) {
        val accuracy: Double get() = if (total == 0) 1.0 else correct.toDouble() / total
    }

    fun score(rows: List<Row>, actualOf: (Row) -> String = ::actual): List<Score> {
        val byCategory = rows.groupBy { it.category }.map { (cat, rs) ->
            Score(cat, rs.count { actualOf(it) == it.expected }, rs.size)
        }
        return byCategory + Score("overall", byCategory.sumOf { it.correct }, rows.size)
    }
}
