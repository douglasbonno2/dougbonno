package com.bydmate.app.ui.settings

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.test.core.app.ApplicationProvider
import com.bydmate.app.data.automation.RouteNavigatorUris
import com.bydmate.app.diagnostics.Trace
import com.bydmate.app.diagnostics.TraceArea
import com.bydmate.app.diagnostics.TraceRecorder
import com.bydmate.app.data.backup.BackupManager
import com.bydmate.app.data.charging.ChargeConnector
import com.bydmate.app.data.local.EnergyDataDeadDetector
import com.bydmate.app.data.local.LocalePreferences
import com.bydmate.app.data.local.EnergyDataReader
import com.bydmate.app.data.local.HistoryImporter
import com.bydmate.app.data.local.dao.BatterySnapshotDao
import com.bydmate.app.data.local.dao.ChargeDao
import com.bydmate.app.data.local.dao.ChargeSummary
import com.bydmate.app.data.local.dao.IdleDrainDao
import com.bydmate.app.data.local.dao.SettingsDao
import com.bydmate.app.data.local.dao.TariffPeriodDao
import com.bydmate.app.data.local.dao.TripDao
import com.bydmate.app.data.local.dao.TripPointDao
import com.bydmate.app.data.local.dao.TripCounterStats
import com.bydmate.app.data.local.dao.TripSummary
import com.bydmate.app.data.local.dao.TripTombstoneDao
import com.bydmate.app.data.local.database.AppDatabase
import com.bydmate.app.data.local.entity.BatterySnapshotEntity
import com.bydmate.app.data.local.entity.ChargeEntity
import com.bydmate.app.data.local.entity.IdleDrainEntity
import com.bydmate.app.data.local.entity.SettingEntity
import com.bydmate.app.data.local.entity.TariffPeriodEntity
import com.bydmate.app.data.local.entity.TripEntity
import com.bydmate.app.data.local.entity.TripPointEntity
import com.bydmate.app.data.remote.InsightsManager
import com.bydmate.app.data.remote.OpenRouterClient
import com.bydmate.app.util.appLocalizedContext
import java.io.File
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.data.repository.TripRepository
import com.bydmate.app.service.UpdateChecker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import okhttp3.OkHttpClient
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import com.bydmate.app.data.vehicle.DumpFidsResult
import com.bydmate.app.data.vehicle.SeatChannel
import com.bydmate.app.data.vehicle.SeatChannelStore
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.coVerifyOrder
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import com.bydmate.app.agent.AgentOrchestrator
import com.bydmate.app.agent.AgentResult
import com.bydmate.app.agent.LlmConnectionResolver
import com.bydmate.app.data.vehicle.HelperBootstrap
import com.bydmate.app.data.vehicle.HelperClient
import com.bydmate.app.voice.online.TtsRouter
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
class SettingsViewModelTest {

    @get:Rule val trace = TraceRecorder()

    private val testDispatcher = StandardTestDispatcher()
    private val seatChannelStore: SeatChannelStore = mockk(relaxed = true)
    private val windowChannelStore: com.bydmate.app.data.vehicle.WindowChannelStore = mockk(relaxed = true)
    private val helperClient: HelperClient = mockk(relaxed = true)
    // relaxed → ensureRunning() defaults to false; tests that need the daemon "up" stub it true.
    private val helperBootstrap: HelperBootstrap = mockk(relaxed = true)
    private val agentOrchestrator: AgentOrchestrator = mockk(relaxed = true)
    private val energyDataDeadDetector: EnergyDataDeadDetector = mockk(relaxed = true)

    // Collaborators the diagnostic header reads; lazy, so a test that never touches them pays as before.
    private val ruleDao: com.bydmate.app.data.local.dao.RuleDao by lazy { mockk(relaxed = true) }
    private val automationEngine: com.bydmate.app.data.automation.AutomationEngine by lazy { mockk(relaxed = true) }
    private val hudController: com.bydmate.app.hud.HudController by lazy { mockk(relaxed = true) }
    private val blindSpotController: com.bydmate.app.camera.BlindSpotController by lazy { mockk(relaxed = true) }
    private val clusterMusicBridge: com.bydmate.app.media.ClusterMusicBridge by lazy { mockk(relaxed = true) }
    private val splitPreferences: com.bydmate.app.split.SplitPreferences by lazy { mockk(relaxed = true) }
    private val splitSessionManager: com.bydmate.app.split.SplitSessionManager by lazy { mockk(relaxed = true) }
    private val cloudOverWifiManager: com.bydmate.app.data.autoservice.CloudOverWifiManager by lazy { mockk(relaxed = true) }
    private val telegramReporter: com.bydmate.app.data.telegram.TelegramReporter by lazy { mockk(relaxed = true) }
    private val vehicleWriteLogDao: com.bydmate.app.data.local.dao.VehicleWriteLogDao by lazy { mockk(relaxed = true) }
    private val fidPushChannel: com.bydmate.app.data.push.FidPushChannel by lazy { mockk(relaxed = true) }

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        // The bare test Application does not run the app's locale bootstrap: pin the language the assertions read.
        LocalePreferences(ApplicationProvider.getApplicationContext<Context>()).setLanguage("en")
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // --- Fake DAOs ---

    private class FakeSettingsDao : SettingsDao {
        val map = mutableMapOf<String, String>()
        override suspend fun get(key: String): String? = map[key]
        override suspend fun getMany(keys: List<String>): List<SettingEntity> =
            keys.mapNotNull { k -> map[k]?.let { SettingEntity(k, it) } }
        override fun observe(key: String): Flow<String?> = flowOf(map[key])
        override suspend fun set(entity: SettingEntity) { map[entity.key] = entity.value ?: "" }
        override suspend fun setAll(settings: List<SettingEntity>) { settings.forEach { set(it) } }
    }

    private open class StubTripDao : TripDao {
        override suspend fun insert(trip: TripEntity): Long = 0L
        override suspend fun update(trip: TripEntity) {}
        override fun getAll(): Flow<List<TripEntity>> = flowOf(emptyList())
        override suspend fun getById(id: Long): TripEntity? = null
        override fun getByDateRange(from: Long, to: Long): Flow<List<TripEntity>> = flowOf(emptyList())
        override fun getRecent(limit: Int): Flow<List<TripEntity>> = flowOf(emptyList())
        override suspend fun getCount(): Int = 0
        override suspend fun getByBydId(bydId: Long): TripEntity? = null
        override suspend fun getTripsWithoutCost(): List<TripEntity> = emptyList()
        override suspend fun getEnergyDataTripsWithoutCounters(sinceTs: Long): List<TripEntity> = emptyList()
        override suspend fun getHybridTripsWithoutCost(): List<TripEntity> = emptyList()
        override suspend fun getPeriodSummary(from: Long, to: Long): TripSummary = TripSummary(0.0, 0.0)
        override suspend fun getLiveTrips(): List<TripEntity> = emptyList()
        override suspend fun getSameTripByTime(startTs: Long, windowMs: Long): TripEntity? = null
        override suspend fun getAllSnapshot(): List<TripEntity> = emptyList()
        override suspend fun unlinkBydId(id: Long, bydId: Long): Int = 0
        override suspend fun getWithEnergyInRange(from: Long, to: Long): List<TripEntity> = emptyList()
        override suspend fun deleteById(id: Long) {}
        override suspend fun deleteZeroKmTrips(): Int = 0
        override suspend fun fillOdometerIfEmpty(id: Long, startKm: Double?, endKm: Double?): Int = 0
        override suspend fun getRecentForEma(limit: Int): List<TripEntity> = emptyList()
        override suspend fun getRecentForEmaFiltered(minKm: Double, limit: Int): List<TripEntity> = emptyList()
        override fun observeCounterStats(from: Long, sessionStart: Long): Flow<TripCounterStats> = flowOf(TripCounterStats(0.0, 0.0, 0.0, 0.0, 0.0, 0, 0L, 0.0, 0.0, 0L, 0, 0.0, 0.0, 0L))
    }

    private class StubTripPointDao : TripPointDao {
        override suspend fun insertAll(points: List<TripPointEntity>) {}
        override suspend fun getByTripId(tripId: Long): List<TripPointEntity> = emptyList()
        override suspend fun getCount(): Int = 0
        override suspend fun thinOldPoints(cutoff: Long, intervalMs: Long): Int = 0
        override suspend fun attachToTrip(tripId: Long, from: Long, to: Long): Int = 0
        override suspend fun deleteByTripId(tripId: Long): Int = 0
    }

    private open class StubChargeDao : ChargeDao {
        override suspend fun insert(charge: ChargeEntity): Long = 0L
        override suspend fun update(charge: ChargeEntity) {}
        override fun getAll(): Flow<List<ChargeEntity>> = flowOf(emptyList())
        override suspend fun getById(id: Long): ChargeEntity? = null
        override fun getByDateRange(from: Long, to: Long): Flow<List<ChargeEntity>> = flowOf(emptyList())
        override suspend fun getPeriodSummary(from: Long, to: Long): ChargeSummary = ChargeSummary(0, 0.0, 0.0)
        override suspend fun getAllAutoserviceCharges(): List<ChargeEntity> = emptyList()
        override suspend fun hasLegacyCharges(): Boolean = false
        override suspend fun deleteEmpty(): Int = 0
        override suspend fun getCompletedSince(since: Long): List<ChargeEntity> = emptyList()
        override suspend fun getInRangeAsc(from: Long, to: Long): List<ChargeEntity> = emptyList()
        override suspend fun getCompletedForPricing(until: Long): List<ChargeEntity> = emptyList()
        override suspend fun getWithMeterReading(): List<ChargeEntity> = emptyList()
        override suspend fun deletePhantomAutoserviceRows(): Int = 0
        override suspend fun delete(charge: ChargeEntity) {}
    }

    private class StubIdleDrainDao : IdleDrainDao {
        override suspend fun insert(drain: IdleDrainEntity): Long = 0L
        override suspend fun update(drain: IdleDrainEntity) {}
        override suspend fun getCount(): Int = 0
        override suspend fun getAll(): List<IdleDrainEntity> = emptyList()
        override suspend fun deleteAll() {}
        override suspend fun getKwhSince(since: Long): Double = 0.0
        override suspend fun getHoursSince(since: Long): Double = 0.0
        override suspend fun getKwhBetween(from: Long, to: Long): Double = 0.0
        override suspend fun getSince(since: Long): List<IdleDrainEntity> = emptyList()
    }

    private class StubBatterySnapshotDao : BatterySnapshotDao {
        override fun getAll(): Flow<List<BatterySnapshotEntity>> = flowOf(emptyList())
        override suspend fun insert(snapshot: BatterySnapshotEntity): Long = 0L
        override suspend fun getLast(): BatterySnapshotEntity? = null
    }

    // --- Factory ---

    private lateinit var settingsDao: FakeSettingsDao

    // Tariff fixture: fields rather than factory parameters, the factory is long enough.
    private var exportCostCalculator: com.bydmate.app.domain.cost.CostCalculator? = null

    // Car type handed to the next built VM; null keeps the relaxed monitor.
    private var vehicleKind: com.bydmate.app.data.nativestack.VehicleKind? = null
    private var tariffPeriodDaoOverride: TariffPeriodDao? = null
    // The log sender of the last built VM, to play the automatic upload (#324).
    private lateinit var logTelegramSender: com.bydmate.app.diagnostics.LogTelegramSender
    // Recorder state handed to the next built VM; null keeps the real recorder that never records.
    private var logRecorderState: kotlinx.coroutines.flow.MutableStateFlow<com.bydmate.app.diagnostics.LogRecorder.State>? = null

    /** In-memory stand-in for the Room DAO, including the unique `start_ts` constraint. */
    private class FakeTariffPeriodDao(initial: List<TariffPeriodEntity>) : TariffPeriodDao {
        val rows = initial.toMutableList()
        private var nextId = (initial.maxOfOrNull { it.id } ?: 0L) + 1L
        override suspend fun insert(period: TariffPeriodEntity): Long {
            val id = if (period.id == 0L) nextId++ else period.id
            rows.removeAll { it.id == id || it.startTs == period.startTs }
            rows.add(period.copy(id = id))
            return id
        }
        override suspend fun update(period: TariffPeriodEntity) {
            check(rows.none { it.id != period.id && it.startTs == period.startTs }) {
                "UNIQUE constraint failed: tariff_periods.start_ts"
            }
            rows.replaceAll { if (it.id == period.id) period else it }
        }
        override suspend fun delete(period: TariffPeriodEntity) { rows.removeAll { it.id == period.id } }
        override suspend fun getAllAsc(): List<TariffPeriodEntity> = rows.sortedBy { it.startTs }
        override suspend fun getByStartTs(startTs: Long): TariffPeriodEntity? = rows.find { it.startTs == startTs }
        override suspend fun count(): Int = rows.size
    }

    // Stub BackupManager: no AppDatabase available in unit tests, use mockk
    private var backupManager: BackupManager = mockk(relaxed = true)

    // Telegram Bot API stand-in for the auto-backup «Проверить» flow (#237).
    private var telegramBackupSink: com.bydmate.app.data.backup.TelegramBackupSink = mockk(relaxed = true)

    private fun buildViewModel(
        updateChecker: UpdateChecker? = null,
        ttsModelManager: com.bydmate.app.voice.TtsModelManager? = null,
        ttsEngine: com.bydmate.app.voice.TtsEngine? = null,
        gigaAmModelManager: com.bydmate.app.voice.GigaAmModelManager? = null,
        llmConnectionResolver: LlmConnectionResolver? = null,
        voiceJournal: com.bydmate.app.voice.VoiceJournal = com.bydmate.app.voice.VoiceJournal(),
    ): SettingsViewModel {
        val ctx: Context = ApplicationProvider.getApplicationContext()

        settingsDao = FakeSettingsDao()
        val settingsRepo = SettingsRepository(settingsDao, mockk<LocalePreferences>(relaxed = true))

        val tripDao = object : StubTripDao() {
            override fun getAll(): Flow<List<TripEntity>> = flowOf(emptyList())
        }
        val tripPointDao = StubTripPointDao()
        val tripRepo = TripRepository(tripDao, tripPointDao, mockk<TripTombstoneDao>(relaxed = true), mockk<AppDatabase>(relaxed = true))

        val chargeDao = object : StubChargeDao() {
            override fun getAll(): Flow<List<ChargeEntity>> = flowOf(emptyList())
        }
        val idleDrainDao = StubIdleDrainDao()

        val httpClient = OkHttpClient()
        val resolvedUpdateChecker = updateChecker ?: UpdateChecker(httpClient, com.bydmate.app.util.AppStrings(ctx))

        val energyReader = EnergyDataReader(ctx)
        val historyImporter = HistoryImporter(
            ctx, energyReader, tripRepo, tripDao, tripPointDao, idleDrainDao,
            settingsRepo, com.bydmate.app.data.repository.LastSessionRepository(ctx),
            mockk<TripTombstoneDao>(relaxed = true), mockk(relaxed = true),
            com.bydmate.app.data.repository.OdometerMarks(ctx),
            com.bydmate.app.data.nativestack.kindMonitor(), mockk(relaxed = true),
            mockk(relaxed = true), mockk(relaxed = true),
        )

        val openRouterClient = OpenRouterClient(httpClient)
        val insightsManager = InsightsManager(ctx, openRouterClient, tripDao, idleDrainDao, chargeDao, settingsRepo)

        // Voice deps are not exercised by most settings tests; relaxed mocks keep them inert.
        val resolvedTtsModelManager = ttsModelManager ?: mockk(relaxed = true)
        val resolvedTtsEngine = ttsEngine ?: mockk<com.bydmate.app.voice.TtsEngine>(relaxed = true)
        val resolvedGigaAmModelManager = gigaAmModelManager ?: mockk(relaxed = true)
        val continuousAsr = mockk<com.bydmate.app.voice.ContinuousAsr>(relaxed = true)

        // Real recorder with an exec seam that would blow up: these tests never record.
        val logRecorder = logRecorderState?.let { flow ->
            mockk<com.bydmate.app.diagnostics.LogRecorder>(relaxed = true) { every { state } returns flow }
        } ?: com.bydmate.app.diagnostics.LogRecorder(ctx) {
            throw UnsupportedOperationException("no logcat in tests")
        }
        logTelegramSender = com.bydmate.app.diagnostics.LogTelegramSender(
            logRecorder, settingsRepo, telegramBackupSink, com.bydmate.app.util.AppStrings(ctx),
        )
        val localePreferences = LocalePreferences(ctx)
        val resolvedLlmConnectionResolver = llmConnectionResolver ?: mockk(relaxed = true)
        val costCalculator = exportCostCalculator ?: mockk(relaxed = true)
        val adbVerdictMonitor: com.bydmate.app.data.autoservice.AdbVerdictMonitor = mockk(relaxed = true) {
            io.mockk.every { verdict } returns kotlinx.coroutines.flow.MutableStateFlow(null)
            io.mockk.every { checking } returns kotlinx.coroutines.flow.MutableStateFlow(false)
        }
        val vehicleKindMonitor = vehicleKind?.let { com.bydmate.app.data.nativestack.kindMonitor(it) }
            ?: mockk(relaxed = true)
        val dumpWriter = DiagnosticDumpWriter(
            appContext = ctx,
            settingsRepository = settingsRepo,
            historyImporter = historyImporter,
            localePreferences = localePreferences,
            chargingStateStore = com.bydmate.app.data.charging.ChargingStateStore(settingsRepo),
            catchUpJournal = com.bydmate.app.data.charging.CatchUpJournal(settingsRepo),
            windowChannelStore = windowChannelStore,
            helperClient = helperClient,
            helperBootstrap = helperBootstrap,
            llmConnectionResolver = resolvedLlmConnectionResolver,
            energyDataDeadDetector = energyDataDeadDetector,
            hudController = hudController,
            fidPushChannel = fidPushChannel,
            splitPreferences = splitPreferences,
            splitSessionManager = splitSessionManager,
            splitJournal = com.bydmate.app.split.NoSplitJournal,
            adbRestoreManager = com.bydmate.app.data.autoservice.AdbRestoreManager(
                com.bydmate.app.data.autoservice.AdbRestorePreferencesImpl(ctx),
                mockk(relaxed = true),
                kotlinx.coroutines.test.TestScope(),
            ),
            cloudOverWifiManager = cloudOverWifiManager,
            fidCatalogManager = mockk(relaxed = true),
            writeAllowlist = com.bydmate.app.data.vehicle.WriteAllowlist.EMPTY,
            ruleDao = ruleDao,
            automationEngine = automationEngine,
            voiceJournal = voiceJournal,
            costCalculator = costCalculator,
            blindSpotController = blindSpotController,
            adbVerdictMonitor = adbVerdictMonitor,
            telegramReporter = telegramReporter,
            clusterMusicBridge = clusterMusicBridge,
            vehicleWriteLogDao = vehicleWriteLogDao,
            vehicleKindMonitor = vehicleKindMonitor,
        )
        return SettingsViewModel(
            appContext = ctx,
            settingsRepository = settingsRepo,
            updateChecker = resolvedUpdateChecker,
            historyImporter = historyImporter,
            insightsManager = insightsManager,
            localePreferences = localePreferences,
            backupManager = backupManager,
            ttsModelManager = resolvedTtsModelManager,
            ruStressMarker = com.bydmate.app.voice.RuStressMarker { null },
            gigaAmModelManager = resolvedGigaAmModelManager,
            continuousAsr = continuousAsr,
            ttsEngine = resolvedTtsEngine,
            seatChannelStore = seatChannelStore,
            helperClient = helperClient,
            helperBootstrap = helperBootstrap,
            agentOrchestrator = agentOrchestrator,
            llmConnectionResolver = resolvedLlmConnectionResolver,
            openRouterClient = openRouterClient,
            energyDataDeadDetector = energyDataDeadDetector,
            logRecorder = logRecorder,
            dumpWriter = dumpWriter,
            splitPreferences = splitPreferences,
            driverMemory = com.bydmate.app.agent.DriverMemory(
                ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
            ),
            dayMemory = com.bydmate.app.agent.DayMemory(
                ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
            ),
            ruleDao = ruleDao,
            tariffPeriodDao = tariffPeriodDaoOverride ?: mockk(relaxed = true),
            costCalculator = costCalculator,
            adbVerdictMonitor = adbVerdictMonitor,
            telegramBackupSink = telegramBackupSink,
            autoBackupScheduler = mockk(relaxed = true),
            appStrings = com.bydmate.app.util.AppStrings(ctx),
            logTelegramSender = logTelegramSender,
            vehicleKindMonitor = vehicleKindMonitor,
        )
    }

    // --- Tests ---

    @Test
    fun `setFontScale writes through to LocalePreferences and updates the flow`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(1.0f, vm.fontScale.value)

        vm.setFontScale(1.3f)

        assertEquals(1.3f, vm.fontScale.value)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(1.3f, LocalePreferences(ctx).getFontScale())
    }

    @Test
    fun `initial state has default home tariff`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(SettingsRepository.DEFAULT_HOME_TARIFF, vm.uiState.value.homeTariff)
    }

    // «Разъём для зарядки»: GB/T until the driver picks another, the pick is saved.
    @Test
    fun `charge connector starts as GB-T and a pick is saved`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(ChargeConnector.GBT, vm.uiState.value.chargeConnector)

        vm.saveChargeConnector(ChargeConnector.CHADEMO)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(ChargeConnector.CHADEMO, vm.uiState.value.chargeConnector)
        assertEquals("chademo", settingsDao.map[SettingsRepository.KEY_CHARGE_CONNECTOR])
    }

    // Issue #23: pressing "Close" while an update is downloading must cancel the
    // download coroutine and clear the Downloading state. Without cancellation the
    // progress callback keeps re-emitting Downloading (re-opening the dialog) and
    // the download eventually fires the system install prompt unexpectedly.
    @Test
    fun `closing update dialog during download cancels job and clears downloading state`() = runTest {
        val uc = mockk<UpdateChecker>(relaxed = true)
        val info = UpdateChecker.UpdateInfo(
            version = "9.9.9",
            downloadUrl = "http://example.invalid/BYDMate.apk",
            releaseNotes = ""
        )
        coEvery { uc.checkForUpdate(any(), any()) } returns info
        val onProgressSlot = slot<(String) -> Unit>()
        coEvery { uc.downloadAndInstall(any(), any(), capture(onProgressSlot)) } coAnswers {
            onProgressSlot.captured.invoke("10%")
            delay(10_000)                       // still downloading...
            onProgressSlot.captured.invoke("100%") // must NOT run after the dialog is closed
        }

        val vm = buildViewModel(updateChecker = uc)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadUpdate()
        testDispatcher.scheduler.runCurrent() // start download, emit "10%", suspend on delay

        vm.hideUpdateDialog()
        testDispatcher.scheduler.advanceUntilIdle() // cancelled job must not resurrect state

        assertEquals(UpdateState.Idle, vm.uiState.value.updateDialogState)
    }

    @Test fun `resetSeatChannel sets winner to UNKNOWN`() = runTest {
        val vm = buildViewModel()
        vm.resetSeatChannel()
        verify { seatChannelStore.setWinner(SeatChannel.UNKNOWN) }
    }

    @Test fun `setDisableNativeAssistant updates state and applies via helper`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        coEvery { helperClient.setAppHidden("com.byd.autovoice", true) } returns true

        vm.setDisableNativeAssistant(true)
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.disableNativeAssistant)
        coVerify { helperClient.setAppHidden("com.byd.autovoice", true) }
    }

    @Test fun `switching the native assistant toggle on asks first and touches nothing yet`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.toggleDisableNativeAssistant(true)
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.showDisableNativeAssistantDialog)
        assertFalse(vm.uiState.value.disableNativeAssistant)
        coVerify(exactly = 0) { helperClient.setAppHidden(any(), any()) }
        assertNull(settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
    }

    @Test fun `confirming the native assistant warning disables it`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.toggleDisableNativeAssistant(true)
        vm.confirmDisableNativeAssistant()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.showDisableNativeAssistantDialog)
        assertTrue(vm.uiState.value.disableNativeAssistant)
        assertEquals("true", settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
        coVerify { helperClient.setAppHidden("com.byd.autovoice", true) }
    }

    @Test fun `cancelling the native assistant warning leaves the toggle off and calls nothing`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.toggleDisableNativeAssistant(true)
        vm.dismissDisableNativeAssistantDialog()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.showDisableNativeAssistantDialog)
        assertFalse(vm.uiState.value.disableNativeAssistant)
        coVerify(exactly = 0) { helperClient.setAppHidden(any(), any()) }
        assertNull(settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
    }

    // --- No saved choice (a reinstall after an uninstall that left the assistant disabled): the
    // toggle shows what the system has; a saved choice keeps ruling as before. ---

    private fun installAssistantPackage(pkg: String, state: Int) {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        org.robolectric.Shadows.shadowOf(ctx.packageManager).installPackage(
            android.content.pm.PackageInfo().apply {
                packageName = pkg
                applicationInfo = android.content.pm.ApplicationInfo().apply { packageName = pkg }
            },
        )
        ctx.packageManager.setApplicationEnabledSetting(pkg, state, 0)
    }

    @Test fun `no saved choice and a user-disabled autovoice show the toggle on`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)
        installAssistantPackage("com.byd.vrassistant", PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.disableNativeAssistant)
        coVerify(exactly = 0) { helperClient.setAppHidden(any(), any()) }
        assertNull(settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
    }

    @Test fun `no saved choice and only a user-disabled vrassistant show the toggle on`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
        installAssistantPackage("com.byd.vrassistant", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.disableNativeAssistant)
    }

    @Test fun `no saved choice and only a user-disabled autovoice engine show the toggle on`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
        installAssistantPackage("com.byd.autovoice.engine", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)
        installAssistantPackage("com.byd.vrassistant", PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.disableNativeAssistant)
    }

    @Test fun `no saved choice and both packages enabled show the toggle off`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
        installAssistantPackage("com.byd.vrassistant", PackageManager.COMPONENT_ENABLED_STATE_ENABLED)

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.disableNativeAssistant)
    }

    @Test fun `a saved choice rules over the system state`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)

        val vm = buildViewModel()
        settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT] = "false"
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.disableNativeAssistant)
        assertTrue(trace.events().none { "native-assistant-from-system" in it })
    }

    @Test fun `switching off a toggle shown on from the system enables the assistant without the warning`() = runTest {
        installAssistantPackage("com.byd.autovoice", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)
        installAssistantPackage("com.byd.vrassistant", PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertTrue(vm.uiState.value.disableNativeAssistant)

        vm.toggleDisableNativeAssistant(false)
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.showDisableNativeAssistantDialog)
        assertFalse(vm.uiState.value.disableNativeAssistant)
        assertEquals("false", settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
        coVerify(exactly = 1) { helperClient.setAppHidden("com.byd.autovoice", false) }
        coVerify(exactly = 1) { helperClient.setAppHidden("com.byd.vrassistant", false) }
    }

    @Test fun `switching the native assistant toggle off goes without the warning`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setDisableNativeAssistant(true)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.toggleDisableNativeAssistant(false)
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.showDisableNativeAssistantDialog)
        assertFalse(vm.uiState.value.disableNativeAssistant)
        assertEquals("false", settingsDao.map[SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT])
        coVerify { helperClient.setAppHidden("com.byd.autovoice", false) }
    }

    /** One voice-settings case: prefs before the view model starts, one action, then what state and prefs show. */
    private class VoiceSettingCase(
        val label: String,
        val prefsBefore: (SharedPreferences.Editor) -> Unit = {},
        val act: (SettingsViewModel) -> Unit = {},
        val check: (SettingsViewModel, SharedPreferences) -> Unit,
        val engineReloads: Int? = null,
        val engineSpeaks: Int? = null,
    )

    private val voiceSettingCases by lazy {
        listOf(
            VoiceSettingCase(
                "setVoiceEnabled persists and mirrors into voice prefs",
                act = { it.setVoiceEnabled(true) },
                check = { vm, prefs ->
                    assertTrue(vm.uiState.value.voiceEnabled)
                    assertTrue(prefs.getBoolean(SettingsRepository.KEY_VOICE_ENABLED, false))
                },
            ),
            VoiceSettingCase(
                "setTtsEnabled persists and mirrors to voice prefs",
                act = { it.setTtsEnabled(true) },
                check = { vm, prefs ->
                    assertTrue(vm.uiState.value.ttsEnabled)
                    assertTrue(prefs.getBoolean(SettingsRepository.KEY_TTS_ENABLED, false))
                },
            ),
            VoiceSettingCase(
                "setTtsVoice persists, mirrors to voice prefs, and reloads the engine",
                act = { it.setTtsVoice("irina") },
                check = { vm, prefs ->
                    assertEquals("irina", vm.uiState.value.ttsVoice)
                    assertEquals("irina", prefs.getString("tts_voice", null))
                },
                engineReloads = 1,
            ),
            VoiceSettingCase(
                "agent identity initializes from voice prefs",
                prefsBefore = { it.putString("agent_name", "Лео").putString("agent_persona", "snarky") },
                check = { vm, _ ->
                    assertEquals("Лео", vm.uiState.value.agentName)
                    assertEquals("snarky", vm.uiState.value.agentPersona)
                },
            ),
            VoiceSettingCase(
                "setTtsRate persists, mirrors to voice prefs, and reloads the engine",
                act = { it.setTtsRate(1.2f) },
                check = { vm, prefs ->
                    assertEquals(1.2f, vm.uiState.value.ttsRate)
                    assertEquals(1.2f, prefs.getFloat("tts_rate", -1f))
                },
                engineReloads = 1,
            ),
            VoiceSettingCase(
                "setTtsLiveliness persists, mirrors to voice prefs, and reloads the engine",
                act = { it.setTtsLiveliness(80) },
                check = { vm, prefs ->
                    assertEquals(80, vm.uiState.value.ttsLiveliness)
                    assertEquals(80, prefs.getInt("tts_liveliness", -1))
                },
                engineReloads = 1,
            ),
            VoiceSettingCase(
                "previewVoice reloads the engine and speaks the sample line via speakOffline",
                act = { it.previewVoice() },
                check = { _, _ -> },
                engineReloads = 1,
                engineSpeaks = 1,
            ),
        )
    }

    @Test fun `voice settings reach state and the voice prefs, and the engine reloads where it should`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val prefs = ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
        for (c in voiceSettingCases) {
            val editor = prefs.edit().clear()
            c.prefsBefore(editor)
            editor.commit()
            val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
            coEvery { ttsModelManager.isReady(com.bydmate.app.voice.TtsVoiceCatalog.byId("irina")) } returns true
            val ttsEngine = mockk<com.bydmate.app.voice.TtsEngine>(relaxed = true)

            val vm = buildViewModel(ttsModelManager = ttsModelManager, ttsEngine = ttsEngine)
            testDispatcher.scheduler.advanceUntilIdle()
            c.act(vm)
            testDispatcher.scheduler.advanceUntilIdle()

            try {
                c.check(vm, prefs)
                c.engineReloads?.let { verify(exactly = it) { ttsEngine.reload() } }
                c.engineSpeaks?.let { verify(exactly = it) { ttsEngine.speakOffline(any()) } }
            } catch (e: AssertionError) {
                throw AssertionError("case: ${c.label}: ${e.message}", e)
            }
        }
    }

    /**
     * Fix (Finding 3b): enabling Voice must best-effort re-bind the a11y key service (the same
     * daemon call ClusterProjectionManager.enableStarControl uses) — otherwise the PTT key filter
     * (SteeringWheelKeyService) is never bound on a fresh install with no cluster-projection toggle.
     * The daemon must be bootstrapped FIRST: HelperClient only resolves an existing binder, so
     * without ensureRunning() the re-bind silently no-ops when the daemon is not up.
     */
    @Test fun `setVoiceEnabled true bootstraps daemon then triggers accessibility re-bind`() = runTest {
        coEvery { helperBootstrap.ensureRunning() } returns true
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setVoiceEnabled(true)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerifyOrder {
            helperBootstrap.ensureRunning()
            helperClient.enableAccessibilityService()
        }
    }

    @Test fun `setVoiceEnabled true skips a11y re-bind when daemon bootstrap fails`() = runTest {
        coEvery { helperBootstrap.ensureRunning() } returns false
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setVoiceEnabled(true)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 0) { helperClient.enableAccessibilityService() }
    }

    @Test fun `setVoiceEnabled false does not touch daemon or accessibility re-bind`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setVoiceEnabled(false)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 0) { helperBootstrap.ensureRunning() }
        coVerify(exactly = 0) { helperClient.enableAccessibilityService() }
    }

    @Test fun `driver memory facts land in state and forgetAgentMemory clears storage`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val prefs = ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
        val memory = com.bydmate.app.agent.DriverMemory(prefs)
        memory.remember("зовут Андрей")
        memory.remember("любит 22 градуса в салоне")

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(2, vm.uiState.value.agentMemoryFacts.size)

        vm.forgetAgentMemory()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(emptyList<String>(), vm.uiState.value.agentMemoryFacts)
        assertEquals(emptyList<String>(), com.bydmate.app.agent.DriverMemory(prefs).facts())
    }

    // Final review fix, finding 3: a legacy "denis"/"dmitri" id read verbatim into state left no
    // radio row selected in Settings, even though playback already resolves it via byId(). State
    // must resolve through the same catalog lookup so the migrated voice shows selected.
    @Test fun `state resolves a legacy persisted voice id to its migrated catalog id`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
            .edit()
            .putString("tts_voice", "denis")
            .apply()

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("dmitri", vm.uiState.value.ttsVoice)
    }

    @Test fun `setAgentName and setAgentPersona mirror to voice prefs`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setAgentName("Майк")
        vm.setAgentPersona("engineer")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("Майк", vm.uiState.value.agentName)
        assertEquals("engineer", vm.uiState.value.agentPersona)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val prefs = ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
        assertEquals("Майк", prefs.getString("agent_name", null))
        assertEquals("engineer", prefs.getString("agent_persona", null))
    }

    @Test fun `downloadTtsVoice success adds voice to ttsReadyVoices`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        coEvery { ttsModelManager.download(any(), any()) } returns Result.success(Unit)
        coEvery { ttsModelManager.isReady(any()) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("alena")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(!vm.uiState.value.ttsDownloadProgress.containsKey("alena"))
        assertTrue("alena" in vm.uiState.value.ttsReadyVoices)
        assertTrue("alena" !in vm.uiState.value.ttsDownloadFailed)
    }

    @Test fun `downloadTtsVoice failure sets ttsDownloadFailed for that voice`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        coEvery { ttsModelManager.download(any(), any()) } returns Result.failure(RuntimeException("boom"))
        coEvery { ttsModelManager.isReady(any()) } returns false

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue("artem" in vm.uiState.value.ttsDownloadFailed)
        assertTrue("artem" !in vm.uiState.value.ttsReadyVoices)
    }

    /**
     * Fix: downloadTtsModel lacked the in-flight guard that downloadVoiceModel has
     * (`voiceDownloadProgress >= 0` early-return). A re-entrant call while a download is
     * already running must be a no-op — the manager's download() must be invoked only once.
     */
    @Test fun `downloadTtsVoice ignores re-entry for the same voice while in flight`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        coEvery { ttsModelManager.download(any(), any()) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { ttsModelManager.isReady(any()) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle()
        vm.downloadTtsVoice("artem") // re-entry while the first download is still in flight
        testDispatcher.scheduler.advanceUntilIdle()

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 1) { ttsModelManager.download(any(), any()) }
    }

    /**
     * Per-voice download state must not clobber another voice's state: downloading "irina"
     * while "artem" is already ready (or mid-download) must leave artem's state untouched.
     */
    @Test fun `downloadTtsVoice for one voice does not affect another voice's state`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        coEvery { ttsModelManager.isReady(com.bydmate.app.voice.TtsVoiceCatalog.byId("ruslan")) } returns true
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        coEvery { ttsModelManager.download(com.bydmate.app.voice.TtsVoiceCatalog.byId("irina"), any()) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { ttsModelManager.isReady(com.bydmate.app.voice.TtsVoiceCatalog.byId("irina")) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()
        // ruslan is already ready from initial load (isReady stubbed true above)
        assertTrue("ruslan" in vm.uiState.value.ttsReadyVoices)

        vm.downloadTtsVoice("irina")
        testDispatcher.scheduler.advanceUntilIdle() // irina's download now in flight

        assertTrue("irina" in vm.uiState.value.ttsDownloadProgress)
        assertTrue("ruslan" !in vm.uiState.value.ttsDownloadProgress)
        assertTrue("ruslan" in vm.uiState.value.ttsReadyVoices) // untouched by irina's download

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue("irina" in vm.uiState.value.ttsReadyVoices)
        assertTrue("ruslan" in vm.uiState.value.ttsReadyVoices)
    }

    /**
     * mark and sofia share the "supertonic-ru" model dir: downloading one must mark both
     * ready, since they share the same on-disk model.
     */
    @Test fun `downloadTtsVoice marks sibling voice ready when they share a modelDirId`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        coEvery { ttsModelManager.download(any(), any()) } returns Result.success(Unit)
        coEvery { ttsModelManager.isReady(com.bydmate.app.voice.TtsVoiceCatalog.byId("mark")) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("mark")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue("mark" in vm.uiState.value.ttsReadyVoices)
        assertTrue("sofia" in vm.uiState.value.ttsReadyVoices)
    }

    /**
     * Fix: deleteTtsModel did not cancel an active download job, so a stale download
     * completion could resurrect ready/progress state after delete. Must cancel the
     * voice's download job first, then delete, then reset state deterministically.
     */
    @Test fun `deleteTtsVoice cancels in-flight download`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        coEvery { ttsModelManager.download(any(), any()) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { ttsModelManager.isReady(any()) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle() // download now in flight, awaiting gate

        vm.deleteTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(!vm.uiState.value.ttsDownloadProgress.containsKey("artem"))
        assertTrue("artem" !in vm.uiState.value.ttsReadyVoices)
        assertTrue("artem" !in vm.uiState.value.ttsDownloadFailed)

        // Even if the (cancelled) download coroutine's suspended await were to resume, the
        // cancellation must have already torn it down — no stale write flips state back.
        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(!vm.uiState.value.ttsDownloadProgress.containsKey("artem"))
        assertTrue("artem" !in vm.uiState.value.ttsReadyVoices)

        coVerify(exactly = 1) { ttsModelManager.delete(any()) }
    }

    /**
     * Fix: the onProgress lambda passed to ttsModelManager.download() wrote unconditionally
     * into _uiState. deleteTtsVoice() removes the voice's progress entry (idle), but a stale
     * progress delivery arriving afterward (from an already-cancelled download coroutine
     * still winding down) must not resurrect an in-progress state.
     */
    @Test fun `late progress callback after delete is ignored`() = runTest {
        val ttsModelManager = mockk<com.bydmate.app.voice.TtsModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        val progressSlot = slot<(Int) -> Unit>()
        coEvery { ttsModelManager.download(any(), capture(progressSlot)) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { ttsModelManager.isReady(any()) } returns true

        val vm = buildViewModel(ttsModelManager = ttsModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle() // download now in flight, awaiting gate

        vm.deleteTtsVoice("artem")
        testDispatcher.scheduler.advanceUntilIdle()

        progressSlot.captured(55) // stale progress delivery after delete reset state to idle

        assertTrue(!vm.uiState.value.ttsDownloadProgress.containsKey("artem"))
    }

    @Test fun `setAgentGender switches selected local voice to its counterpart`() = runTest {
        val ttsEngine = mockk<com.bydmate.app.voice.TtsEngine>(relaxed = true)
        val vm = buildViewModel(ttsEngine = ttsEngine)
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals("dmitri", vm.uiState.value.ttsVoice) // default voice, male

        vm.setAgentGender("f")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("f", vm.uiState.value.agentGender)
        assertEquals("irina", vm.uiState.value.ttsVoice)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals("f", ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("agent_gender", null))
    }

    @Test fun `setAgentGender is a no-op on the voice when it already matches`() = runTest {
        val ttsEngine = mockk<com.bydmate.app.voice.TtsEngine>(relaxed = true)
        val vm = buildViewModel(ttsEngine = ttsEngine)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setAgentGender("m") // already male (default voice is dmitri)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("dmitri", vm.uiState.value.ttsVoice)
        verify(exactly = 0) { ttsEngine.reload() }
    }

    // --- Wave N: online TTS source (Gemini/OpenAI via OpenRouter, MiniMax) ---

    @Test fun `setTtsSource persists an online id to voice prefs`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setTtsSource("gemini")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("gemini", vm.uiState.value.ttsSource)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            "gemini",
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    @Test fun `setTtsSource minimax is rejected while no key is saved`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setTtsSource("minimax")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(TtsRouter.OFFLINE, vm.uiState.value.ttsSource)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            null,
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    @Test fun `setTtsSource minimax is accepted once a key is saved`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setMinimaxKey("mm-key")
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setTtsSource("minimax")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("minimax", vm.uiState.value.ttsSource)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            "minimax",
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    @Test fun `setMinimaxProvider persists via SettingsRepository`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setMinimaxProvider("fal")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("fal", vm.uiState.value.minimaxProvider)
        assertEquals("fal", settingsDao.map[SettingsRepository.KEY_MINIMAX_TTS_PROVIDER])
    }

    @Test fun `setMinimaxKey persists via SettingsRepository and flips minimaxKeySet`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertTrue(!vm.uiState.value.minimaxKeySet)

        vm.setMinimaxKey("mm-key")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.minimaxKeySet)
        assertEquals("mm-key", settingsDao.map[SettingsRepository.KEY_MINIMAX_TTS_KEY])
    }

    @Test fun `setMinimaxKey with a blank value clears minimaxKeySet`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setMinimaxKey("mm-key")
        testDispatcher.scheduler.advanceUntilIdle()
        assertTrue(vm.uiState.value.minimaxKeySet)

        vm.setMinimaxKey("")
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(!vm.uiState.value.minimaxKeySet)
    }

    @Test fun `setMinimaxKey with a blank value resets tts_source from minimax to offline`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setMinimaxKey("mm-key")
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setTtsSource("minimax")
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals("minimax", vm.uiState.value.ttsSource)

        vm.setMinimaxKey("")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(TtsRouter.OFFLINE, vm.uiState.value.ttsSource)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            TtsRouter.OFFLINE,
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    @Test fun `setMinimaxKey with a blank value leaves a non-minimax source untouched`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setMinimaxKey("mm-key")
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setTtsSource("gemini")
        testDispatcher.scheduler.advanceUntilIdle()

        vm.setMinimaxKey("")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("gemini", vm.uiState.value.ttsSource)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            "gemini",
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    // --- GigaAM v3 ASR (free-form Russian speech recognition, offline) ---

    @Test fun `initial state reflects gigaAmModelManager isReady`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.gigaAmModelReady)
    }

    @Test fun `downloadGigaAmModel success flips gigaAmModelReady`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        coEvery { gigaAmModelManager.download(any()) } returns Result.success(Unit)
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(-1, vm.uiState.value.gigaAmDownloadProgress)
        assertTrue(vm.uiState.value.gigaAmModelReady)
        assertTrue(!vm.uiState.value.gigaAmDownloadFailed)
    }

    @Test fun `downloadGigaAmModel failure sets gigaAmDownloadFailed`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        coEvery { gigaAmModelManager.download(any()) } returns Result.failure(RuntimeException("boom"))
        coEvery { gigaAmModelManager.isReady() } returns false

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.gigaAmDownloadFailed)
        assertTrue(!vm.uiState.value.gigaAmModelReady)
    }

    /** A re-entrant call while a download is already running must be a no-op. */
    @Test fun `downloadGigaAmModel ignores re-entry while in flight`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        coEvery { gigaAmModelManager.download(any()) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.downloadGigaAmModel() // re-entry while the first download is still in flight
        testDispatcher.scheduler.advanceUntilIdle()

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 1) { gigaAmModelManager.download(any()) }
    }

    /** deleteGigaAmModel() must cancel an in-flight download so a stale completion can't
     *  resurrect ready/progress state after delete (same stale-guard as deleteTtsVoice). */
    @Test fun `deleteGigaAmModel cancels in-flight download`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        coEvery { gigaAmModelManager.download(any()) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle() // download now in flight, awaiting gate

        vm.deleteGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(-1, vm.uiState.value.gigaAmDownloadProgress)
        assertTrue(!vm.uiState.value.gigaAmModelReady)
        assertTrue(!vm.uiState.value.gigaAmDownloadFailed)

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(-1, vm.uiState.value.gigaAmDownloadProgress)
        assertTrue(!vm.uiState.value.gigaAmModelReady)
        assertTrue(!vm.uiState.value.gigaAmDownloadFailed)

        coVerify(exactly = 1) { gigaAmModelManager.delete() }
    }

    /** A stale progress delivery arriving after deleteGigaAmModel() reset progress to idle
     *  must not resurrect an in-progress state. */
    @Test fun `late gigaAm progress callback after delete is ignored`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        val progressSlot = slot<(com.bydmate.app.voice.GigaAmModelManager.Phase, Int) -> Unit>()
        coEvery { gigaAmModelManager.download(capture(progressSlot)) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle() // download now in flight, awaiting gate

        vm.deleteGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        progressSlot.captured(com.bydmate.app.voice.GigaAmModelManager.Phase.UNPACK, 55) // stale delivery after delete reset state to idle

        assertEquals(-1, vm.uiState.value.gigaAmDownloadProgress)
    }

    /** The unpack stage must reach the UI as its own phase: labelling those minutes
     *  "Downloading" is what made the bar read as frozen on DiLink 3 (#stuck-at-99). */
    @Test fun `downloadGigaAmModel exposes the reported phase while in flight`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        val progressSlot = slot<(com.bydmate.app.voice.GigaAmModelManager.Phase, Int) -> Unit>()
        coEvery { gigaAmModelManager.download(capture(progressSlot)) } coAnswers {
            gate.await()
            Result.success(Unit)
        }
        coEvery { gigaAmModelManager.isReady() } returns true

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        progressSlot.captured(com.bydmate.app.voice.GigaAmModelManager.Phase.UNPACK, 94)
        assertEquals(94, vm.uiState.value.gigaAmDownloadProgress)
        assertEquals(
            com.bydmate.app.voice.GigaAmModelManager.Phase.UNPACK,
            vm.uiState.value.gigaAmDownloadPhase,
        )

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        // Idle again: no stale phase left to mislabel the next run.
        assertEquals(null, vm.uiState.value.gigaAmDownloadPhase)
    }

    @Test fun `storage failure surfaces the shortfall numbers in MB`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        val mb = 1024L * 1024L
        coEvery { gigaAmModelManager.download(any()) } returns Result.failure(
            com.bydmate.app.voice.GigaAmModelManager.InsufficientStorageException(
                requiredBytes = 500 * mb,
                availableBytes = 120 * mb,
            )
        )
        coEvery { gigaAmModelManager.isReady() } returns false

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.gigaAmDownloadFailed)
        assertEquals(
            com.bydmate.app.ui.settings.SpaceShortfall(requiredMb = 500, availableMb = 120),
            vm.uiState.value.gigaAmSpaceShortfall,
        )
    }

    @Test fun `non-storage failure leaves the shortfall unset`() = runTest {
        val gigaAmModelManager = mockk<com.bydmate.app.voice.GigaAmModelManager>(relaxed = true)
        coEvery { gigaAmModelManager.download(any()) } returns Result.failure(RuntimeException("boom"))
        coEvery { gigaAmModelManager.isReady() } returns false

        val vm = buildViewModel(gigaAmModelManager = gigaAmModelManager)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.downloadGigaAmModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue(vm.uiState.value.gigaAmDownloadFailed)
        assertEquals(null, vm.uiState.value.gigaAmSpaceShortfall)
    }

    /** #190: default is Yandex, the setter mirrors into the same voice prefs the dispatcher reads. */
    @Test fun `route navigator defaults to yandex and persists the choice`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(RouteNavigatorUris.YANDEX, vm.uiState.value.routeNavigator)

        vm.setRouteNavigator(RouteNavigatorUris.DGIS)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(RouteNavigatorUris.DGIS, vm.uiState.value.routeNavigator)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            RouteNavigatorUris.DGIS,
            ctx.getSharedPreferences(RouteNavigatorUris.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(RouteNavigatorUris.KEY_ROUTE_NAVIGATOR, "")
        )
    }

    /** #305: Waze persists and a fresh view model reads it back. */
    @Test fun `route navigator waze persists and reads back`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setRouteNavigator("waze")
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("waze", vm.uiState.value.routeNavigator)
        val ctx: Context = ApplicationProvider.getApplicationContext()
        assertEquals(
            "waze",
            ctx.getSharedPreferences(RouteNavigatorUris.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(RouteNavigatorUris.KEY_ROUTE_NAVIGATOR, "")
        )
        val reread = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals("waze", reread.uiState.value.routeNavigator)
    }

    /** The dump header must carry the choice: it is the only place a user log shows it. */
    @Test fun `the diagnostic header reports the chosen route navigator`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        vm.setRouteNavigator(RouteNavigatorUris.DGIS)
        testDispatcher.scheduler.advanceUntilIdle()

        // The header is written before the logcat pipe (which the test seam blows up on),
        // so the started file keeps the settings block even though the start itself fails.
        vm.startLogRecording()
        testDispatcher.scheduler.advanceUntilIdle()
        val header = awaitDiagnosticHeader()

        assertTrue(
            "the settings block must report the navigator, was:\n$header",
            header.contains("route_navigator=dgis"),
        )
    }

    /** Wave 1: the dump carries the agent section — tools and answer of the last turns. */
    @Test fun `the diagnostic header reports the agent journal`() = runTest {
        val journal = com.bydmate.app.voice.VoiceJournal()
        journal.add(
            com.bydmate.app.voice.VoiceJournalEntry(
                timestampMs = System.currentTimeMillis(),
                transcript = "закрой окна",
                route = com.bydmate.app.voice.VoiceJournalEntry.Route.AGENT,
                detail = "Окна закрыты",
                outcome = com.bydmate.app.voice.VoiceJournalEntry.Outcome.OK,
                tools = listOf(com.bydmate.app.agent.AgentToolOutcome("vehicle_control", true)),
                answer = "Окна закрыты",
            )
        )
        val vm = buildViewModel(voiceJournal = journal)
        testDispatcher.scheduler.advanceUntilIdle()

        vm.startLogRecording()
        testDispatcher.scheduler.advanceUntilIdle()
        val header = awaitDiagnosticHeader()

        assertTrue("no agent section, was:\n$header", header.contains("--- agent ---"))
        assertTrue("no tool line, was:\n$header", header.contains("vehicle_control:ok"))
        assertTrue("no answer line, was:\n$header", header.contains("answer: Окна закрыты"))
        assertTrue("no voice section, was:\n$header", header.contains("--- voice ---"))
        assertTrue("no counters, was:\n$header", header.contains("sessions=1 nlu_ok=0 automation_ok=0 agent=1 refused=0"))
        assertTrue("no session line, was:\n$header", header.contains("route=agent heard=\"закрой окна\" cmd=- reason=- result=ok"))
    }

    /** #237: the backup section names the bot and the chat tail, never the token. */
    @Test fun `the diagnostic header never contains the telegram token`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123456:SECRET-token-value"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "987654321"

        vm.startLogRecording()
        testDispatcher.scheduler.advanceUntilIdle()
        val header = awaitDiagnosticHeader()

        assertTrue("no auto backup section, was:\n$header", header.contains("--- auto backup ---"))
        assertTrue(header, header.contains("telegram: configured=yes bot=- chat=…4321"))
        assertFalse("token leaked into the dump", header.contains("SECRET-token-value"))
    }

    /** #238: the backup section prints the parts of the automatic and of the manual save. */
    @Test fun `the diagnostic header reports the backup parts`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        settingsDao.map[SettingsRepository.KEY_AUTO_BACKUP_PARTS] = "keys,tables"

        vm.startLogRecording()
        testDispatcher.scheduler.advanceUntilIdle()
        val header = awaitDiagnosticHeader()

        assertTrue(header, header.contains("parts: auto=tables,keys manual=tables,settings"))
    }

    /** The trace closes the header: what the app did before the recording, newest event last. */
    @Test fun `the diagnostic header ends with the trace, newest event last`() = runTest {
        val ptt = Trace.event(TraceArea.USER, "ptt", "listening" to false)
        Trace.event(TraceArea.VOICE, "session-start", by = ptt)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.startLogRecording()
        testDispatcher.scheduler.advanceUntilIdle()
        val header = awaitDiagnosticHeader(until = "voice  session-start #2 by=#1")

        val section = header.substringAfter("--- trace ---\n").substringBefore("===============================")
        val events = section.lines().filter { it.isNotBlank() && !it.startsWith("-- ") }.map { it.substringAfter(' ') }
        assertEquals(listOf("user   ptt listening=false #1", "voice  session-start #2 by=#1"), events)
        assertTrue(header, header.indexOf("--- last crash ---") < header.indexOf("--- trace ---"))
    }

    /**
     * Pins the whole header text as one string, so moving the writer into its own class cannot
     * change a character of what users send us. The reference is `diagnostic-dump/reference-header.txt`.
     */
    @Test fun `the diagnostic header text is pinned as a whole`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        // The header prints process-wide state that another test class in the same JVM may have left behind:
        // the self-heal history and the live state of the cluster projection object. Both start as on a cold start.
        com.bydmate.app.service.GrantSelfHeal.clearHistory()
        io.mockk.mockkObject(com.bydmate.app.cluster.ClusterProjectionManager)
        io.mockk.every { com.bydmate.app.cluster.ClusterProjectionManager.diag() } returns
            com.bydmate.app.cluster.ClusterProjectionManager.Diag(
                mode = com.bydmate.app.cluster.ClusterMode.OFF, projectedPackage = null, vdDisplayId = -1,
                directDisplayId = -1, overlayAttached = false, attemptInProgress = false, lastFailure = null,
                directDensityDpi = -1,
            )
        // Every time in the header is printed in the default zone: pin it so the test is the same on any machine.
        val zone = java.util.TimeZone.getDefault()
        java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("UTC"))
        try {
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).edit()
                .putString("tts_source", "minimax").putString("tts_voice", "anna").putString("agent_gender", "f")
                .putBoolean("voice_enabled", true).putInt("voice_keycode", 321).commit()
            ctx.getSharedPreferences(com.bydmate.app.service.BootReceiver.PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putString(com.bydmate.app.service.BootReceiver.KEY_CHAIN_LOG, "boot>worker>service").commit()
            ctx.getSharedPreferences(com.bydmate.app.hud.HudController.PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putBoolean(com.bydmate.app.hud.HudController.KEY_ENABLED, true).commit()
            val journal = com.bydmate.app.voice.VoiceJournal()
            journal.add(
                com.bydmate.app.voice.VoiceJournalEntry(
                    timestampMs = 1_700_000_000_000L,
                    transcript = "закрой окна",
                    route = com.bydmate.app.voice.VoiceJournalEntry.Route.AGENT,
                    detail = "Окна закрыты",
                    outcome = com.bydmate.app.voice.VoiceJournalEntry.Outcome.OK,
                    tools = listOf(com.bydmate.app.agent.AgentToolOutcome("vehicle_control", true)),
                    answer = "Окна закрыты",
                )
            )
            vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.EV
            val vm = buildViewModel(voiceJournal = journal)
            testDispatcher.scheduler.advanceUntilIdle()
            fillHeaderSettings()
            vm.setRouteNavigator(RouteNavigatorUris.DGIS)
            testDispatcher.scheduler.advanceUntilIdle()

            stubHeaderCollaborators()

            vm.startLogRecording()
            testDispatcher.scheduler.advanceUntilIdle()
            val header = awaitDiagnosticHeader(until = "===============================")
            // The only lines the set-up cannot fix; everything else is compared character for character.
            val normalized = header
                // timestamp: the moment the header was written.
                .replace(Regex("(?m)^timestamp: \\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$"), "timestamp: <now>")
                // app: the version name and code move with every release.
                .replace(Regex("(?m)^(app: \\S+) v\\S+ \\(code=\\d+\\)$"), "$1 v<version> (code=<code>)")
            val reference = javaClass.getResourceAsStream("/diagnostic-dump/reference-header.txt")!!
                .bufferedReader().use { it.readText() }
            assertEquals(reference, normalized)
        } finally {
            java.util.TimeZone.setDefault(zone)
            io.mockk.unmockkObject(com.bydmate.app.cluster.ClusterProjectionManager)
        }
    }

    /** The stored settings the pinned header prints; fixed values only. */
    private fun fillHeaderSettings() {
        settingsDao.map.putAll(
            mapOf(
                SettingsRepository.KEY_BATTERY_CAPACITY to "72,9",
                SettingsRepository.KEY_ABRP_ENABLED to "true",
                SettingsRepository.KEY_ABRP_USER_TOKEN to "abc12345",
                SettingsRepository.KEY_ABRP_CAR_MODEL to "byd:leopard3",
                SettingsRepository.KEY_CHARGING_BASELINE_SOC to "64",
                SettingsRepository.KEY_LAST_MILEAGE_KM to "12345.5",
                SettingsRepository.KEY_LAST_STATE_TS to "1700000000000",
                SettingsRepository.KEY_CATCHUP_JOURNAL to "2023-11-14 22:13:20 STILL_CHARGING soc=64",
                SettingsRepository.KEY_AUTO_BACKUP_PERIOD to "daily",
                SettingsRepository.KEY_AUTO_BACKUP_LAST_TS to "1700000000000",
                SettingsRepository.KEY_AUTO_BACKUP_LAST_RESULT to "ok",
                SettingsRepository.KEY_AUTO_BACKUP_PENDING_UPLOAD to "/sdcard/backup-1.zip",
                SettingsRepository.KEY_TG_BACKUP_TOKEN to "123456:SECRET",
                SettingsRepository.KEY_TG_BACKUP_CHAT_ID to "987654321",
                SettingsRepository.KEY_TG_BACKUP_BOT_NAME to "test_bot",
                SettingsRepository.KEY_DISABLE_NATIVE_ASSISTANT to "true",
                "trip1_reset_ts" to "1700000000000",
                "trip1_corr_km" to "1.5",
            )
        )
    }

    /** What the relaxed collaborators answer while the pinned header is written. */
    private fun stubHeaderCollaborators() {
        coEvery { ruleDao.getAllList() } returns listOf(
            com.bydmate.app.data.local.entity.RuleEntity(
                id = 7, name = "Morning", triggers = "[]", actions = "[]", lastTriggeredAt = 1_700_000_000_000L,
            )
        )
        coEvery { automationEngine.serviceStartDumpLine() } returns "service_start: fixed"
        coEvery { automationEngine.journalDumpLines() } returns listOf("journal line 1", "journal line 2")
        every { automationEngine.paramSnapshotLine(any()) } returns "params: fixed"
        every { hudController.status } returns kotlinx.coroutines.flow.MutableStateFlow(
            com.bydmate.app.hud.HudController.Status.ON
        )
        every { hudController.mode() } returns 2
        every { hudController.diag() } returns com.bydmate.app.hud.HudController.HudDiag(
            framesSent = 10, lastFrameTs = 20, lastRc = 0, nonZeroRcCount = 1,
        )
        every { blindSpotController.dumpLines() } returns listOf("blind line")
        every { clusterMusicBridge.dumpLines() } returns listOf("music line")
        coEvery { cloudOverWifiManager.dumpLine() } returns "cloud_over_wifi: fixed"
        coEvery { telegramReporter.diagnosticsLines() } returns listOf("reporter line")
        coEvery { fidPushChannel.diagnosticsSnapshot() } returns listOf("push line")
        coEvery { vehicleWriteLogDao.getLatest(any()) } returns listOf(
            com.bydmate.app.data.local.entity.VehicleWriteLogEntity(
                ts = 1_700_000_000_000L, actionName = "seat_heat", dev = 1, fid = 2, requested = 3,
                readback = 3, status = 0, error = null, validated = true,
            )
        )
        val pair = com.bydmate.app.split.SplitPair("pkg.narrow", "pkg.wide", com.bydmate.app.split.SplitSide.LEFT)
        every { splitPreferences.getLastPair() } returns pair
        every { splitPreferences.getMenuPair() } returns pair
        every { splitPreferences.getSessionPair() } returns pair
        every { splitPreferences.isFeatureEnabled() } returns true
        every { splitPreferences.getSteeringKeyCode() } returns 322
        every { splitSessionManager.state } returns kotlinx.coroutines.flow.MutableStateFlow<com.bydmate.app.split.SplitSessionState>(
            com.bydmate.app.split.SplitSessionState.Active(pair, 11, 12)
        )
        every { splitSessionManager.departedPanePkgs() } returns setOf("pkg.gone")
        every { windowChannelStore.winner() } returns com.bydmate.app.data.vehicle.WindowChannel.PERCENT
        every { helperBootstrap.daemonEverAlive() } returns true
        every { helperBootstrap.lastSpawnFailure() } returns com.bydmate.app.data.vehicle.HelperBootstrap.SpawnFailure(
            1_700_000_000_000L, com.bydmate.app.data.vehicle.HelperBootstrap.SpawnFailReason.ADB_UNREACHABLE, "detail one\ndetail two",
        )
        coEvery { helperClient.isAlive() } returns true
        coEvery { helperClient.readBatch(any()) } answers {
            firstArg<List<com.bydmate.app.data.vehicle.BatchReadItem>>().mapIndexed { i, _ -> 0 to (i % 3) }
        }
    }

    /** The header lands on the real Dispatchers.IO, which the test scheduler cannot advance.
     *  [until] is a text the finished header contains. */
    private fun awaitDiagnosticHeader(timeoutMs: Long = 10_000, until: String = "--- settings ---"): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val file = listOf(publicDumpDir(), fallbackDumpDir())
                .flatMap { it.listFiles()?.toList() ?: emptyList() }
                .filter { it.name.startsWith("bydmate_logs_") }
                .maxByOrNull { it.lastModified() }
            val text = file?.readText().orEmpty()
            if (text.contains(until)) return text
            Thread.sleep(10)
        }
        throw AssertionError("no diagnostic header was written within $timeoutMs ms")
    }

    /** A value written by an older build (or garbage) must not leak into the UI or the dispatcher. */
    @Test fun `an unknown stored navigator reads back as yandex`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        ctx.getSharedPreferences(RouteNavigatorUris.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(RouteNavigatorUris.KEY_ROUTE_NAVIGATOR, "2gis").commit()

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(RouteNavigatorUris.YANDEX, vm.uiState.value.routeNavigator)
    }

    @Test fun `testAgentModel on Answer sets result with seconds and answer prefix`() = runTest {
        coEvery { agentOrchestrator.ask(any()) } returns AgentResult.Answer("Заряд батареи 62 процента.")
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.testAgentModel()
        testDispatcher.scheduler.advanceUntilIdle()

        val result = vm.uiState.value.modelTestResult
        assertTrue(result != null)
        assertTrue(result!!.contains(Regex("""\d+\.\d""")))
        assertTrue(result.contains("Заряд батареи 62 процента."))
        assertTrue(!vm.uiState.value.modelTestRunning)
    }

    @Test fun `testAgentModel on Error sets result with error prefix`() = runTest {
        coEvery { agentOrchestrator.ask(any()) } returns AgentResult.Error("Не получилось связаться с сервером")
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.testAgentModel()
        testDispatcher.scheduler.advanceUntilIdle()

        val ctx: Context = ApplicationProvider.getApplicationContext()
        val expected = ctx.getString(
            com.bydmate.app.R.string.settings_error_with_message, "Не получилось связаться с сервером"
        )
        assertEquals(expected, vm.uiState.value.modelTestResult)
        assertTrue(!vm.uiState.value.modelTestRunning)
    }

    @Test fun `testAgentModel second tap while running is ignored`() = runTest {
        val gate = CompletableDeferred<Unit>()
        coEvery { agentOrchestrator.ask(any()) } coAnswers {
            gate.await()
            AgentResult.Answer("ok")
        }
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.testAgentModel()
        testDispatcher.scheduler.runCurrent() // in flight, suspended on gate
        assertTrue(vm.uiState.value.modelTestRunning)

        vm.testAgentModel() // second tap while running — must be ignored
        testDispatcher.scheduler.runCurrent()

        gate.complete(Unit)
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 1) { agentOrchestrator.ask(any()) }
    }

    // Wave O T3: stored "openai" tts_source must be migrated to "offline" on first load,
    // because the OpenAI TTS backend was removed (model not available on OpenRouter).
    @Test fun `stored openai tts_source is migrated to offline on load and prefs are rewritten`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
            .edit()
            .putString("tts_source", "openai")
            .apply()

        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("offline", vm.uiState.value.ttsSource)
        assertEquals(
            "offline",
            ctx.getSharedPreferences("voice", Context.MODE_PRIVATE).getString("tts_source", null)
        )
    }

    @Test
    fun `resetTripSourceDetection also clears the energydata import watermark (#348)`() = runTest {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        // A watermark poisoned by a future-dated energydata row, and a source fingerprint that
        // would make the next sync skip the unchanged file.
        settingsDao.map[SettingsRepository.KEY_LAST_ENERGYDATA_IMPORT_TS] = "4102444800" // 2100-01-01
        ctx.getSharedPreferences("energydata_sync", Context.MODE_PRIVATE).edit()
            .putLong("lastModified", 1L).putLong("fileSize", 2L).putString("filePath", "/x").commit()

        vm.resetTripSourceDetection()
        testDispatcher.scheduler.advanceUntilIdle()

        verify(exactly = 1) { energyDataDeadDetector.reset() }
        assertEquals(
            "reset must clear the import watermark",
            0L,
            SettingsRepository(settingsDao, mockk(relaxed = true)).getLastEnergyImportTs(),
        )
        assertFalse(
            "reset must also forget the source fingerprint so the next sync re-reads the file",
            ctx.getSharedPreferences("energydata_sync", Context.MODE_PRIVATE).contains("lastModified"),
        )
    }

    @Test
    fun `dumpFids calls ensureRunning before helperClient dumpFids (C-3)`() = runTest {
        // C-3: ensureRunning must be called before dumpFids so a stale old-format daemon is
        // replaced before the TX_DUMP_FIDS call is attempted.
        //
        // Anti-vacuity: removing helperBootstrap.ensureRunning() from SettingsViewModel.dumpFids()
        // makes "ensureRunning" absent from callOrder, failing the assertEquals assertion.
        val callOrder = mutableListOf<String>()
        coEvery { helperBootstrap.ensureRunning() } answers { callOrder += "ensureRunning"; true }
        coEvery { helperClient.dumpFids() } answers { callOrder += "dumpFids"; DumpFidsResult.BinderAbsent }
        val vm = buildViewModel()
        vm.dumpFids()
        awaitFidDumpDone(vm)
        assertEquals(
            "ensureRunning must be called before dumpFids",
            listOf("ensureRunning", "dumpFids"),
            callOrder,
        )
    }

    @Test
    fun `dumpFids sets unavailable error status when helperClient returns BinderAbsent`() = runTest {
        coEvery { helperClient.dumpFids() } returns DumpFidsResult.BinderAbsent
        val vm = buildViewModel()
        vm.dumpFids()
        // dumpFids() runs on the real Dispatchers.IO, which the test scheduler cannot advance.
        val status = awaitFidDumpDone(vm)
        // settings_fid_dump_error_unavailable renders as "демон недоступен" (RU) or "daemon unavailable" (EN).
        assertTrue(
            "BinderAbsent must map to unavailable string, was: $status",
            status.contains("daemon") || status.contains("демон"),
        )
    }

    @Test
    fun `dumpFids sets read-error status when helperClient returns ReadError`() = runTest {
        coEvery { helperClient.dumpFids() } returns DumpFidsResult.ReadError("status=-1 at chunk 0")
        val vm = buildViewModel()
        vm.dumpFids()
        // dumpFids() runs on the real Dispatchers.IO, which the test scheduler cannot advance.
        val status = awaitFidDumpDone(vm)
        // settings_fid_dump_error_read renders as "ошибка чтения: ..." (RU) or "read error: ..." (EN).
        // Also must NOT use the unavailable string (would be the wrong failure kind).
        assertTrue(
            "ReadError must map to read-error string, was: $status",
            status.contains("read error") || status.contains("ошибка чтения"),
        )
        assertFalse(
            "ReadError must not map to unavailable string, was: $status",
            status.contains("daemon") || status.contains("демон"),
        )
    }

    @Test
    fun `dumpFids sets empty-firmware status when helperClient returns Success with blank string`() = runTest {
        coEvery { helperClient.dumpFids() } returns DumpFidsResult.Success("")
        val vm = buildViewModel()
        vm.dumpFids()
        // dumpFids() runs on the real Dispatchers.IO, which the test scheduler cannot advance.
        val status = awaitFidDumpDone(vm)
        // Matches both English ("empty") and Russian ("пуст") renderings of the status string.
        assertTrue(
            "Success blank dump must show empty-firmware status, was: $status",
            status.contains("empty") || status.contains("пуст"),
        )
    }

    // ---------------------------------------------------------------------------
    // W6-F4: the dump must land straight in the public Download folder so the user
    // can reach it with a file manager or adb pull (filesDir was unreachable). No
    // subfolder: CSV export, backup, APK update and the log export all write there too.
    // ---------------------------------------------------------------------------

    private fun publicDumpDir(): File =
        android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        )

    private fun fallbackDumpDir(): File =
        ApplicationProvider.getApplicationContext<Context>().getExternalFilesDir(null)!!

    private fun dumpFilesIn(dir: File): List<File> =
        dir.listFiles { _, name -> name.startsWith("fid-dump-") && name.endsWith(".txt") }
            ?.toList() ?: emptyList()

    /** Download is shared with other exports — clear only our own dumps, never the folder. */
    private fun clearDumpsIn(dir: File) = dumpFilesIn(dir).forEach { it.delete() }

    @Test
    fun `openRestorePicker lists backups into the state, close clears it`() = runTest {
        val files = listOf(File("/sdcard/Download/bydmate_backup_2.zip"), File("/sdcard/Download/bydmate_backup_1.zip"))
        backupManager = mockk { every { listBackups() } returns files }
        val vm = buildViewModel().apply { ioDispatcher = testDispatcher }
        assertNull(vm.uiState.value.restoreCandidates)

        vm.openRestorePicker()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(files, vm.uiState.value.restoreCandidates)

        vm.closeRestorePicker()
        assertNull(vm.uiState.value.restoreCandidates)
    }

    @Test
    fun `a picked backup opens the parts dialog with the parts its manifest lists`() = runTest {
        val file = File("/sdcard/Download/bydmate_backup_1.zip")
        val parts = setOf(com.bydmate.app.data.backup.BackupPart.TABLES)
        backupManager = mockk { every { archiveParts(file) } returns parts }
        val vm = buildViewModel().apply { ioDispatcher = testDispatcher }

        vm.pickRestoreFile(file)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(RestoreChoice(file, parts), vm.uiState.value.restoreChoice)
        vm.dismissRestoreChoice()
        assertNull(vm.uiState.value.restoreChoice)
    }

    @Test
    fun `restoreConfig ignores a second restore while the first one runs`() = runTest {
        val file = File("/sdcard/Download/bydmate_backup_1.zip")
        val parts = setOf(com.bydmate.app.data.backup.BackupPart.TABLES)
        val calls = java.util.concurrent.atomic.AtomicInteger()
        backupManager = mockk { every { restore(file, parts) } answers { calls.incrementAndGet(); error("broken") } }
        val vm = buildViewModel().apply { ioDispatcher = testDispatcher }

        vm.restoreConfig(file, parts)
        assertTrue(vm.uiState.value.restoreInProgress)
        vm.restoreConfig(file, parts)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(1, calls.get())
        assertFalse(vm.uiState.value.restoreInProgress)
        assertTrue(vm.uiState.value.configStatus!!.contains("broken"))
    }

    @Test
    fun `openRestorePicker ignores repeated taps while a scan runs`() = runTest {
        val calls = java.util.concurrent.atomic.AtomicInteger()
        backupManager = mockk { every { listBackups() } answers { calls.incrementAndGet(); emptyList() } }
        val vm = buildViewModel().apply { ioDispatcher = testDispatcher }

        vm.openRestorePicker()          // job created, not yet run on StandardTestDispatcher
        vm.openRestorePicker()
        vm.openRestorePicker()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(1, calls.get())
    }

    @Test
    fun `closeRestorePicker during a scan drops the scan result`() = runTest {
        val files = listOf(File("/sdcard/Download/bydmate_backup_1.zip"))
        lateinit var vm: SettingsViewModel
        // The scan closes the picker from inside listBackups(): ensureActive() after it must drop the result.
        backupManager = mockk { every { listBackups() } answers { vm.closeRestorePicker(); files } }
        vm = buildViewModel().apply { ioDispatcher = testDispatcher }

        vm.openRestorePicker()
        testDispatcher.scheduler.advanceUntilIdle()

        assertNull(vm.uiState.value.restoreCandidates)
    }

    /**
     * dumpFids() runs on the real [Dispatchers.IO], so the test scheduler cannot advance it —
     * poll the status until it leaves the "in progress" state.
     */
    private fun awaitFidDumpDone(vm: SettingsViewModel, timeoutMs: Long = 10_000): String {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val inProgress = ctx.appLocalizedContext()
            .getString(com.bydmate.app.R.string.settings_fid_dump_in_progress)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val status = vm.uiState.value.fidDumpStatus
            if (status != null && status != inProgress) return status
            Thread.sleep(10)
        }
        throw AssertionError("dumpFids did not finish within $timeoutMs ms")
    }

    @Test
    fun `dumpFids writes into the public Download folder keeping the 3-line header (W6-F4)`() = runTest {
        // Anti-vacuity: any other target (filesDir, or a BYDMate/ subfolder) leaves Download
        // itself empty and the size assertion fails.
        clearDumpsIn(publicDumpDir())
        val dump = "FID_A=1\nFID_B=2\n"
        coEvery { helperClient.dumpFids() } returns DumpFidsResult.Success(dump)
        val vm = buildViewModel()

        vm.dumpFids()
        val status = awaitFidDumpDone(vm)

        val files = dumpFilesIn(publicDumpDir())
        assertEquals("dump must be written straight to Download, status was: $status", 1, files.size)
        val file = files.single()
        assertTrue(
            "file name must stay fid-dump-<yyyyMMdd-HHmmss>.txt, was ${file.name}",
            Regex("""fid-dump-\d{8}-\d{6}\.txt""").matches(file.name),
        )
        val lines = file.readText().lines()
        // Full structure, not just the prefix: dropping the version code, the timestamp, the
        // build id or the double space between model and build must fail the assertions.
        assertTrue(
            "line 1 must be 'BYDMate <name> (<code>), <yyyy-MM-dd HH:mm>', was: ${lines[0]}",
            Regex("""^BYDMate .+ \(\d+\), \d{4}-\d{2}-\d{2} \d{2}:\d{2}$""").matches(lines[0]),
        )
        assertTrue(
            "line 2 must be 'model: <model>  build: <build>' (double space), was: ${lines[1]}",
            Regex("""^model: .+ {2}build: .+$""").matches(lines[1]),
        )
        assertEquals("line 3 must be the separator", "---", lines[2])
        assertEquals("body must be the raw dump", dump, file.readText().substringAfter("---\n"))
        // Path shape only. The share sheet cannot be asserted here: Robolectric puts
        // getExternalStorageDirectory() under external-cache/ while the public Download lives
        // under external-files/, so <external-path path="Download/"> never matches in tests.
        // The fallback branch, whose root IS resolvable, carries the share assertion instead.
        assertTrue(
            "status must end with the visible path without a subfolder, was: $status",
            status.endsWith("Download/${file.name}"),
        )
    }

    @Test
    fun `dumpFids keeps a two-file rolling window in the public folder (W6-F4)`() = runTest {
        // Anti-vacuity: pointing the cleanup at any other folder leaves all 3 files here.
        val dir = publicDumpDir().apply { mkdirs() }
        clearDumpsIn(dir)
        val oldest = File(dir, "fid-dump-20200101-000000.txt").apply {
            writeText("oldest"); setLastModified(1_000_000L)
        }
        val newer = File(dir, "fid-dump-20200102-000000.txt").apply {
            writeText("newer"); setLastModified(2_000_000L)
        }
        coEvery { helperClient.dumpFids() } returns DumpFidsResult.Success("FID_A=1\n")
        val vm = buildViewModel()

        vm.dumpFids()
        val status = awaitFidDumpDone(vm)

        val names = dumpFilesIn(dir).map { it.name }
        assertEquals("rolling window must keep exactly 2 dumps, was $names (status: $status)", 2, names.size)
        assertFalse("oldest dump must be deleted", oldest.exists())
        assertTrue("most recent previous dump must survive", newer.exists())
    }

    @Test
    fun `dumpFids falls back to app external files dir when public folder is unavailable (W6-F4)`() = runTest {
        // Force the public candidate to fail by making Download read-only. (Replacing it with a
        // regular file does not work: the Robolectric shadow re-creates the public dir on every
        // getExternalStoragePublicDirectory() call.)
        val publicDir = publicDumpDir().apply { mkdirs(); setWritable(false) }
        assertFalse(
            "precondition: Download must be non-writable for this test (are you running as root?)",
            publicDir.canWrite(),
        )
        clearDumpsIn(fallbackDumpDir())
        try {
            coEvery { helperClient.dumpFids() } returns DumpFidsResult.Success("FID_A=1\n")
            val vm = buildViewModel()

            vm.dumpFids()
            val status = awaitFidDumpDone(vm)

            val files = dumpFilesIn(fallbackDumpDir())
            assertEquals("dump must land in the getExternalFilesDir fallback, status: $status", 1, files.size)
            assertFalse(
                "fallback must not surface an error, status: $status",
                status.contains("Ошибка") || status.contains("Error"),
            )
            assertTrue("status must name the saved file, was: $status", status.contains(files.single().name))
        } finally {
            publicDir.setWritable(true)
        }
    }

    // --- Tariff periods: the unique start date and the reach of a recalculation ---

    private val augustStart = 1_754_006_400_000L   // 01.08.2026
    private val septemberStart = 1_756_684_800_000L // 01.09.2026

    private fun twoPeriods() = FakeTariffPeriodDao(
        listOf(
            TariffPeriodEntity(id = 1, startTs = augustStart, homeRate = 0.10, dcRate = 0.50),
            TariffPeriodEntity(id = 2, startTs = septemberStart, homeRate = 0.20, dcRate = 0.60),
        )
    )

    @Test
    fun `saving a period onto a date another one holds is refused instead of crashing`() = runTest {
        val dao = twoPeriods()
        tariffPeriodDaoOverride = dao
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.saveTariffPeriod(dao.rows.first { it.id == 2L }.copy(startTs = augustStart))
        testDispatcher.scheduler.advanceUntilIdle()

        assertTrue("the dialog must say why", vm.uiState.value.tariffPeriodError != null)
        assertEquals(septemberStart, dao.rows.first { it.id == 2L }.startTs)
        assertEquals(2, dao.rows.size)
    }

    // The earliest period also prices everything before its own date, so editing or deleting
    // it has to re-price the whole history, not just the span from its start.
    @Test
    fun `editing the earliest period recalculates the whole history`() = runTest {
        val dao = twoPeriods()
        tariffPeriodDaoOverride = dao
        val calculator = mockk<com.bydmate.app.domain.cost.CostCalculator>(relaxed = true)
        exportCostCalculator = calculator
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.saveTariffPeriod(dao.rows.first { it.id == 1L }.copy(homeRate = 0.99))
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify { calculator.recalculate(0L, Long.MAX_VALUE) }
    }

    @Test
    fun `deleting the earliest period recalculates the whole history`() = runTest {
        val dao = twoPeriods()
        tariffPeriodDaoOverride = dao
        val calculator = mockk<com.bydmate.app.domain.cost.CostCalculator>(relaxed = true)
        exportCostCalculator = calculator
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.deleteTariffPeriod(dao.rows.first { it.id == 1L })
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify { calculator.recalculate(0L, Long.MAX_VALUE) }
        assertEquals(1, dao.rows.size)
    }

    @Test
    fun `editing a later period recalculates only from its own date`() = runTest {
        val dao = twoPeriods()
        tariffPeriodDaoOverride = dao
        val calculator = mockk<com.bydmate.app.domain.cost.CostCalculator>(relaxed = true)
        exportCostCalculator = calculator
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.saveTariffPeriod(dao.rows.first { it.id == 2L }.copy(homeRate = 0.42))
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify { calculator.recalculate(septemberStart, Long.MAX_VALUE) }
    }

    // DM-i (#184): the litre price is part of a period, so a new price re-prices from its date only.
    @Test
    fun `a new period with a litre price recalculates only from its own date`() = runTest {
        val dao = twoPeriods()
        tariffPeriodDaoOverride = dao
        val calculator = mockk<com.bydmate.app.domain.cost.CostCalculator>(relaxed = true)
        exportCostCalculator = calculator
        vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.HYBRID
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        val octoberStart = 1_759_276_800_000L // 01.10.2026

        vm.saveTariffPeriod(
            TariffPeriodEntity(startTs = octoberStart, homeRate = 0.20, dcRate = 0.60, fuelPricePerLiter = 2.5)
        )
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 1) { calculator.recalculate(octoberStart, Long.MAX_VALUE) }
        coVerify(exactly = 0) { calculator.recalculate(0L, any()) }
        assertEquals(2.5, dao.rows.single { it.startTs == octoberStart }.fuelPricePerLiter!!, 0.0)
        assertNull(dao.rows.single { it.startTs == septemberStart }.fuelPricePerLiter)
    }

    // --- Telegram backup bot «Проверить» (#237) ---

    private fun tgSinkFake(): com.bydmate.app.data.backup.TelegramBackupSink = mockk<com.bydmate.app.data.backup.TelegramBackupSink>().also {
        telegramBackupSink = it
    }

    private fun checkToken(vm: SettingsViewModel, token: String) {
        vm.updateTgBackupToken(token)
        vm.checkTelegramBackup()
        testDispatcher.scheduler.advanceUntilIdle()
    }

    @Test
    fun `telegram check with a rejected token shows the reason and stores nothing`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("bad") } returns Result.failure(
            com.bydmate.app.data.backup.TelegramSinkException(com.bydmate.app.data.backup.TelegramError.BAD_TOKEN, 401)
        )
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        checkToken(vm, " bad ")

        val ctx: Context = ApplicationProvider.getApplicationContext()
        val state = vm.uiState.value
        assertFalse(state.tgBackupChecking)
        assertEquals("bad", state.tgBackupToken)
        val reason = ctx.getString(com.bydmate.app.R.string.settings_tg_error_bad_token)
        assertTrue(state.tgBackupStatus!!, state.tgBackupStatus!!.contains(reason))
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        coVerify(exactly = 0) { sink.findLinkChat(any(), any()) }
    }

    private val ctxForTg: Context get() = ApplicationProvider.getApplicationContext()

    @Test
    fun `first check of a new bot moves to the code step and stores nothing`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        checkToken(vm, "123:abc")

        val code = vm.uiState.value.tgBackupCode!!
        assertTrue(code, Regex("\\d{6}").matches(code))
        assertEquals("my_car_bot", vm.uiState.value.tgBackupBotName)
        assertNull(vm.uiState.value.tgBackupStatus)
        assertNull(vm.uiState.value.tgBackupBinding)
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        coVerify(exactly = 0) { sink.findLinkChat(any(), any()) }
    }

    @Test
    fun `check before the code was sent keeps the same code and stores nothing`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        coEvery { sink.findLinkChat("123:abc", any()) } returns Result.success(null)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        checkToken(vm, "123:abc")
        val code = vm.uiState.value.tgBackupCode!!

        checkToken(vm, "123:abc")

        assertEquals(code, vm.uiState.value.tgBackupCode)
        assertEquals(
            ctxForTg.getString(com.bydmate.app.R.string.settings_tg_backup_code_not_received),
            vm.uiState.value.tgBackupStatus,
        )
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        coVerify(exactly = 0) { sink.sendMessage(any(), any(), any()) }
    }

    @Test
    fun `chat that sent the code is greeted and then stored`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        coEvery { sink.sendMessage("123:abc", 777L, any()) } returns Result.success(Unit)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        checkToken(vm, "123:abc")
        val code = vm.uiState.value.tgBackupCode!!
        coEvery { sink.findLinkChat("123:abc", code) } returns
            Result.success(com.bydmate.app.data.backup.TelegramChat(777L, "Andy @andy_s"))

        checkToken(vm, "123:abc")

        assertEquals(TgBackupBinding("my_car_bot", "Andy @andy_s"), vm.uiState.value.tgBackupBinding)
        assertNull(vm.uiState.value.tgBackupStatus)
        assertNull(vm.uiState.value.tgBackupCode)
        assertEquals("123:abc", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        assertEquals("my_car_bot", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME])
        assertEquals("777", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
        assertEquals("Andy @andy_s", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME])
        coVerify(exactly = 1) {
            sink.sendMessage("123:abc", 777L, ctxForTg.getString(com.bydmate.app.R.string.settings_tg_backup_greeting))
        }
    }

    @Test
    fun `failed greeting stores nothing and shows the reason`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        coEvery { sink.findLinkChat("123:abc", any()) } returns
            Result.success(com.bydmate.app.data.backup.TelegramChat(777L, "Andy"))
        coEvery { sink.sendMessage(any(), any(), any()) } returns Result.failure(
            com.bydmate.app.data.backup.TelegramSinkException(com.bydmate.app.data.backup.TelegramError.HTTP, 403)
        )
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        checkToken(vm, "123:abc")

        checkToken(vm, "123:abc")

        val reason = ctxForTg.getString(com.bydmate.app.R.string.settings_tg_error_http, "403")
        assertTrue(vm.uiState.value.tgBackupStatus!!, vm.uiState.value.tgBackupStatus!!.contains(reason))
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
    }

    @Test
    fun `re-checking a bound bot keeps its chat without a code`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        coEvery { sink.sendMessage("123:abc", 777L, any()) } returns Result.success(Unit)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME] = "Andy"

        checkToken(vm, "123:abc")

        assertNull(vm.uiState.value.tgBackupCode)
        assertEquals("777", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
        assertEquals("Andy", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME])
        coVerify(exactly = 0) { sink.findLinkChat(any(), any()) }
        coVerify(exactly = 1) { sink.sendMessage("123:abc", 777L, any()) }
    }

    @Test
    fun `failed chat lookup keeps the previously connected bot untouched`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("456:new") } returns Result.success("new_bot")
        coEvery { sink.findLinkChat("456:new", any()) } returns Result.failure(
            com.bydmate.app.data.backup.TelegramSinkException(com.bydmate.app.data.backup.TelegramError.WEBHOOK, 409)
        )
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME] = "my_car_bot"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
        checkToken(vm, "456:new")

        checkToken(vm, "456:new")

        val reason = ctxForTg.getString(com.bydmate.app.R.string.settings_tg_error_webhook)
        assertTrue(vm.uiState.value.tgBackupStatus!!, vm.uiState.value.tgBackupStatus!!.contains(reason))
        assertEquals("123:abc", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        assertEquals("my_car_bot", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME])
        assertEquals("777", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
    }

    @Test
    fun `token edited during the check makes its result ignored`() = runTest {
        val sink = tgSinkFake()
        lateinit var vm: SettingsViewModel
        coEvery { sink.getMe("123:abc") } returns Result.success("my_car_bot")
        coEvery { sink.findLinkChat("123:abc", any()) } returns
            Result.success(com.bydmate.app.data.backup.TelegramChat(777L, "Andy"))
        coEvery { sink.sendMessage(any(), any(), any()) } coAnswers {
            vm.updateTgBackupToken("999:other")
            Result.success(Unit)
        }
        vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        checkToken(vm, "123:abc")

        vm.checkTelegramBackup()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.tgBackupChecking)
        assertNull(vm.uiState.value.tgBackupStatus)
        assertNull(vm.uiState.value.tgBackupBinding)
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        assertNull(settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
    }

    @Test
    fun `a connected bot opens on the done step, back on the code step returns to the token`() = runTest {
        // The stored bot is read by the init coroutine, which runs on the first advance.
        val connected = buildViewModel()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME] = "my_car_bot"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME] = "Andy"
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(TgBackupBinding("my_car_bot", "Andy"), connected.uiState.value.tgBackupBinding)

        val sink = tgSinkFake()
        coEvery { sink.getMe("456:new") } returns Result.success("new_bot")
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        checkToken(vm, "456:new")
        vm.cancelTelegramCode()

        assertNull(vm.uiState.value.tgBackupCode)
        assertNull(vm.uiState.value.tgBackupStatus)
        assertEquals("456:new", vm.uiState.value.tgBackupToken)
    }

    @Test
    fun `disconnect during a running check cancels it and nothing is stored`() = runTest {
        val sink = tgSinkFake()
        coEvery { sink.getMe("123:abc") } coAnswers { kotlinx.coroutines.awaitCancellation() }
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        checkToken(vm, "123:abc")
        assertTrue(vm.uiState.value.tgBackupChecking)
        vm.disconnectTelegramBackup()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.tgBackupChecking)
        assertNull(vm.uiState.value.tgBackupStatus)
        assertEquals("", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        coVerify(exactly = 0) { sink.findLinkChat(any(), any()) }
    }

    @Test
    fun `telegram disconnect clears token, chat and bot name`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME] = "my_car_bot"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME] = "Andy"

        vm.disconnectTelegramBackup()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME])
        assertEquals("", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN])
        assertEquals("", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID])
        assertEquals("", settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME])
        assertEquals("", vm.uiState.value.tgBackupToken)
        assertNull(vm.uiState.value.tgBackupBinding)
    }

    // --- «Отправить в Telegram» for a saved log (#324) ---

    private fun savedLog(bytes: Long = 10): File =
        File.createTempFile("bydmate_logs_", ".txt").apply {
            deleteOnExit()
            java.io.RandomAccessFile(this, "rw").use { it.setLength(bytes) }
        }

    /** A VM whose recorder goes idle -> recording -> stopped at [log]; [connected] stores a bound bot. */
    private fun vmWithStoppedLog(log: File, connected: Boolean = true): SettingsViewModel {
        val recorder = kotlinx.coroutines.flow.MutableStateFlow(com.bydmate.app.diagnostics.LogRecorder.State())
        logRecorderState = recorder
        val vm = buildViewModel()
        if (connected) {
            settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
            settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
            settingsDao.map[SettingsRepository.KEY_TG_BACKUP_BOT_NAME] = "my_car_bot"
            settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_NAME] = "Andy"
        }
        testDispatcher.scheduler.advanceUntilIdle()
        recorder.value = com.bydmate.app.diagnostics.LogRecorder.State(isRecording = true, filePath = log.absolutePath)
        testDispatcher.scheduler.advanceUntilIdle()
        assertFalse(vm.uiState.value.canSendLogToTelegram)
        recorder.value = com.bydmate.app.diagnostics.LogRecorder.State(
            lastStopped = com.bydmate.app.diagnostics.LogRecorder.Stopped(log.absolutePath, 0),
        )
        testDispatcher.scheduler.advanceUntilIdle()
        return vm
    }

    @Test
    fun `the send button shows only for a saved log with a connected bot`() = runTest {
        val log = savedLog()
        assertTrue(vmWithStoppedLog(log).uiState.value.canSendLogToTelegram)
        assertFalse(vmWithStoppedLog(log, connected = false).uiState.value.canSendLogToTelegram)

        logRecorderState = null
        val idle = buildViewModel()
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_TOKEN] = "123:abc"
        settingsDao.map[SettingsRepository.KEY_TG_BACKUP_CHAT_ID] = "777"
        testDispatcher.scheduler.advanceUntilIdle()
        assertFalse(idle.uiState.value.canSendLogToTelegram)
    }

    @Test
    fun `sending a saved log uploads it once with the file name as caption`() = runTest {
        val log = savedLog()
        val sink = tgSinkFake()
        coEvery { sink.sendDocument(any(), any(), any(), any()) } returns Result.success(Unit)
        val vm = vmWithStoppedLog(log)

        vm.sendLogToTelegram()
        vm.sendLogToTelegram()
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 1) { sink.sendDocument("123:abc", 777L, log, log.name) }
        assertFalse(vm.uiState.value.logSending)
        assertEquals(
            ctxForTg.getString(com.bydmate.app.R.string.settings_log_tg_sent),
            vm.uiState.value.logSaveStatus,
        )
    }

    @Test
    fun `a failed log upload names the reason`() = runTest {
        val log = savedLog()
        val sink = tgSinkFake()
        coEvery { sink.sendDocument(any(), any(), any(), any()) } returns Result.failure(
            com.bydmate.app.data.backup.TelegramSinkException(com.bydmate.app.data.backup.TelegramError.NO_NETWORK)
        )
        val vm = vmWithStoppedLog(log)

        vm.sendLogToTelegram()
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.logSending)
        val reason = ctxForTg.getString(com.bydmate.app.R.string.settings_tg_error_no_network)
        assertEquals(
            ctxForTg.getString(com.bydmate.app.R.string.settings_log_tg_failed, reason),
            vm.uiState.value.logSaveStatus,
        )
    }

    @Test
    fun `a log over the Telegram limit is not uploaded`() = runTest {
        val log = savedLog(com.bydmate.app.data.backup.TelegramBackupSink.MAX_UPLOAD_BYTES + 1)
        val sink = tgSinkFake()
        val vm = vmWithStoppedLog(log)

        vm.sendLogToTelegram()
        testDispatcher.scheduler.advanceUntilIdle()

        coVerify(exactly = 0) { sink.sendDocument(any(), any(), any(), any()) }
        assertEquals(
            ctxForTg.getString(com.bydmate.app.R.string.settings_log_tg_too_big),
            vm.uiState.value.logSaveStatus,
        )
    }

    @Test
    fun `an automatic log upload shows its result under the log row`() = runTest {
        val log = savedLog()
        val sink = tgSinkFake()
        coEvery { sink.sendDocument(any(), any(), any(), any()) } returns Result.success(Unit)
        val vm = vmWithStoppedLog(log)

        logTelegramSender.send(log)
        testDispatcher.scheduler.advanceUntilIdle()

        assertFalse(vm.uiState.value.logSending)
        assertEquals(
            ctxForTg.getString(com.bydmate.app.R.string.settings_log_tg_sent),
            vm.uiState.value.logSaveStatus,
        )
    }

    @Test
    fun `the log auto-send switch is stored and read back`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertFalse(vm.uiState.value.tgLogAutoSendEnabled)

        vm.setTgLogAutoSendEnabled(true)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals("true", settingsDao.map[SettingsRepository.KEY_TG_LOG_AUTO_SEND])
        assertTrue(vm.uiState.value.tgLogAutoSendEnabled)
    }
}
