package com.bydmate.app.voice

import com.bydmate.app.diagnostics.TraceRecorder
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import io.mockk.verifyOrder
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import java.util.concurrent.Executor

/**
 * Segmentation logic tests for GigaAmAsrEngine, driven entirely through fake
 * RecognizerHandle/VadHandle seams -- the sherpa-onnx JNI classes are never touched.
 */
class GigaAmSegmenterTest {

    @get:Rule val trace = TraceRecorder()

    private fun readyModelManager(): GigaAmModelManager =
        mockk<GigaAmModelManager>(relaxed = true).also { every { it.isReady() } returns true }

    private fun notReadyModelManager(): GigaAmModelManager =
        mockk<GigaAmModelManager>(relaxed = true).also { every { it.isReady() } returns false }

    // Scripts one isSpeechDetected()/segment outcome per acceptWaveform() call, in order.
    // Out-of-range calls repeat the last entry (needed for the infinite-flow cancellation test).
    // Default (no args): silence forever, no segment -- fine for tests that only care about
    // recognizer/vad instance counts, not transcription content.
    private class FakeVadHandle(
        private val perFrame: List<FrameScript> = listOf(FrameScript(speech = false)),
    ) : VadHandle {
        data class FrameScript(val speech: Boolean, val segment: FloatArray? = null)

        private var idx = -1
        private var pendingSegment: FloatArray? = null
        var closed = false

        private fun current() = perFrame.getOrElse(idx) { perFrame.last() }

        override fun acceptWaveform(samples: FloatArray) {
            idx++
            current().segment?.let { pendingSegment = it }
        }

        override fun isSpeechDetected(): Boolean = current().speech
        override fun empty(): Boolean = pendingSegment == null
        override fun front(): FloatArray = pendingSegment!!
        override fun pop() { pendingSegment = null }
        override fun close() { closed = true }
    }

    private class FakeRecognizerHandle(
        private val text: String = "",
        private val onClose: () -> Unit = {},
    ) : RecognizerHandle {
        var closed = false
        var lastSamples: FloatArray? = null
        override fun decode(samples: FloatArray): String {
            lastSamples = samples
            return text
        }
        override fun close() { closed = true; onClose() }
    }

    @Test fun `speech then silence emits exactly one utterance with recognizer text`() = runTest {
        val segment = floatArrayOf(0.1f, 0.2f)
        val vad = FakeVadHandle(listOf(
            FakeVadHandle.FrameScript(speech = true),
            FakeVadHandle.FrameScript(speech = true),
            FakeVadHandle.FrameScript(speech = false, segment = segment),
        ))
        val recognizer = FakeRecognizerHandle("привет")
        val engine = GigaAmAsrEngine(readyModelManager(), { recognizer }, { vad })

        val events = engine.transcribe(List(3) { ShortArray(320) }.asFlow()).toList()

        val utterances = events.filterIsInstance<ContinuousAsrEvent.Utterance>()
        assertEquals(1, utterances.size)
        assertEquals("привет", utterances[0].text)
        assertSame(segment, recognizer.lastSamples)
    }

    @Test fun `silence ticks grow monotonically over 1000ms of silence`() = runTest {
        // 320 samples at 16kHz = 20ms/frame; 50 frames = 1000ms.
        val vad = FakeVadHandle(List(50) { FakeVadHandle.FrameScript(speech = false) })
        val engine = GigaAmAsrEngine(readyModelManager(), { FakeRecognizerHandle("") }, { vad })

        val ticks = engine.transcribe(List(50) { ShortArray(320) }.asFlow())
            .filterIsInstance<ContinuousAsrEvent.SilenceTick>()
            .toList()

        assertEquals(50, ticks.size)
        assertEquals(20L, ticks.first().silentMs)
        assertEquals(1000L, ticks.last().silentMs)
        for (i in 1 until ticks.size) {
            assertTrue(ticks[i].silentMs > ticks[i - 1].silentMs)
        }
    }

    @Test fun `speech start emits SpeechStart exactly once on the silence-to-speech transition`() = runTest {
        val vad = FakeVadHandle(listOf(
            FakeVadHandle.FrameScript(speech = false),
            FakeVadHandle.FrameScript(speech = true),
        ))
        val engine = GigaAmAsrEngine(readyModelManager(), { FakeRecognizerHandle("") }, { vad })

        val events = engine.transcribe(List(2) { ShortArray(320) }.asFlow()).toList()

        assertEquals(1, events.filterIsInstance<ContinuousAsrEvent.SpeechStart>().size)
    }

    // Wave G Task 1: the recognizer is now cached across collections (see
    // recognizer_created_once_across_two_collections_vad_per_collection below), so it is no
    // longer closed on cancellation/failure paths -- only the per-collection VAD is.

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test fun `cancelling collection closes its vad, recognizer stays cached`() = runTest {
        val vad = FakeVadHandle(listOf(FakeVadHandle.FrameScript(speech = false)))
        val recognizer = FakeRecognizerHandle("")
        val engine = GigaAmAsrEngine(readyModelManager(), { recognizer }, { vad })
        val pcm = flow { while (true) { emit(ShortArray(320)); delay(10) } }

        val job = launch { engine.transcribe(pcm).collect {} }
        advanceTimeBy(50)
        job.cancelAndJoin()

        assertTrue(vad.closed)
        assertFalse(recognizer.closed)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test fun `overlapping collections each own a vad but share the cached recognizer`() = runTest {
        // Pins the per-collection VAD scoping: two overlapping collections of the SAME returned
        // cold Flow must each own their own VAD (transcribe()-level shared variables made the
        // collections close one pair twice and leak the other) while sharing one recognizer.
        val vads = mutableListOf<FakeVadHandle>()
        val recognizers = mutableListOf<FakeRecognizerHandle>()
        val engine = GigaAmAsrEngine(
            readyModelManager(),
            { FakeRecognizerHandle("").also { recognizers += it } },
            { FakeVadHandle(listOf(FakeVadHandle.FrameScript(speech = false))).also { vads += it } },
        )
        val stream = engine.transcribe(flow { repeat(10) { emit(ShortArray(320)); delay(10) } })

        val jobA = launch { stream.collect {} }
        advanceTimeBy(15)
        val jobB = launch { stream.collect {} }
        jobA.join()
        jobB.join()

        assertEquals(2, vads.size)
        assertEquals(1, recognizers.size)
        assertTrue(vads.all { it.closed })
        assertFalse(recognizers.first().closed)
    }

    @Test fun `vad factory failure leaves the already-cached recognizer open`() = runTest {
        val recognizer = FakeRecognizerHandle("")
        val engine = GigaAmAsrEngine(
            readyModelManager(),
            { recognizer },
            { error("vad init failed") },
        )

        runCatching { engine.transcribe(List(1) { ShortArray(320) }.asFlow()).toList() }

        assertFalse(recognizer.closed)
    }

    @Test fun `recognizer stays cached even when vad close throws`() = runTest {
        val recognizer = FakeRecognizerHandle("")
        val vad = object : VadHandle by FakeVadHandle(listOf(FakeVadHandle.FrameScript(speech = false))) {
            override fun close() = error("vad close failed")
        }
        val engine = GigaAmAsrEngine(readyModelManager(), { recognizer }, { vad })

        runCatching { engine.transcribe(List(1) { ShortArray(320) }.asFlow()).toList() }

        assertFalse(recognizer.closed)
    }

    // --- Wave G Task 1: recognizer cached across sessions, VAD stays per-collection ---

    @Test
    fun recognizer_created_once_across_two_collections_vad_per_collection() = runTest {
        var recognizerCreations = 0
        var vadCreations = 0
        var recognizerClosed = 0
        val engine = GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = { recognizerCreations++; FakeRecognizerHandle(onClose = { recognizerClosed++ }) },
            vadFactory = { vadCreations++; FakeVadHandle() },
        )
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        assertEquals(1, recognizerCreations)
        assertEquals(2, vadCreations)
        assertEquals(0, recognizerClosed)   // cached recognizer is NOT closed in finally
    }

    // --- Task 5: pre-warm the recognizer so the first PTT's transcribe() doesn't pay the
    // cold model-load cost before the mic starts recording. ---

    @Test fun `warmUp builds recognizer once and transcribe reuses it`() = runTest {
        var recognizerCreations = 0
        val engine = GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = { recognizerCreations++; FakeRecognizerHandle() },
            vadFactory = { FakeVadHandle() },
        )

        engine.warmUp()
        assertEquals(1, recognizerCreations)

        engine.transcribe(flowOf(ShortArray(160))).collect {}
        assertEquals(1, recognizerCreations)   // reused, not rebuilt
    }

    @Test fun `warmUp is a no-op when model files absent`() = runTest {
        var recognizerCreations = 0
        val engine = GigaAmAsrEngine(
            modelManager = notReadyModelManager(),
            recognizerFactory = { recognizerCreations++; FakeRecognizerHandle() },
            vadFactory = { FakeVadHandle() },
        )

        engine.warmUp()

        assertEquals(0, recognizerCreations)
    }

    // --- ASR crash-loop guard (field defect: Sea Lion 07, corrupt model -> SIGABRT loop) ---

    @Test fun `tripped guard reports not ready and blocks every native load path`() = runTest {
        val guard = mockk<AsrLoadGuard>(relaxed = true)
        every { guard.isTripped() } returns true
        var recognizerCreations = 0
        var vadCreations = 0
        val engine = GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = { recognizerCreations++; FakeRecognizerHandle() },
            vadFactory = { vadCreations++; FakeVadHandle() },
            loadGuard = guard,
        )

        assertFalse(engine.isReady())
        engine.warmUp()
        engine.transcribe(flowOf(ShortArray(160))).collect {}

        assertEquals(0, recognizerCreations)
        assertEquals(0, vadCreations)
    }

    @Test fun `successful loads bracket the guard - begin then success per artifact`() = runTest {
        val guard = mockk<AsrLoadGuard>(relaxed = true)
        every { guard.isTripped() } returns false
        val engine = GigaAmAsrEngine(
            readyModelManager(), { FakeRecognizerHandle() }, { FakeVadHandle() }, guard)

        engine.transcribe(flowOf(ShortArray(160))).collect {}

        verifyOrder {
            guard.noteLoadBegin(AsrLoadGuard.ARTIFACT_RECOGNIZER)
            guard.noteLoadSuccess(AsrLoadGuard.ARTIFACT_RECOGNIZER)
            guard.noteLoadBegin(AsrLoadGuard.ARTIFACT_VAD)
            guard.noteLoadSuccess(AsrLoadGuard.ARTIFACT_VAD)
        }
    }

    @Test fun `recognizer factory failure leaves begin without success - the crash signature`() = runTest {
        val guard = mockk<AsrLoadGuard>(relaxed = true)
        every { guard.isTripped() } returns false
        val engine = GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = { error("native load died") },
            vadFactory = { FakeVadHandle() },
            loadGuard = guard,
        )

        engine.warmUp()   // swallows the failure via its own runCatching

        verify { guard.noteLoadBegin(AsrLoadGuard.ARTIFACT_RECOGNIZER) }
        verify(exactly = 0) { guard.noteLoadSuccess(any()) }
    }

    @Test fun `blank recognizer text does not emit an utterance`() = runTest {
        val vad = FakeVadHandle(listOf(
            FakeVadHandle.FrameScript(speech = true),
            FakeVadHandle.FrameScript(speech = false, segment = floatArrayOf(0.1f)),
        ))
        val recognizer = FakeRecognizerHandle("")
        val engine = GigaAmAsrEngine(readyModelManager(), { recognizer }, { vad })

        val events = engine.transcribe(List(2) { ShortArray(320) }.asFlow()).toList()

        assertTrue(events.filterIsInstance<ContinuousAsrEvent.Utterance>().isEmpty())
    }

    // --- Android 10 head units (PR #261): one VAD is built ahead, so a session's first frames go
    // into a ready VAD instead of waiting for its construction. Other cars keep the path above. ---

    /** Holds the background builds until the test runs them. */
    private class ManualExecutor : Executor {
        val pending = mutableListOf<Runnable>()
        override fun execute(command: Runnable) { pending += command }
        fun runAll() {
            val jobs = pending.toList()
            pending.clear()
            jobs.forEach { it.run() }
        }
    }

    private fun warmEngine(
        vads: MutableList<FakeVadHandle>,
        background: Executor,
        recognizerFactory: () -> RecognizerHandle = { FakeRecognizerHandle() },
    ) =
        GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = recognizerFactory,
            vadFactory = { FakeVadHandle().also { vads += it } },
            warmVad = true,
            prewarmExecutor = background,
        )

    @Test fun `warm vad - warmUp builds the recognizer and one spare vad`() = runTest {
        val vads = mutableListOf<FakeVadHandle>()
        var recognizerCreations = 0
        val engine = warmEngine(vads, ManualExecutor()) { recognizerCreations++; FakeRecognizerHandle() }
        assertTrue(engine.requiresWarmBeforeListening())
        assertFalse(engine.isWarm())

        engine.warmUp()
        engine.warmUp()

        assertEquals(1, recognizerCreations)
        assertEquals(1, vads.size)
        assertFalse(vads.single().closed)
        assertTrue(engine.isWarm())
    }

    @Test fun `warm vad - the session takes the prebuilt vad and a new one is prepared in the background`() = runTest {
        val vads = mutableListOf<FakeVadHandle>()
        val background = ManualExecutor()
        val engine = warmEngine(vads, background)
        engine.warmUp()
        val prebuilt = vads.single()

        engine.transcribe(flowOf(ShortArray(160))).collect {}

        // The session built nothing on its own path and closed the VAD it took; the next one is
        // only handed to the background.
        assertEquals(1, vads.size)
        assertTrue(prebuilt.closed)
        assertEquals(1, background.pending.size)
        assertFalse(engine.isWarm())

        background.runAll()

        assertEquals(2, vads.size)
        assertFalse(vads[1].closed)
        assertTrue(engine.isWarm())
    }

    @Test fun `warm vad - a session with no spare ready builds its own and closes it`() = runTest {
        val vads = mutableListOf<FakeVadHandle>()
        val background = ManualExecutor()
        val engine = warmEngine(vads, background)

        engine.transcribe(flowOf(ShortArray(160))).collect {}

        assertEquals(1, vads.size)
        assertTrue(vads.single().closed)
        background.runAll()
        assertEquals(2, vads.size)
        assertTrue(engine.isWarm())
    }

    @Test fun `warm vad - the second session closes the vad the background prepared`() = runTest {
        val vads = mutableListOf<FakeVadHandle>()
        val background = ManualExecutor()
        val engine = warmEngine(vads, background)
        engine.warmUp()
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        background.runAll()
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        background.runAll()

        // Two sessions each closed the vad they took; the third waits for the next session.
        assertEquals(3, vads.size)
        assertTrue(vads[0].closed)
        assertTrue(vads[1].closed)
        assertFalse(vads[2].closed)
        assertTrue(engine.isWarm())
    }

    @Test fun `default path - no spare vad and no wait before listening`() = runTest {
        val vads = mutableListOf<FakeVadHandle>()
        var recognizerCreations = 0
        val background = ManualExecutor()
        val engine = GigaAmAsrEngine(
            modelManager = readyModelManager(),
            recognizerFactory = { recognizerCreations++; FakeRecognizerHandle() },
            vadFactory = { FakeVadHandle().also { vads += it } },
            prewarmExecutor = background,
        )
        assertFalse(engine.requiresWarmBeforeListening())
        assertTrue(engine.isWarm())

        engine.warmUp()
        assertEquals(1, recognizerCreations)
        assertTrue(vads.isEmpty())

        // As before the Android 10 change: each session builds its own VAD on its own path and
        // closes it when it ends, nothing is built ahead or in the background.
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        assertEquals(1, vads.size)
        assertTrue(vads.single().closed)
        engine.transcribe(flowOf(ShortArray(160))).collect {}
        assertEquals(2, vads.size)
        assertTrue(vads.all { it.closed })
        assertEquals(1, recognizerCreations)
        assertTrue(background.pending.isEmpty())
        assertTrue(engine.isWarm())
    }

    // --- VAD build time in the trace on every car: shows whether newer head units need the warm
    // VAD too. Milliseconds only, never the audio or the recognized text. ---

    @Test fun `the time to get the session vad is traced in milliseconds and nothing else`() = runTest {
        val vad = FakeVadHandle(listOf(
            FakeVadHandle.FrameScript(speech = true),
            FakeVadHandle.FrameScript(speech = false, segment = floatArrayOf(0.1f)),
        ))
        val engine = GigaAmAsrEngine(readyModelManager(), { FakeRecognizerHandle("открой окно") }, { vad })

        engine.transcribe(List(2) { ShortArray(320) { 1000 } }.asFlow()).toList()

        assertEquals(
            listOf("voice  vad-ready ms=N prebuilt=false #1"),
            trace.events().map { it.replace(Regex(""" ms=\d+"""), " ms=N") },
        )
    }

    @Test fun `warm vad - a prebuilt vad is traced as prebuilt`() = runTest {
        val engine = warmEngine(mutableListOf(), ManualExecutor())
        engine.warmUp()

        engine.transcribe(flowOf(ShortArray(160))).collect {}

        assertEquals(
            listOf("voice  vad-ready ms=N prebuilt=true #1"),
            trace.events().map { it.replace(Regex(""" ms=\d+"""), " ms=N") },
        )
    }
}
