package com.bydmate.app.hud

import android.content.Context
import android.content.pm.PackageInfo
import androidx.test.core.app.ApplicationProvider
import com.bydmate.app.navdata.NavGuidance
import com.bydmate.app.navdata.NavGuidanceHub
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
class HudManeuverJournalTest {

    private class FakeSink : HudEventSink {
        override fun fireEvent(topic: Long, payload: ByteArray): Int = 0
    }

    private val context: Context = ApplicationProvider.getApplicationContext()
    private val prefs = context.getSharedPreferences("hud_journal_test", Context.MODE_PRIVATE)
    private var clock = 1_700_000_000_000L

    @Before fun clear() {
        prefs.edit().clear().commit()
        NavGuidanceHub.reset()
    }

    private fun journal() = HudManeuverJournal(prefs) { clock }

    private fun installAmapService() {
        shadowOf(context.packageManager).installPackage(
            PackageInfo().apply { packageName = "com.byd.amapservice" })
    }

    private fun guidance(gaode: Int, distance: Int = 250, road: String = "A", raw: String = "desc:x") = NavGuidanceHub.update(
        NavGuidance(maneuverGaode = gaode, distanceMeters = distance, road = road, speedLimit = 0, maneuverRaw = raw),
        NavGuidanceHub.Source.A11Y, nowMs = clock,
    )

    @Test fun `ring drops the oldest entries past the cap`() {
        val j = journal()
        repeat(HudManeuverJournal.MAX_ENTRIES + 3) { i ->
            clock += 1000
            j.append(
                maneuverGaode = i, distanceMeters = 100, f28 = 1,
                amapIcon = 9, roundaboutNum = null, suppressArrow = false,
                source = "a11y", raw = "",
            )
        }
        val lines = j.lines()
        assertEquals(HudManeuverJournal.MAX_ENTRIES, lines.size)
        assertTrue(lines.first().contains("gaode=3 "))
        assertTrue(lines.last().contains("gaode=${HudManeuverJournal.MAX_ENTRIES + 2} "))
    }

    @Test fun `push loop records one line per maneuver change, not per frame`() {
        installAmapService()
        val loop = HudPushLoop(FakeSink(), nowMsProvider = { clock },
            amap = HudAmapBroadcaster(context), maneuvers = journal())

        guidance(gaode = 2)
        loop.tick(wasActive = false)
        loop.tick(wasActive = true)
        loop.tick(wasActive = true)      // same maneuver: still one line
        assertEquals(1, journal().lines().size)

        guidance(gaode = 27, distance = 300)
        loop.tick(wasActive = true)

        val lines = journal().lines()
        assertEquals(2, lines.size)
        // f28 = the SOME/IP arrow, amap = the broadcast icon: approaching the third exit of a
        // roundabout the arrow field is blank (99) while the Amap channel carries
        // ROUNDABOUT_ENTER (11) plus exit 3 — exactly the comparison #94 needs.
        assertTrue(lines[0].endsWith("gaode=2 dist=250m f28=2 amap=3 suppress=false src=a11y raw=\"desc:x\""))
        assertTrue(lines[1].endsWith("gaode=27 dist=300m f28=99 amap=11 rab=3 suppress=false src=a11y raw=\"desc:x\""))
    }

    @Test fun `camera takeover is recorded as a suppression change of the same maneuver`() {
        val loop = HudPushLoop(FakeSink(), nowMsProvider = { clock }, maneuvers = journal())

        guidance(gaode = 2)
        loop.tick(wasActive = false)

        NavGuidanceHub.updateFromNotification(
            NavGuidanceHub.RichUpdate(
                maneuverGaode = 2, distanceMeters = 900, road = "A",
                cameraAlert = "camera", cameraDistanceMeters = 400,
            ),
            nowMs = clock,
        )
        loop.tick(wasActive = true)

        val lines = journal().lines()
        assertEquals(2, lines.size)
        assertTrue(lines[1].endsWith("f28=0 amap=off suppress=true src=a11y raw=\"desc:x\""))
    }

    @Test fun `a new guidance session re-records its first maneuver`() {
        val loop = HudPushLoop(FakeSink(), nowMsProvider = { clock }, maneuvers = journal())

        guidance(gaode = 2)
        loop.tick(wasActive = false)
        NavGuidanceHub.reset()
        loop.tick(wasActive = true)      // clear frame, no journal line
        assertEquals(1, journal().lines().size)

        guidance(gaode = 2)
        loop.tick(wasActive = false)
        assertEquals(2, journal().lines().size)
    }

    @Test fun `push loop records where the maneuver came from and a drop on a street change (#294)`() {
        val loop = HudPushLoop(FakeSink(), nowMsProvider = { clock }, maneuvers = journal())

        guidance(gaode = 2, raw = "desc:Поверните направо")
        loop.tick(wasActive = false)
        // The next read names another street and carries no maneuver: the arrow goes at once.
        NavGuidanceHub.update(NavGuidance(distanceMeters = 800, road = "B"), NavGuidanceHub.Source.A11Y, nowMs = clock)
        loop.tick(wasActive = true)

        val lines = journal().lines()
        assertEquals(2, lines.size)
        assertTrue(lines[0], lines[0].endsWith("gaode=2 dist=250m f28=2 amap=off suppress=false src=a11y raw=\"desc:Поверните направо\""))
        assertTrue(lines[1], lines[1].endsWith("gaode=0 dist=800m f28=0 amap=off suppress=false src=none raw=\"\""))
    }
}
