package com.bydmate.app.voice

import android.content.Context
import com.bydmate.app.agent.AgentOrchestrator
import com.bydmate.app.agent.AgentResult
import com.bydmate.app.agent.AgentToolOutcome
import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.AutomationEngine
import com.bydmate.app.data.automation.DispatchResult
import com.bydmate.app.data.automation.VoiceFireResult
import com.bydmate.app.R
import com.bydmate.app.data.local.entity.ActionDef
import com.bydmate.app.util.appStringsOver
import io.mockk.clearMocks
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import io.mockk.verifyOrder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Wave B: PTT-toggled continuous session (onPttPressed / startContinuousSession /
 * stopContinuousSession) in VoiceController. A plain Kotlin fake stands in for
 * ContinuousAsr — its transcribe() replays whatever the test pushes into [events], while
 * ALSO actually collecting the incoming pcm flow (recordedFrames / collecting), which is
 * what lets tests prove the mute filter and cancellation wiring, not just the routing.
 */
class VoiceControllerSessionTest {

    private class FakeContinuousAsr(var ready: Boolean) : ContinuousAsr {
        val events = MutableSharedFlow<ContinuousAsrEvent>(extraBufferCapacity = 16)
        // Frames that actually survived the controller's mute filter and reached transcribe().
        val recordedFrames: MutableList<ShortArray> = Collections.synchronizedList(mutableListOf())
        @Volatile var collecting = false
        override fun isReady(): Boolean = ready
        override fun transcribe(pcm: Flow<ShortArray>): Flow<ContinuousAsrEvent> = flow {
            coroutineScope {
                val collectJob: Job = launch {
                    collecting = true
                    try {
                        pcm.collect { recordedFrames.add(it) }
                    } finally {
                        collecting = false
                    }
                }
                try {
                    emitAll(events)
                } finally {
                    collectJob.cancel()
                }
            }
        }
    }

    /** GigaAM downloaded but transcribe() itself throws (e.g. a corrupted model file after a
     *  partial delete) the instant it sees the first pcm frame -- simulates degradation matrix
     *  scenario (a). No events are ever emitted; the collect chain fails synchronously instead. */
    private class FailingContinuousAsr : ContinuousAsr {
        override fun isReady(): Boolean = true
        override fun transcribe(pcm: Flow<ShortArray>): Flow<ContinuousAsrEvent> = flow {
            pcm.collect { throw RuntimeException("gigaam decode failed") }
        }
    }

    /** Polls [condition] instead of a blind Thread.sleep -- deterministic-ish and fails fast in
     *  the common case. VoiceController's coroutine scope is a real, non-injected
     *  CoroutineScope(SupervisorJob()) with no test-dispatcher seam, so true virtual-time control
     *  (runTest) is not available without changing the production constructor; this is the closest
     *  practical alternative. */
    private fun awaitTrue(timeoutMs: Long = 10_000L, condition: () -> Boolean) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (condition()) return
            Thread.sleep(20)
        }
        if (!condition()) fail("condition not met within ${timeoutMs}ms")
    }

    /** `listening` flips true synchronously inside onPttPressed(), before the session coroutine
     *  has actually started running on its dispatcher -- so waiting on `listening` alone races
     *  with FakeContinuousAsr's emitAll(events) subscribing. subscriptionCount is the real
     *  barrier: a tryEmit before any collector attaches (replay = 0) is simply lost. */
    private fun awaitSubscribed(events: MutableSharedFlow<*>) = awaitTrue { events.subscriptionCount.value >= 1 }

    /** A stopped session flips `listening` false first and releases `busy` last in its finally
     *  (off-cue, overlay and trace run in between); a press before the release is dropped as
     *  busy. sessionActive() covers both, so a test presses again only once it reads false. */
    private fun awaitReleased(controller: VoiceController) = awaitTrue { !controller.sessionActive() }

    /** End-of-routing barrier that covers the busy flag: the routing job's finally nulls
     *  routingJob, then clears processingUtterance, then sets the overlay back to "listening"
     *  (VoiceController.kt:479-481). routingJobForTest() == null alone fires one line before the
     *  flag clears, and a phrase sent in that window is dropped as busy. The [n]-th "thinking" ->
     *  "listening" pair in [updates] (a controller built over [stubbedContext]) means the [n]-th
     *  routing has cleared the flag. */
    private fun awaitRoutingDone(updates: List<String>, n: Int) = awaitTrue {
        synchronized(updates) { updates.zipWithNext().count { (a, b) -> a == "Думаю" && b == "Слушаю" } } >= n
    }

    /** A clock that returns [times] one call at a time, then keeps the last: the mic gate reads
     *  it once per captured frame, so the frames get these capture times in order. */
    private fun frameClock(vararg times: Long): () -> Long {
        val queue = ArrayDeque(times.toList())
        return { if (queue.size > 1) queue.removeFirst() else queue.first() }
    }

    /** Same idea as [awaitTrue] but for a block of mockk verifications, which throw
     *  AssertionError on mismatch rather than returning a Boolean. */
    private fun awaitVerify(timeoutMs: Long = 10_000L, block: () -> Unit) {
        val deadline = System.currentTimeMillis() + timeoutMs
        var lastError: Throwable? = null
        while (System.currentTimeMillis() < deadline) {
            try {
                block()
                return
            } catch (t: Throwable) {
                lastError = t
                Thread.sleep(20)
            }
        }
        block() // let the final failure surface with mockk's own message
        lastError?.let { throw it }
    }

    /** A relaxed TtsEngine mock's `speaking` StateFlow<Boolean> property, being a mocked
     *  interface itself, has no real backing state and its collect() never suspends the way a
     *  real StateFlow does -- every test that runs a continuous session needs a stable, real
     *  StateFlow backing `speaking` for the session's internal speakingWatcher to collect
     *  safely. Tests that care about mute behaviour stub `speaking` explicitly instead. */
    private fun quietTtsEngine(): TtsEngine = mockk<TtsEngine>(relaxed = true) {
        every { speaking } returns MutableStateFlow(false)
    }

    @Suppress("LongParameterList") // test factory: every collaborator is an overridable default
    private fun makeController(
        continuousAsr: ContinuousAsr,
        dispatcher: ActionDispatcher,
        agentOrchestrator: AgentOrchestrator = mockk<AgentOrchestrator>().also {
            coEvery { it.ask(any(), any(), any()) } returns AgentResult.Disabled
            coEvery { it.noteAction(any()) } returns Unit
            // Default: no pending agent question (individual tests override AFTER construction).
            coEvery { it.expectsFollowUp() } returns false
        },
        ttsEngine: TtsEngine = quietTtsEngine(),
        audioCapture: AudioCapture = mockk<AudioCapture>(relaxed = true).also {
            every { it.captureSession(any(), any<(ShortArray) -> Any?>()) } returns flow { /* fake ignores pcm content */ }
        },
        journal: VoiceJournal = VoiceJournal(),
        earcon: VoiceEarcon = mockk(relaxed = true),
        context: Context = mockk<Context>(relaxed = true),
        agentIdentity: () -> AgentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
        closeAfterCommand: Boolean = false,
        ttsEnabled: Boolean = false,
    ): VoiceController {
        val gate = mockk<VoiceGate>()
        every { gate.isEnabled() } returns true
        every { gate.vehicleSnapshot() } returns null
        every { gate.ttsEnabled() } returns ttsEnabled
        every { gate.closeAfterCommand() } returns closeAfterCommand

        val automationEngine = mockk<AutomationEngine>(relaxed = true)
        val automationResolver = mockk<VoiceAutomationResolver>()
        coEvery { automationResolver.match(any()) } returns null

        return VoiceController(audioCapture, dispatcher, earcon, gate,
            automationEngine, automationResolver, agentOrchestrator, context,
            ttsEngine, journal, continuousAsr, agentIdentity = agentIdentity,
            ttsModelManager = mockk(relaxed = true),
            ruStressMarker = RuStressMarker { null },
            selectedTtsVoice = { TtsVoiceCatalog.byId("dmitri") },
            appStrings = appStringsOver(context))
    }

    // (a) PTT with isReady=true routes each Utterance into the NLU dispatch path, and the
    // session keeps listening for a second Utterance without a second PTT press.
    @Test fun `ptt press starts continuous session and routes each utterance to NLU dispatch`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal, context = stubbedContext())
        val overlayUpdates = Collections.synchronizedList(mutableListOf<String>())
        controller.updateListeningOverlay = { text -> overlayUpdates.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitVerify { coVerify(exactly = 1) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) } }
        awaitTrue { journal.entries.value.size == 1 && controller.routingJobForTest() == null }
        awaitRoutingDone(overlayUpdates, 1)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitVerify { coVerify(exactly = 2) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) } }

        assertTrue(controller.listening.value)
    }

    @Test fun `utterance while previous is routing is dropped without journal or earcon`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchStarted = AtomicBoolean(false)
        val releaseDispatch = AtomicBoolean(false)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            dispatchStarted.set(true)
            while (!releaseDispatch.get()) delay(10)
            DispatchResult(true)
        }
        val journal = VoiceJournal()
        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val controller = makeController(fakeAsr, dispatcher, journal = journal, earcon = earcon)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        clearMocks(earcon)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchStarted.get() }
        // The real GigaAM engine emits SpeechStart before every Utterance; while busy it must
        // not clobber the Thinking state either. droppedWhileBusyForTest() is the deterministic
        // signal that the sequential collect has consumed both events (no journal/earcon/state
        // side effects exist to await on a busy drop).
        fakeAsr.events.tryEmit(ContinuousAsrEvent.SpeechStart)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.droppedWhileBusyForTest() == 1 }

        assertEquals(VoiceUiState.Thinking, controller.state.value)
        assertTrue(journal.entries.value.isEmpty())
        verify(exactly = 0) { earcon.ok() }
        verify(exactly = 0) { earcon.fail() }

        releaseDispatch.set(true)
        awaitTrue { journal.entries.value.size == 1 }
        awaitTrue { controller.routingJobForTest() == null }

        coVerify(exactly = 1) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) }
        assertEquals(1, journal.entries.value.size)
    }

    @Test fun `next utterance after routing completes is processed normally`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchCalls = AtomicInteger(0)
        val releaseFirst = AtomicBoolean(false)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            val call = dispatchCalls.incrementAndGet()
            if (call == 1) {
                while (!releaseFirst.get()) delay(10)
            }
            DispatchResult(true)
        }
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal, context = stubbedContext())
        val overlayUpdates = Collections.synchronizedList(mutableListOf<String>())
        controller.updateListeningOverlay = { text -> overlayUpdates.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchCalls.get() == 1 }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))

        releaseFirst.set(true)
        awaitTrue { journal.entries.value.size == 1 }
        awaitTrue { controller.routingJobForTest() == null }
        awaitRoutingDone(overlayUpdates, 1)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { journal.entries.value.size == 2 }

        coVerify(exactly = 2) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) }
    }

    @Test fun `agent name utterance while ask is running cancels ask and keeps listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val askStarted = CompletableDeferred<Unit>()
        val askCancelled = CompletableDeferred<Unit>()
        val releaseAsk = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            askStarted.complete(Unit)
            try {
                releaseAsk.await()
                AgentResult.Answer("Поздний ответ")
            } catch (ce: CancellationException) {
                askCancelled.complete(Unit)
                throw ce
            }
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val journal = VoiceJournal()
        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val ttsEngine = quietTtsEngine()
        val controller = makeController(
            fakeAsr,
            dispatcher,
            agentOrchestrator = agentOrchestrator,
            journal = journal,
            earcon = earcon,
            ttsEngine = ttsEngine,
            context = stubbedContext(),
            agentIdentity = { AgentIdentity("Лео", AgentPersona.NAVIGATOR) },
        )
        val overlayUpdates = Collections.synchronizedList(mutableListOf<String>())
        controller.updateListeningOverlay = { text -> overlayUpdates.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        clearMocks(ttsEngine, earcon, answers = false)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("Лео"))

        awaitTrue { askCancelled.isCompleted }
        awaitTrue { controller.routingJobForTest() == null }
        assertEquals(VoiceUiState.Listening, controller.state.value)
        assertTrue(controller.listening.value)
        assertTrue(overlayUpdates.contains("Слушаю"))
        verify(exactly = 1) { ttsEngine.stop() }
        verify(atLeast = 1) { earcon.ok() }
        assertTrue(journal.entries.value.any {
            it.route == VoiceJournalEntry.Route.AGENT &&
                it.outcome == VoiceJournalEntry.Outcome.OK &&
                it.refusal == VoiceRefusal.BARGE_IN &&
                it.detail == "Прерван по имени"
        })

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitVerify { coVerify(exactly = 1) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) } }
    }

    @Test fun `non-name utterance while agent ask is running is still dropped as busy`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val askStarted = CompletableDeferred<Unit>()
        val askCancelled = CompletableDeferred<Unit>()
        val releaseAsk = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            askStarted.complete(Unit)
            try {
                releaseAsk.await()
                AgentResult.Answer("Готово")
            } catch (ce: CancellationException) {
                askCancelled.complete(Unit)
                throw ce
            }
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val journal = VoiceJournal()
        val controller = makeController(
            fakeAsr,
            dispatcher,
            agentOrchestrator = agentOrchestrator,
            journal = journal,
            agentIdentity = { AgentIdentity("Лео", AgentPersona.NAVIGATOR) },
        )

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("открой дверь"))

        awaitTrue { controller.droppedWhileBusyForTest() == 1 }
        assertFalse(askCancelled.isCompleted)
        releaseAsk.complete(Unit)
        awaitTrue { journal.entries.value.any { it.route == VoiceJournalEntry.Route.AGENT } }
    }

    @Test fun `blank agent name disables name barge-in and drops the utterance as busy`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val askStarted = CompletableDeferred<Unit>()
        val askCancelled = CompletableDeferred<Unit>()
        val releaseAsk = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            askStarted.complete(Unit)
            try {
                releaseAsk.await()
                AgentResult.Answer("Готово")
            } catch (ce: CancellationException) {
                askCancelled.complete(Unit)
                throw ce
            }
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val ttsEngine = quietTtsEngine()
        val journal = VoiceJournal()
        val controller = makeController(
            fakeAsr,
            dispatcher,
            agentOrchestrator = agentOrchestrator,
            journal = journal,
            ttsEngine = ttsEngine,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
        )

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        clearMocks(ttsEngine, answers = false)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("Лео"))

        awaitTrue { controller.droppedWhileBusyForTest() == 1 }
        assertFalse(askCancelled.isCompleted)
        verify(exactly = 0) { ttsEngine.stop() }
        releaseAsk.complete(Unit)
        awaitTrue { journal.entries.value.any { it.route == VoiceJournalEntry.Route.AGENT } }
    }

    @Test fun `silence autostop is suppressed while an utterance is being routed`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchStarted = AtomicBoolean(false)
        val releaseDispatch = AtomicBoolean(false)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            dispatchStarted.set(true)
            while (!releaseDispatch.get()) delay(10)
            DispatchResult(true)
        }
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchStarted.get() }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.SilenceTick(60_000L))
        // Marker utterance: when its busy drop is observed, the sequential collect has
        // definitely consumed the preceding SilenceTick without killing the session.
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("маркер"))
        awaitTrue { controller.droppedWhileBusyForTest() == 1 }
        assertTrue(controller.listening.value)

        releaseDispatch.set(true)
        awaitTrue { journal.entries.value.size == 1 }
        awaitTrue { controller.routingJobForTest() == null }

        assertTrue(controller.listening.value)
    }

    // (b) A second PTT press while listening stops the session immediately (barge-in stop TTS);
    // an utterance pushed after the stop is no longer routed (the collector was cancelled).
    @Test fun `second ptt press stops the session and further utterances are not routed`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val ttsEngine = quietTtsEngine()
        // makeController's default audioCapture is an empty flow{} that completes on first
        // collection -- unsuitable here since we need `collecting` to stay true until we
        // deliberately stop the session, not flip false on its own the instant it's collected.
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, audioCapture = audioCapture)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitTrue { fakeAsr.collecting }

        controller.onPttPressed()
        awaitTrue { !controller.listening.value }
        // Poll until the pcm collector has actually torn down (not just the listening flag) --
        // once true, the utterance loop is provably no longer running, so the negative assertion
        // below needs no arbitrary wait to be non-racy.
        awaitTrue { !fakeAsr.collecting }
        verify(atLeast = 1) { ttsEngine.stop() }

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (c) SilenceTick reaching the 30s auto-stop threshold ends the session on its own. The tick
    // is exactly 30_000 so this test pins the Wave P threshold: it fails if anyone reverts to 60s.
    @Test fun `silence tick at 30s auto-stops the session`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val controller = makeController(fakeAsr, dispatcher)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.SilenceTick(30_000L))

        awaitTrue { !controller.listening.value }
    }

    // (e) A follow-up question from the agent (AgentAnswer) does not end the session — the loop
    // keeps listening for the driver's reply without a second PTT press.
    @Test fun `agent answer to an utterance leaves the session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } returns AgentResult.Answer("Уточните, пожалуйста")
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val controller = makeController(fakeAsr, dispatcher, agentOrchestrator = agentOrchestrator)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("навигатор"))

        awaitTrue { controller.state.value == VoiceUiState.AgentAnswer("Уточните, пожалуйста") }
        assertTrue(controller.listening.value)
    }

    // (unrelated automation route): a rule match still dispatches through fireAutomation while
    // the continuous session stays open, mirroring the legacy VoiceFireResult.Fired coverage.
    @Test fun `utterance matched by automation resolver fires the rule, session stays open`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val automationEngine = mockk<AutomationEngine>(relaxed = true)
        coEvery { automationEngine.fireVoiceRule(any(), any()) } returns VoiceFireResult.Fired

        val gate = mockk<VoiceGate>()
        every { gate.isEnabled() } returns true
        every { gate.vehicleSnapshot() } returns null
        every { gate.ttsEnabled() } returns false

        val audioCapture = mockk<AudioCapture>(relaxed = true)
        every { audioCapture.captureSession(any(), any<(ShortArray) -> Any?>()) } returns flow { }

        val earcon = mockk<VoiceEarcon>(relaxed = true)

        val automationResolver = mockk<VoiceAutomationResolver>()
        coEvery { automationResolver.match(any()) } returns VoiceAutomationMatch(42L, "rule42")

        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false

        val controller = VoiceController(audioCapture, dispatcher, earcon, gate,
            automationEngine, automationResolver, agentOrchestrator, mockk<Context>(relaxed = true),
            quietTtsEngine(), VoiceJournal(), fakeAsr,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
            ttsModelManager = mockk(relaxed = true),
            ruStressMarker = RuStressMarker { null },
            selectedTtsVoice = { TtsVoiceCatalog.byId("dmitri") },
            appStrings = appStringsOver(mockk<Context>(relaxed = true)))

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("навигатор"))

        awaitVerify { coVerify(exactly = 1) { automationEngine.fireVoiceRule(42L, null) } }
        assertTrue(controller.listening.value)
    }

    // --- Finding 4: captureSession contract + cancellation + mute filter ---

    @Test fun `captureSession is invoked exactly once with no session cap (Long MAX_VALUE)`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        every { audioCapture.captureSession(any(), any<(ShortArray) -> Any?>()) } returns flow { }
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture)

        controller.onPttPressed()
        // `listening` flips synchronously in startContinuousSession(), before the launched
        // session coroutine has necessarily reached captureSession() -- poll the verify itself
        // (like awaitVerify elsewhere) instead of asserting once right after the flag.
        // Wave P: no hard session cap; Long.MAX_VALUE means "run until silence or user stops".
        awaitVerify { verify(exactly = 1) { audioCapture.captureSession(Long.MAX_VALUE, any<(ShortArray) -> Any?>()) } }
        assertTrue(controller.listening.value)
    }

    @Test fun `stopping the session cancels pcm collection`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture)

        controller.onPttPressed()
        awaitTrue { fakeAsr.collecting }

        controller.onPttPressed() // second press = stop
        awaitTrue { !controller.listening.value }
        awaitTrue { !fakeAsr.collecting }

        // Not just the flag: prove no frame emitted after the confirmed teardown is ever
        // recorded by the fake recognizer -- the collector job has already finished at this
        // point, so this is a deterministic check, not a timing-dependent one.
        val framesBefore = fakeAsr.recordedFrames.size
        rawFrames.tryEmit(shortArrayOf(9, 9, 9))
        assertEquals(framesBefore, fakeAsr.recordedFrames.size)
    }

    // The mic is gated while the agent talks: the car has no working echo cancellation, so an
    // echo that opened a VAD segment would swallow the driver's next phrase with it.
    @Test fun `frames captured while tts is audible never reach the recognizer`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(true)
        // One read per captured frame: the first frame is captured while the agent is audible.
        every { ttsEngine.audible() } returnsMany listOf(true, false)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, audioCapture = audioCapture)
        controller.clock = frameClock(1_000L, 1_500L) // the second frame is past the 200 ms grace

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)

        rawFrames.tryEmit(shortArrayOf(1, 2, 3))
        rawFrames.tryEmit(shortArrayOf(4, 5, 6))
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
        assertTrue(fakeAsr.recordedFrames.single().contentEquals(shortArrayOf(4, 5, 6)))
    }

    // --- Fix wave 2, finding 3: per-frame grace boundary (no collect()-based watcher) ---

    @Test fun `a frame just inside the post-speech grace window is dropped, one at its end passes`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(false)
        every { ttsEngine.audible() } returnsMany listOf(true, false)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, audioCapture = audioCapture)
        controller.clock = frameClock(1_000L, 1_199L, 1_200L)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)

        rawFrames.tryEmit(shortArrayOf(0)) // the last audible frame stamps the grace window
        rawFrames.tryEmit(shortArrayOf(1)) // 199 ms after it: still inside
        rawFrames.tryEmit(shortArrayOf(2)) // 200 ms after it: past the window
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
        assertTrue(fakeAsr.recordedFrames.single().contentEquals(shortArrayOf(2)))
    }

    // --- Task 6 (wave M): mic mute keys off physical playback (audible()), not the logical
    // `speaking` flag -- speaking is deliberately held true across a whole streamed reply,
    // including silent tool rounds where the sentence queue stays hot waiting on the LLM. ---

    @Test fun `frames pass the filter during a tool round -- speaking held true but audible false`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        // Emulates the queue mid tool-round: logically still "speaking" (queue hot), but nothing
        // is physically playing right now.
        val speaking = MutableStateFlow(true)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns speaking
        every { ttsEngine.audible() } returns false
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, audioCapture = audioCapture)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)

        rawFrames.tryEmit(shortArrayOf(1, 2, 3))
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
    }

    @Test fun `frames are dropped while audible is true even though the logical speaking flag is false`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(false)
        // Physical playback is actually happening for the first frame -- the gate must key off
        // this, not the (stale/mocked) logical flag.
        every { ttsEngine.audible() } returnsMany listOf(true, false)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, audioCapture = audioCapture)
        controller.clock = frameClock(1_000L, 1_500L)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)

        rawFrames.tryEmit(shortArrayOf(1, 2, 3))
        rawFrames.tryEmit(shortArrayOf(4, 5, 6))
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
        assertTrue(fakeAsr.recordedFrames.single().contentEquals(shortArrayOf(4, 5, 6)))
    }

    // --- Fix wave 3, finding 1: call-time stamp covers a TTS burst so short it starts AND ends
    // entirely between two mic frames, so the per-frame gate (Fix wave 2) never samples
    // audible=true for it. Only stamping lastSpeakingSeenMs when we ourselves call
    // ttsEngine.speak() (announce()/agent answer) can drop the frame that follows.

    @Test fun `a frame right after an agent answer is dropped even though audible never read true on any frame`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        // audible never flips true: simulates a TTS burst so short the per-frame gate never
        // observes it, so only the call-time stamp in agentFallback()'s Answer branch can drop.
        val speaking = MutableStateFlow(false)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns speaking
        // A relaxed mock's unstubbed Boolean-returning speak() returns false by default -- must
        // be stubbed true here since only that lets the Fix wave 4 conditional stamp fire.
        every { ttsEngine.speak(any()) } returns true
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)

        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } returns AgentResult.Answer("Готово")
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false

        val gate = mockk<VoiceGate>()
        every { gate.isEnabled() } returns true
        every { gate.vehicleSnapshot() } returns null
        every { gate.ttsEnabled() } returns true // must be true so agentFallback() actually speaks

        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val automationEngine = mockk<AutomationEngine>(relaxed = true)
        val automationResolver = mockk<VoiceAutomationResolver>()
        coEvery { automationResolver.match(any()) } returns null

        val controller = VoiceController(audioCapture, dispatcher, earcon, gate,
            automationEngine, automationResolver, agentOrchestrator, mockk<Context>(relaxed = true),
            ttsEngine, VoiceJournal(), fakeAsr,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
            ttsModelManager = mockk(relaxed = true),
            ruStressMarker = RuStressMarker { null },
            selectedTtsVoice = { TtsVoiceCatalog.byId("dmitri") },
            appStrings = appStringsOver(mockk<Context>(relaxed = true)))
        // The call-time stamp, then one read per captured frame.
        controller.clock = frameClock(1_000L, 1_100L, 1_500L)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("навигатор"))
        // Wait for agentFallback()'s Answer branch to actually run and stamp lastSpeakingSeenMs
        // at call time -- audible stays false throughout, so this can only be the call-time
        // stamp, never the per-frame one.
        awaitTrue { controller.lastSpeakingSeenMs == 1_000L }
        assertFalse(speaking.value)

        rawFrames.tryEmit(shortArrayOf(7)) // well within TTS_ECHO_GRACE_MS(200ms) of the stamp
        rawFrames.tryEmit(shortArrayOf(8)) // past it
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
        assertTrue(fakeAsr.recordedFrames.single().contentEquals(shortArrayOf(8)))
        coVerify(exactly = 1) { agentOrchestrator.ask(any(), any(), any()) }
    }

    // --- Fix wave 4, finding 1: speak() returning false (blank text, or engine not ready -- e.g.
    // voice not downloaded while the settings toggle is on) means no audio was ever enqueued, so
    // the call-time stamp must NOT fire and the following frame must NOT be dropped. ---

    @Test fun `agent answer with speak() returning false does not stamp the playback window, next phrase is routed`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val speaking = MutableStateFlow(false)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns speaking
        every { ttsEngine.speak(any()) } returns false // e.g. voice not downloaded
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)

        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } returns AgentResult.Answer("Готово")
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false

        val gate = mockk<VoiceGate>()
        every { gate.isEnabled() } returns true
        every { gate.vehicleSnapshot() } returns null
        every { gate.ttsEnabled() } returns true

        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val automationEngine = mockk<AutomationEngine>(relaxed = true)
        val automationResolver = mockk<VoiceAutomationResolver>()
        coEvery { automationResolver.match(any()) } returns null

        val controller = VoiceController(audioCapture, dispatcher, earcon, gate,
            automationEngine, automationResolver, agentOrchestrator, mockk<Context>(relaxed = true),
            ttsEngine, VoiceJournal(), fakeAsr,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
            ttsModelManager = mockk(relaxed = true),
            ruStressMarker = RuStressMarker { null },
            selectedTtsVoice = { TtsVoiceCatalog.byId("dmitri") },
            appStrings = appStringsOver(mockk<Context>(relaxed = true)))

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("навигатор"))
        // Once speak() (which returned false) has been invoked, the surrounding conditional has
        // already been evaluated synchronously in the same statement -- no separate wait needed
        // for the stamp decision itself.
        awaitVerify { verify { ttsEngine.speak("Готово") } }
        assertEquals(0L, controller.lastSpeakingSeenMs)

        rawFrames.tryEmit(shortArrayOf(7))
        awaitTrue { fakeAsr.recordedFrames.isNotEmpty() }
        awaitTrue { controller.routingJobForTest() == null }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.SpeechStart)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("навигатор"))
        awaitVerify { coVerify(exactly = 2) { agentOrchestrator.ask(any(), any(), any()) } }
    }

    // --- Fix wave 2, finding 3: inPlaybackWindow pins the exact grace-window boundary ---

    @Test fun `inPlaybackWindow pins the grace-window boundary precisely`() {
        // lastSpeakingSeenMs + TTS_ECHO_GRACE_MS(200) = windowEndMs, computed at the call site.
        assertTrue(VoiceController.inPlaybackWindow(nowMs = 999L, windowEndMs = 1000L, audible = false))
        assertFalse(VoiceController.inPlaybackWindow(nowMs = 1000L, windowEndMs = 1000L, audible = false))
    }

    // --- Finding 3: a single utterance's routing crash is journaled, session stays open ---

    @Test fun `routing exception for one utterance is journaled as an error but the session stays open`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } throws RuntimeException("boom") andThen DispatchResult(true)
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { journal.entries.value.isNotEmpty() }
        assertEquals(VoiceJournalEntry.Outcome.ERROR, journal.entries.value.first().outcome)
        assertTrue(controller.listening.value) // crash did not tear down the session
        awaitTrue { controller.routingJobForTest() == null }

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitVerify { coVerify(exactly = 2) { dispatcher.dispatch(match { it.command == "车窗关闭" }, any()) } }
    }

    // --- Fix wave 2, finding 2: decodeMs also lands in the ERROR entry's detail, not just logMsg ---

    @Test fun `routing exception journal entry also includes decodeMs in its detail`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } throws RuntimeException("boom")
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { journal.entries.value.isNotEmpty() }

        val entry = journal.entries.value.first()
        assertEquals(VoiceJournalEntry.Outcome.ERROR, entry.outcome)
        assertTrue(entry.detail.contains("decodeMs="))
    }

    // --- Finding 2: decodeMs lands in the VoiceJournal detail, not just logcat ---

    @Test fun `utterance journal detail includes decodeMs`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { journal.entries.value.isNotEmpty() }

        assertTrue(journal.entries.value.first().detail.contains("decodeMs="))
    }

    // --- Finding 6: sessionJob is released so a subsequent PTT can start a fresh session ---

    @Test fun `session can be restarted after a stop`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val controller = makeController(fakeAsr, dispatcher)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        controller.onPttPressed()
        awaitReleased(controller)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
    }

    // --- inPlaybackWindow: pure function, no session/clock needed ---

    @Test fun `inPlaybackWindow is true whenever tts is audible regardless of the window end`() {
        assertTrue(VoiceController.inPlaybackWindow(nowMs = System.currentTimeMillis(), windowEndMs = 0L, audible = true))
    }

    // --- Task 4: listening-overlay wiring (show/update/hide test seams) ---

    // #87: the resource string the else-branch of onPttPressed announces.
    private val modelMissingMsg = "Голосовая модель не загружена. Скачайте её в Настройках, раздел Голос-агент."

    private fun stubbedContext(): Context = mockk<Context>(relaxed = true).also {
        every { it.getString(R.string.voice_listening) } returns "Слушаю"
        every { it.getString(R.string.voice_thinking) } returns "Думаю"
        every { it.getString(R.string.voice_error_model_missing) } returns modelMissingMsg
    }

    @Test fun `starting a continuous session shows the listening overlay`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        val shown = Collections.synchronizedList(mutableListOf<String>())
        controller.showListeningOverlay = { text -> shown.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }

        awaitTrue { shown.isNotEmpty() }
        assertEquals(listOf("Слушаю"), shown)
    }

    @Test fun `an utterance flips the overlay to thinking then back to listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        val updates = Collections.synchronizedList(mutableListOf<String>())
        controller.updateListeningOverlay = { text -> updates.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { updates.size >= 2 }
        assertEquals(listOf("Думаю", "Слушаю"), updates)
    }

    @Test fun `stopping the session hides the listening overlay`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        var hidden = false
        controller.hideListeningOverlay = { hidden = true }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        controller.onPttPressed()
        awaitTrue { !controller.listening.value }

        awaitTrue { hidden }
    }

    // --- Wave B degradation matrix (Task 5) ---

    // (a) transcribe() throws on the first frame -- a capture/ASR failure, not a per-utterance
    // routing crash: the whole session ends with an error announce, busy is released (a fresh PTT
    // press can start a new session), and the overlay hides.
    @Test fun `transcribe throwing on the first frame ends the session with an error announce`() {
        val failingAsr = FailingContinuousAsr()
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(failingAsr, dispatcher, audioCapture = audioCapture, context = stubbedContext())
        val answers = Collections.synchronizedList(mutableListOf<String>())
        controller.showAnswerHook = { text -> answers.add(text) }
        var hidden = false
        controller.hideListeningOverlay = { hidden = true }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(rawFrames)

        rawFrames.tryEmit(shortArrayOf(1, 2, 3)) // "first frame" -- triggers the throw in transcribe()

        awaitTrue { !controller.listening.value }
        awaitTrue { hidden }
        awaitTrue { answers.isNotEmpty() }
        // announce()'s orb-dialog text is "Отказ: <message>" ("Ошибка" is the spoken phrase, not
        // shown here since ttsEnabled() defaults to false in makeController).
        assertTrue(answers.first().contains("Отказ"))

        // busy released: a fresh PTT press can start a new session, proving no stuck state.
        controller.onPttPressed()
        awaitTrue { controller.listening.value }
    }

    // (b) GigaAM model not ready (not downloaded, or deleted) while no session is active -- PTT
    // reports the degraded "model not ready" outcome without starting a session: state goes to
    // NotUnderstood, the journal records an ERROR entry, and the overlay/spoken announce is the
    // voice_error_model_missing resource string (#87).
    @Test fun `ptt with continuous engine not ready reports model-not-ready without starting a session`() {
        val fakeAsr = FakeContinuousAsr(ready = false) // simulates the model not being downloaded/deleted
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal, context = stubbedContext())
        val answers = Collections.synchronizedList(mutableListOf<String>())
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed()

        assertEquals(VoiceUiState.NotUnderstood(""), controller.state.value)
        assertEquals(1, journal.entries.value.size)
        assertEquals(VoiceJournalEntry.Outcome.ERROR, journal.entries.value.first().outcome)
        assertFalse(controller.listening.value)
        awaitTrue { answers.contains(modelMissingMsg) }
    }

    // (b2) Voice is always Russian (owner decision 2026-09-24): the app UI language plays no
    // part in starting a session. The controller no longer reads the app locale at all, so this
    // builds it over an English string set and checks that a ready model starts the session
    // with no refusal journaled.
    @Test fun `continuous session starts with the app language set to en`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val journal = VoiceJournal()
        val enContext = mockk<Context>(relaxed = true).also {
            every { it.getString(R.string.voice_listening) } returns "Listening"
            every { it.getString(R.string.voice_thinking) } returns "Thinking"
            every { it.getString(R.string.voice_error_model_missing) } returns "Voice model is not downloaded."
        }
        val controller = makeController(fakeAsr, dispatcher, journal = journal, context = enContext)
        val shown = Collections.synchronizedList(mutableListOf<String>())
        controller.showListeningOverlay = { text -> shown.add(text) }

        controller.onPttPressed()

        awaitTrue { controller.listening.value }
        awaitTrue { shown.isNotEmpty() }
        assertEquals(listOf("Listening"), shown)
        assertTrue(journal.entries.value.none { it.refusal == VoiceRefusal.MODEL_MISSING })
    }

    // (в) TTS voice not downloaded (gate.ttsEnabled() == false, the makeController default) --
    // the continuous session runs entirely silently (ttsEngine.speak() never called) while the
    // listening/thinking overlay still updates normally.
    @Test fun `continuous session runs silently with overlay when tts is not downloaded`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val ttsEngine = quietTtsEngine()
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine, context = stubbedContext())
        val updates = Collections.synchronizedList(mutableListOf<String>())
        controller.updateListeningOverlay = { text -> updates.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { updates.size >= 2 }

        assertEquals(listOf("Думаю", "Слушаю"), updates)
        verify(exactly = 0) { ttsEngine.speak(any()) }
        assertTrue(controller.listening.value)
    }

    // (г) A PTT-stop pressed while an utterance is mid-dispatch (Thinking) immediately cancels
    // the routing job — the orb goes idle without waiting for dispatch to complete. Frames
    // arriving after the stop never reach the recognizer (stopRequested blocks them, unchanged).
    @Test fun `ptt stop during routing immediately cancels dispatch and tears down`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchStarted = AtomicBoolean(false)
        val releaseDispatch = AtomicBoolean(false)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            dispatchStarted.set(true)
            while (!releaseDispatch.get()) delay(10)
            DispatchResult(true)
        }
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val journal = VoiceJournal()
        var hidden = false
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture, journal = journal, context = stubbedContext())
        controller.hideListeningOverlay = { hidden = true }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        // Proves the mic collector is genuinely attached to rawFrames (not just to
        // fakeAsr.events) before the post-stop frame is emitted below -- otherwise, with no
        // subscriber and replay=0, the emission could be silently lost by the fixture itself and
        // the "never reaches the recognizer" assertion would pass vacuously.
        awaitSubscribed(rawFrames)
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchStarted.get() } // dispatch() is now in flight, suspended in the delay loop

        controller.onPttPressed() // PTT-stop while Thinking

        // Frames emitted after stop must never reach the recognizer (stopRequested blocks them).
        val framesBefore = fakeAsr.recordedFrames.size
        rawFrames.tryEmit(shortArrayOf(1, 2, 3))
        Thread.sleep(100)
        assertEquals(framesBefore, fakeAsr.recordedFrames.size)

        // Hard stop: routing is cancelled immediately; session tears down without calling
        // releaseDispatch. Journal stays empty — CancellationException, no journal write.
        awaitTrue { !controller.listening.value }
        awaitTrue { hidden }
        assertTrue(journal.entries.value.isEmpty())
        coVerify(exactly = 1) { dispatcher.dispatch(any(), any()) } // called once, then cancelled
    }

    // --- Task 6: transcript in the orb dialog (heard phrase / agent answer / auto-clear) ---

    @Test fun `an utterance shows the heard transcript in the orb`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        val heard = Collections.synchronizedList(mutableListOf<String>())
        controller.showHeardHook = { text -> heard.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { heard.isNotEmpty() }
        assertEquals("закрой окна", heard.first())
    }

    @Test fun `a terminal answer shows the agent answer in the orb`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        val answers = Collections.synchronizedList(mutableListOf<String>())
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { answers.isNotEmpty() }
        assertTrue(answers.first().contains("Выполнено"))
    }

    @Test fun `the orb dialog clears after the answer once tts is not speaking`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        // Shrink the 6s dwell so the test need not wait it out (mirrors idleResetDelayMs); the fake
        // TtsEngine's speaking flow is already false, so first{!it} returns immediately.
        controller.dialogClearDelayMs = 50L
        var cleared = false
        controller.clearDialogHook = { cleared = true }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        // The dwell now scales with the answer length when nothing was spoken aloud, so the
        // window is longer than the seam alone suggests even for this short outcome text.
        awaitTrue { cleared }
    }

    @Test fun `a new utterance cancels the pending orb clear`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        // Second utterance's dispatch is held suspended so it never arms a replacement clear during
        // the observation window below -- so a fired clearDialogHook could only be the FIRST timer.
        val secondStarted = AtomicBoolean(false)
        val releaseSecond = AtomicBoolean(false)
        var calls = 0
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            calls++
            if (calls >= 2) {
                secondStarted.set(true)
                while (!releaseSecond.get()) delay(10)
            }
            DispatchResult(true)
        }
        val controller = makeController(fakeAsr, dispatcher, context = stubbedContext())
        // The unspoken 33-char outcome reads in under 2.5 s, so this floor is the first timer.
        controller.dialogClearDelayMs = 2_500L
        var cleared = false
        controller.clearDialogHook = { cleared = true }
        val answers = Collections.synchronizedList(mutableListOf<String>())
        val firstAnswerMs = AtomicLong(0L)
        controller.showAnswerHook = { text -> firstAnswerMs.compareAndSet(0L, System.currentTimeMillis()); answers.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        // First utterance completes and arms a 2.5 s clear.
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { answers.isNotEmpty() }
        awaitTrue { controller.routingJobForTest() == null }

        // Second utterance arrives well within 2.5 s; routeUtterance() cancels the pending clear
        // before its own (held) dispatch, so no replacement clear is armed.
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { secondStarted.get() }

        // Past the first timer's 2.5 s: had it not been cancelled, clearDialogHook would have fired.
        Thread.sleep((firstAnswerMs.get() + 3_000L - System.currentTimeMillis()).coerceAtLeast(0L))
        assertFalse(cleared)

        releaseSecond.set(true)
    }

    // --- Wave G Task 1: instant duck on PTT, before the recognizer is even constructed ---

    @Test fun `continuous session ducks before asr and restores on teardown`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        every { audioCapture.duckMusic() } returns 20
        // A never-completing frame source: the session must still be alive when the second press
        // arrives, and the collecting barrier below must not miss its window (an empty flow{}
        // flips collecting true->false before awaitTrue can observe it).
        val rawFrames = MutableSharedFlow<ShortArray>()
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        // Barrier: listening flips true synchronously in startContinuousSession, BEFORE the
        // launched coroutine reaches captureSession(). Without waiting for the collector the
        // stop below could cancel the job before captureSession() is ever invoked.
        awaitTrue { fakeAsr.collecting }

        controller.onPttPressed() // second press stops the session -- runs its finally block
        awaitTrue { !controller.listening.value }

        verifyOrder {
            audioCapture.duckMusic()       // early duck, before captureSession() is even called
            audioCapture.captureSession(any(), any<(ShortArray) -> Any?>())
        }
        verify { audioCapture.restoreMusic(20) }   // finally restored the early-duck volume
    }

    // --- Wave O Task 8: orb button is a hard OFF switch ---

    /** Hard stop (a): orb pressed while the agent ask is in-flight. The ask job must be
     *  cancelled and listening must go false immediately — without waiting for the LLM. */
    @Test fun `orb stop while agent ask is in flight cancels ask and goes idle immediately`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val askStarted = CompletableDeferred<Unit>()
        val askCancelled = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        // Ask hangs forever — simulates a slow or stuck LLM SSE stream.
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            askStarted.complete(Unit)
            try {
                CompletableDeferred<AgentResult>().await() // blocked until cancelled
            } catch (ce: CancellationException) {
                askCancelled.complete(Unit)
                throw ce
            }
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val ttsEngine = quietTtsEngine()
        val controller = makeController(
            fakeAsr, dispatcher,
            agentOrchestrator = agentOrchestrator,
            audioCapture = audioCapture,
            ttsEngine = ttsEngine,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
        )

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        // Utterance reaches agent path (no NLU match) and blocks forever.
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }

        // Hard stop: orb press while ask is suspended in the LLM call.
        controller.onPttPressed()

        // Ask must be cancelled and orb must go idle immediately — no releaseAsk needed.
        awaitTrue { askCancelled.isCompleted }
        awaitTrue { !controller.listening.value }
    }

    /** Hard stop (b): orb pressed while NLU dispatch is in-flight. The routing job must be
     *  cancelled and the orb must go idle immediately, without waiting for dispatch to return. */
    @Test fun `orb stop while routing is in flight cancels routing and goes idle immediately`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchStarted = AtomicBoolean(false)
        // Dispatch hangs indefinitely — cancelled at the delay suspension point.
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            dispatchStarted.set(true)
            delay(Long.MAX_VALUE)
            DispatchResult(true)
        }
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchStarted.get() }

        // Hard stop: orb press while dispatch is suspended.
        controller.onPttPressed()

        // Orb must go idle immediately — dispatch will never return on its own.
        awaitTrue { !controller.listening.value }
    }

    /** Hard stop (c): orb pressed while TTS is speaking and dispatch is in-flight.
     *  tts.stop() must be called even when processingUtterance=true. */
    @Test fun `orb stop while speaking and processing calls tts stop immediately`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val dispatchStarted = AtomicBoolean(false)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            dispatchStarted.set(true)
            delay(Long.MAX_VALUE)
            DispatchResult(true)
        }
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(true)
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture, ttsEngine = ttsEngine)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { dispatchStarted.get() }

        controller.onPttPressed() // hard stop while TTS speaking + dispatch in flight

        verify(atLeast = 1) { ttsEngine.stop() }
        awaitTrue { !controller.listening.value }
    }

    /** Hard stop (d): a late streaming sentence lands AFTER the orb press. The SSE loop can
     *  emit one more sentence between the ask job's cancellation and its next suspension
     *  point; the callback itself is non-suspend, so without the stopRequested gate it would
     *  repaint the orb dialog after the hard stop. The mock swallows the cancellation and
     *  fires the callback once more to model exactly that window. */
    @Test fun `orb stop suppresses streaming sentence that lands after the stop`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val askStarted = CompletableDeferred<Unit>()
        val releaseAsk = CompletableDeferred<Unit>()
        val lateSentenceFired = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            val onSentence = thirdArg<(String) -> Unit>()
            askStarted.complete(Unit)
            // Swallow the hard stop's cancellation, then emit one more sentence — models the
            // real SSE loop running past the cancellation until its next suspension point.
            try { releaseAsk.await() } catch (_: CancellationException) {}
            onSentence("поздний ответ")
            lateSentenceFired.complete(Unit)
            throw CancellationException("ask cancelled")
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val ttsEngine = quietTtsEngine()
        val controller = makeController(
            fakeAsr, dispatcher,
            agentOrchestrator = agentOrchestrator,
            audioCapture = audioCapture,
            ttsEngine = ttsEngine,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
        )
        val answers = mutableListOf<String>()
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }

        controller.onPttPressed() // hard stop while the ask is still suspended
        awaitTrue { !controller.listening.value }

        releaseAsk.complete(Unit) // the SSE tail sentence lands after the stop
        awaitTrue { lateSentenceFired.isCompleted }

        assertTrue("late sentence must not reach the orb dialog", answers.none { "поздний ответ" in it })
        assertTrue("late sentence must not resurrect AgentAnswer state",
            controller.state.value !is VoiceUiState.AgentAnswer)
    }

    /** Hard stop (e): stopRequested must not bleed into the NEXT session. A continuous hard
     *  stop leaves the flag set; only startContinuousSession() clears it -- a later session that
     *  forgot to reset it would have every announce() silently suppressed by the entry gate. */
    @Test fun `session after a hard stop is not muted by the stale stop flag`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        // A slow off-cue widens the window between listening=false and the session's release, the
        // window a press right after !listening used to fall into (dropped as ptt-ignored busy).
        val earcon = mockk<VoiceEarcon>(relaxed = true) { every { off() } answers { Thread.sleep(300) } }
        val controller = makeController(fakeAsr, dispatcher, audioCapture = audioCapture, earcon = earcon)
        val answers = mutableListOf<String>()
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        controller.onPttPressed() // hard stop: sets stopRequested and tears the session down
        awaitReleased(controller)

        // A fresh continuous session starts: startContinuousSession() must clear the stale flag.
        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))

        // The new session's outcome announcement must reach the orb dialog.
        awaitTrue { answers.any { "Выполнено" in it } }
    }

    /** Hard stop (f): a late streaming sentence from the OLD hard-stopped ask must stay muted
     *  even after a NEW session has started and reset the global stopRequested flag — the
     *  per-turn askJob.isCancelled mark, not the global flag, is what keeps it silent. */
    @Test fun `late sentence from a stopped ask stays muted after a new session starts`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
        val askStarted = CompletableDeferred<Unit>()
        val releaseAsk = CompletableDeferred<Unit>()
        val lateSentenceFired = CompletableDeferred<Unit>()
        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.ask(any(), any(), any()) } coAnswers {
            val onSentence = thirdArg<(String) -> Unit>()
            askStarted.complete(Unit)
            // Survives the hard stop's cancellation: models the real SSE loop still running
            // on the HTTP thread and delivering one more sentence long after the stop.
            withContext(NonCancellable) { releaseAsk.await() }
            onSentence("поздний ответ")
            lateSentenceFired.complete(Unit)
            throw CancellationException("ask cancelled")
        }
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false
        val rawFrames = MutableSharedFlow<ShortArray>()
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val controller = makeController(
            fakeAsr, dispatcher,
            agentOrchestrator = agentOrchestrator,
            audioCapture = audioCapture,
            ttsEngine = quietTtsEngine(),
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
        )
        val answers = mutableListOf<String>()
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи про заряд"))
        awaitTrue { askStarted.isCompleted }

        controller.onPttPressed() // hard stop while the ask is suspended
        awaitReleased(controller)

        // A NEW continuous session starts and resets the global stopRequested flag.
        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { answers.any { "Выполнено" in it } } // the new session's round completed

        releaseAsk.complete(Unit) // the OLD ask's tail sentence lands only now
        awaitTrue { lateSentenceFired.isCompleted }

        assertTrue("old ask's late sentence must stay muted after the new session reset the flag",
            answers.none { "поздний ответ" in it })
    }

    // --- Wave P Task 8: orb auto-closes after successful play_music ---

    // Wave P: a successful play_music tool call auto-closes the continuous session once the
    // reply has been spoken, so the orb stops ducking the music it just started. The session
    // must stay open for the whole spoken reply and close only when playback ends.
    @Test fun `successful play_music closes the continuous session after the answer`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } returns AgentResult.Answer(
            "Включаю", listOf(AgentToolOutcome("play_music", true)))
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val tts = mockk<TtsEngine>(relaxed = true)
        val speaking = MutableStateFlow(true)   // the reply is already streaming out loud
        every { tts.speaking } returns speaking
        val controller = makeController(fakeAsr, dispatcher, agentOrchestrator = agent, ttsEngine = tts)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer && controller.routingJobForTest() == null }

        // While the reply is still being spoken the session must stay open...
        Thread.sleep(500)
        assertTrue(controller.listening.value)
        // ...and closes once playback ends.
        speaking.value = false
        awaitTrue { !controller.listening.value }   // the session closed itself
    }

    // Pin for the enqueue-vs-playback race: speak() returns before the TTS worker flips
    // speaking=true, so a close that waits only for !speaking fires immediately and cuts the
    // reply before it starts. The close must wait for playback to begin, then to end.
    @Test fun `play_music close waits for a reply whose playback has not started yet`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } returns AgentResult.Answer(
            "Включаю", listOf(AgentToolOutcome("play_music", true)))
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val tts = mockk<TtsEngine>(relaxed = true)
        val speaking = MutableStateFlow(false)  // enqueue() returned, worker not playing yet
        every { tts.speaking } returns speaking
        val controller = makeController(fakeAsr, dispatcher, agentOrchestrator = agent, ttsEngine = tts)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("включи музыку"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer && controller.routingJobForTest() == null }

        // The answer landed but playback has not begun: the session must NOT close.
        Thread.sleep(500)
        assertTrue(controller.listening.value)
        speaking.value = true    // playback finally starts
        Thread.sleep(300)
        assertTrue(controller.listening.value)   // still open while the reply plays
        speaking.value = false   // playback ends
        awaitTrue { !controller.listening.value }
    }

    // The dictionary's Yandex Music phrase starts the same personal mix the agent's play_music
    // starts with no query, and closes the session after the reply for the same reason.
    @Test fun `dictionary Yandex Music plays the agent's personal mix and closes the session after the reply`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val captured = AtomicReference<ActionDef?>(null)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            captured.set(firstArg<ActionDef>()); DispatchResult(true)
        }
        val tts = mockk<TtsEngine>(relaxed = true)
        val speaking = MutableStateFlow(false)
        every { tts.speaking } returns speaking
        every { tts.speak(any()) } answers { speaking.value = true; true }
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = tts, ttsEnabled = true)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("включи яндекс музыку"))

        awaitTrue { captured.get() != null }
        assertEquals("yandex_music", captured.get()?.kind)
        assertEquals("""{"mode":"mybeat"}""", captured.get()?.payload)
        awaitTrue { controller.state.value is VoiceUiState.Done && controller.routingJobForTest() == null }
        // Open while "Готово" is being said, closed once it ends.
        Thread.sleep(500)
        assertTrue(controller.listening.value)
        speaking.value = false
        awaitTrue { !controller.listening.value }
    }

    @Test fun `non-music tools keep the continuous session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } returns AgentResult.Answer(
            "Заряд 80%", listOf(AgentToolOutcome("get_battery", true)))
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val controller = makeController(fakeAsr, dispatcher, agentOrchestrator = agent)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer && controller.routingJobForTest() == null }

        Thread.sleep(700)
        assertTrue(controller.listening.value)   // still listening
    }

    // Guard against the stale deferred close: PTT for a NEW session stops TTS, which is the very
    // signal the parked close-coroutine waits for -- without the job-identity check it would set
    // stopRequested and kill the session the user just started.
    @Test fun `play_music auto-close never kills a newer session started while tts still spoke`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } returns AgentResult.Answer(
            "Включаю", listOf(AgentToolOutcome("play_music", true)))
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val tts = mockk<TtsEngine>(relaxed = true)
        val speaking = MutableStateFlow(true)   // the reply keeps playing until flipped below
        every { tts.speaking } returns speaking
        val controller = makeController(fakeAsr, dispatcher, agentOrchestrator = agent, ttsEngine = tts)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("включи музыку"))
        // The deferred close is now parked on speaking.first { !it }. End the first session via
        // silence auto-stop; silence while the utterance is still routing does not count, so
        // keep re-emitting growing ticks until the session actually stops.
        var silentMs = 0L
        awaitTrue {
            silentMs += 30_000L
            fakeAsr.events.tryEmit(ContinuousAsrEvent.SilenceTick(silentMs))
            !controller.sessionActive()
        }

        controller.onPttPressed()               // user starts a fresh session...
        awaitTrue { controller.listening.value }
        speaking.value = false                  // ...and the old reply finally ends

        Thread.sleep(700)
        assertTrue(controller.listening.value)  // the new session must survive the stale close
    }

    // --- Close the agent after a done command (Settings toggle) and on the driver's request ---

    private fun okDispatcher(): ActionDispatcher = mockk<ActionDispatcher>(relaxed = true).also {
        coEvery { it.dispatch(any<ActionDef>(), any()) } returns DispatchResult(true)
    }

    private fun answeringAgent(text: String, vararg tools: AgentToolOutcome): AgentOrchestrator =
        mockk<AgentOrchestrator>().also {
            coEvery { it.ask(any(), any(), any()) } returns AgentResult.Answer(text, tools.toList())
            coEvery { it.noteAction(any()) } returns Unit
            coEvery { it.expectsFollowUp() } returns false
        }

    /** A TTS whose speak() enqueues playback; the test drives [speaking] by hand. */
    private fun speakingTts(speaking: MutableStateFlow<Boolean>): TtsEngine = mockk<TtsEngine>(relaxed = true) {
        every { speak(any()) } returns true
        every { this@mockk.speaking } returns speaking
    }

    private fun startSession(controller: VoiceController, asr: FakeContinuousAsr) {
        controller.onPttPressed()
        awaitTrue { controller.listening.value }
        awaitSubscribed(asr.events)
    }

    /** Stamps, on the controller's own threads, when the first answer reached the orb and when
     *  the session hid its overlay on teardown. */
    private fun stampAnswerAndClose(controller: VoiceController): Pair<AtomicLong, AtomicLong> {
        val answeredMs = AtomicLong(0L)
        val closedMs = AtomicLong(0L)
        controller.showAnswerHook = { answeredMs.compareAndSet(0L, System.currentTimeMillis()) }
        controller.hideListeningOverlay = { closedMs.set(System.currentTimeMillis()) }
        return answeredMs to closedMs
    }

    /** The session stayed open at least [minMs] after the answer appeared. Both ends are stamped
     *  by the controller itself, so a late test thread cannot make this fail. */
    private fun assertOpenAtLeast(minMs: Long, answeredMs: AtomicLong, closedMs: AtomicLong) {
        val openMs = closedMs.get() - answeredMs.get()
        assertTrue("closed $openMs ms after the answer", answeredMs.get() != 0L && openMs >= minMs)
    }

    // Longest unspoken reading dwell of the short outcome texts below with the 50 ms floor.
    private val shortDwellMs = 2_500L

    @Test fun `toggle off - a done command keeps the session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, okDispatcher())
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Done && controller.routingJobForTest() == null }
        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    @Test fun `toggle on - a done command closes the session once the spoken reply ends`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val speaking = MutableStateFlow(false)
        val controller = makeController(fakeAsr, okDispatcher(), ttsEngine = speakingTts(speaking),
            closeAfterCommand = true, ttsEnabled = true)
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Done }
        Thread.sleep(500)
        assertTrue(controller.listening.value)   // the reply has not started playing yet
        speaking.value = true
        Thread.sleep(300)
        assertTrue(controller.listening.value)   // still open while the reply plays
        speaking.value = false
        awaitTrue { !controller.listening.value }
    }

    @Test fun `toggle on - an agent question keeps the session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, mockk(relaxed = true),
            agentOrchestrator = answeringAgent("Какое окно закрыть? "), closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer }
        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    @Test fun `toggle on - a final agent answer closes the session`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, mockk(relaxed = true),
            agentOrchestrator = answeringAgent("Окна закрыты."), closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { !controller.listening.value }
    }

    @Test fun `toggle on - a blocked or not understood phrase keeps the session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } returns DispatchResult(false, "занято")
        // The default agent is disabled: an unknown phrase ends NotUnderstood.
        val controller = makeController(fakeAsr, dispatcher, closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Blocked && controller.routingJobForTest() == null }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.NotUnderstood }
        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    @Test fun `toggle on - a new phrase before the close cancels it`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        // The second phrase's dispatch is held, so it never arms a close of its own.
        val secondStarted = AtomicBoolean(false)
        val releaseSecond = AtomicBoolean(false)
        val calls = AtomicInteger(0)
        coEvery { dispatcher.dispatch(any<ActionDef>(), any()) } coAnswers {
            if (calls.incrementAndGet() >= 2) {
                secondStarted.set(true)
                while (!releaseSecond.get()) delay(10)
            }
            DispatchResult(true)
        }
        val controller = makeController(fakeAsr, dispatcher, closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Done && controller.routingJobForTest() == null }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { secondStarted.get() }

        Thread.sleep(shortDwellMs)   // past the first close's reading dwell
        assertTrue(controller.listening.value)
        releaseSecond.set(true)
    }

    @Test fun `toggle on - with nothing spoken the session closes after the reading dwell`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, okDispatcher(), closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        val (answeredMs, closedMs) = stampAnswerAndClose(controller)
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Done }
        awaitTrue { !controller.listening.value && closedMs.get() != 0L }
        // the text was still being read 500 ms after it appeared
        assertOpenAtLeast(500L, answeredMs, closedMs)
    }

    @Test fun `toggle on - a newer session started while the close waited is not closed`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val speaking = MutableStateFlow(true)   // the reply keeps playing until flipped below
        val controller = makeController(fakeAsr, okDispatcher(), ttsEngine = speakingTts(speaking),
            closeAfterCommand = true, ttsEnabled = true)
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))
        awaitTrue { controller.state.value is VoiceUiState.Done && controller.routingJobForTest() == null }
        controller.onPttPressed()               // the driver stops this session...
        awaitReleased(controller)
        controller.onPttPressed()               // ...and starts a fresh one
        awaitTrue { controller.listening.value }
        speaking.value = false                  // the old reply finally ends

        Thread.sleep(700)
        assertTrue(controller.listening.value)
    }

    // Nothing is spoken (TTS off): the goodbye stays readable for its reading dwell, then the session closes.
    @Test fun `end_conversation closes the session after the reply even with the toggle off`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, mockk(relaxed = true),
            agentOrchestrator = answeringAgent("До встречи, хорошей дороги!", AgentToolOutcome("end_conversation", true)))
        controller.dialogClearDelayMs = 50L
        val (answeredMs, closedMs) = stampAnswerAndClose(controller)
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой агента"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer }
        awaitTrue { !controller.listening.value && closedMs.get() != 0L }
        // the goodbye was still being read 500 ms after it appeared
        assertOpenAtLeast(500L, answeredMs, closedMs)
    }

    // The reply is a queue of two sentences; speaking dips false between them. The close waits
    // for the whole queued reply, not for the first dip.
    @Test fun `toggle on - a two-sentence reply closes only after the second sentence ends`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val speaking = MutableStateFlow(false)
        val played = CompletableDeferred<Unit>()
        val queue = object : TtsEngine.SpeechQueue {
            override fun enqueue(text: String): Boolean = true
            override fun finish() = Unit
            override suspend fun awaitPlayed() = played.await()
        }
        val tts = speakingTts(speaking).also { every { it.startQueue() } returns queue }
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } coAnswers {
            val onSentence = thirdArg<((String) -> Unit)?>()
            onSentence?.invoke("Окна закрыты.")
            onSentence?.invoke("Хорошей дороги.")
            AgentResult.Answer("Окна закрыты. Хорошей дороги.")
        }
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val controller = makeController(fakeAsr, mockk(relaxed = true), agentOrchestrator = agent,
            ttsEngine = tts, closeAfterCommand = true, ttsEnabled = true)
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer }
        speaking.value = true    // sentence 1 plays
        Thread.sleep(200)
        speaking.value = false   // the gap: sentence 2 is still being synthesized
        Thread.sleep(700)
        assertTrue(controller.listening.value)
        speaking.value = true    // sentence 2 plays
        played.complete(Unit)    // the queue handed out its last sentence
        Thread.sleep(300)
        assertTrue(controller.listening.value)
        speaking.value = false   // sentence 2 ends
        awaitTrue { !controller.listening.value }
    }

    // One pending close at a time: a later close replaces the earlier, so a barge-in that
    // cancels the later one leaves nothing behind that could still close the session.
    @Test fun `a barge-in after a play_music close and a done command keeps the session open`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val speaking = MutableStateFlow(true)   // the play_music reply keeps playing until flipped
        val tts = mockk<TtsEngine>(relaxed = true) { every { this@mockk.speaking } returns speaking }
        val askCalls = AtomicInteger(0)
        val askStarted = CompletableDeferred<Unit>()
        val agent = mockk<AgentOrchestrator>()
        coEvery { agent.ask(any(), any(), any()) } coAnswers {
            if (askCalls.incrementAndGet() == 1) {
                AgentResult.Answer("Включаю", listOf(AgentToolOutcome("play_music", true)))
            } else {
                askStarted.complete(Unit)
                CompletableDeferred<AgentResult>().await()   // hangs until the barge-in cancels it
            }
        }
        coEvery { agent.noteAction(any()) } returns Unit
        coEvery { agent.expectsFollowUp() } returns false
        val controller = makeController(fakeAsr, okDispatcher(), agentOrchestrator = agent, ttsEngine = tts,
            closeAfterCommand = true, context = stubbedContext(),
            agentIdentity = { AgentIdentity("Лео", AgentPersona.NAVIGATOR) })
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("включи музыку"))   // arms the play_music close
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer && controller.routingJobForTest() == null }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой окна"))     // arms the auto-close
        awaitTrue { controller.state.value is VoiceUiState.Done && controller.routingJobForTest() == null }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { askStarted.isCompleted }
        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("Лео"))             // name barge-in
        awaitTrue { controller.routingJobForTest() == null }
        speaking.value = false   // the old music reply ends

        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    @Test fun `toggle on - an agent answer after a failed tool keeps the session listening`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, mockk(relaxed = true),
            agentOrchestrator = answeringAgent("Не получилось открыть окно.", AgentToolOutcome("vehicle_control", false)),
            closeAfterCommand = true)
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("расскажи анекдот"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer }
        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    @Test fun `an agent answer without end_conversation keeps the session listening with the toggle off`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val controller = makeController(fakeAsr, mockk(relaxed = true),
            agentOrchestrator = answeringAgent("Пока"))
        controller.dialogClearDelayMs = 50L
        startSession(controller, fakeAsr)

        fakeAsr.events.tryEmit(ContinuousAsrEvent.Utterance("закрой агента"))
        awaitTrue { controller.state.value is VoiceUiState.AgentAnswer }
        Thread.sleep(shortDwellMs)
        assertTrue(controller.listening.value)
    }

    // --- I-1 fix: the else-branch (model not ready / non-RU) must also reset stopRequested ---

    /** A continuous-session hard stop leaves stopRequested set; only startContinuousSession()
     *  used to clear it. If the model then becomes not ready (or the language switches to
     *  non-RU) before the next PTT press, onPttPressed() falls into the else-branch instead --
     *  which, before the fix, never reset the flag, so announce()'s stopRequested gate silently
     *  swallowed the "model not loaded" overlay+speech forever (this user can never start a
     *  continuous session again to reset it). */
    @Test fun `ptt reports model-not-ready after a hard stop, not muted by the stale stop flag`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val journal = VoiceJournal()
        val controller = makeController(fakeAsr, dispatcher, journal = journal, context = stubbedContext())
        val answers = Collections.synchronizedList(mutableListOf<String>())
        controller.showAnswerHook = { text -> answers.add(text) }

        controller.onPttPressed() // starts a continuous session
        awaitTrue { controller.listening.value }
        awaitSubscribed(fakeAsr.events)
        controller.onPttPressed() // hard stop: sets stopRequested, session tears down
        awaitReleased(controller)

        fakeAsr.ready = false // model becomes not ready (or user switched to a non-RU language)
        controller.onPttPressed() // else-branch: model-not-ready path

        assertEquals(VoiceUiState.NotUnderstood(""), controller.state.value)
        assertEquals(1, journal.entries.value.size)
        assertEquals(VoiceJournalEntry.Outcome.ERROR, journal.entries.value.first().outcome)
        awaitTrue { answers.contains(modelMissingMsg) }
    }

    // --- Voice speed wave step 1: PTT prewarms the online TTS network connection while the
    // driver is still speaking, so a cold turn does not pay DNS+TLS inside the reply latency.
    // Gated on gate.ttsEnabled() -- prewarming a connection nobody will use is wasted work.

    @Test fun `ptt session start prewarms the tts network when spoken replies are enabled`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val rawFrames = MutableSharedFlow<ShortArray>(extraBufferCapacity = 8)
        val audioCapture = mockk<AudioCapture>(relaxed = true)
        audioCapture.stubFrames(rawFrames)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(false)

        val agentOrchestrator = mockk<AgentOrchestrator>()
        coEvery { agentOrchestrator.noteAction(any()) } returns Unit
        coEvery { agentOrchestrator.expectsFollowUp() } returns false

        val gate = mockk<VoiceGate>()
        every { gate.isEnabled() } returns true
        every { gate.vehicleSnapshot() } returns null
        every { gate.ttsEnabled() } returns true // must be true so PTT prewarms the connection

        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val automationEngine = mockk<AutomationEngine>(relaxed = true)
        val automationResolver = mockk<VoiceAutomationResolver>()
        coEvery { automationResolver.match(any()) } returns null

        val controller = VoiceController(audioCapture, dispatcher, earcon, gate,
            automationEngine, automationResolver, agentOrchestrator, mockk<Context>(relaxed = true),
            ttsEngine, VoiceJournal(), fakeAsr,
            agentIdentity = { AgentIdentity("", AgentPersona.NAVIGATOR) },
            ttsModelManager = mockk(relaxed = true),
            ruStressMarker = RuStressMarker { null },
            selectedTtsVoice = { TtsVoiceCatalog.byId("dmitri") },
            appStrings = appStringsOver(mockk<Context>(relaxed = true)))

        controller.onPttPressed()
        awaitTrue { controller.listening.value }

        verify(exactly = 1) { ttsEngine.prewarmNetwork() }
    }

    @Test fun `ptt session start does not prewarm the tts network when spoken replies are disabled`() {
        val fakeAsr = FakeContinuousAsr(ready = true)
        val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        val ttsEngine = mockk<TtsEngine>(relaxed = true)
        every { ttsEngine.speaking } returns MutableStateFlow(false)
        // makeController's default gate.ttsEnabled() is false.
        val controller = makeController(fakeAsr, dispatcher, ttsEngine = ttsEngine)

        controller.onPttPressed()
        awaitTrue { controller.listening.value }

        verify(exactly = 0) { ttsEngine.prewarmNetwork() }
    }

    // --- Android 10 head units (PR #261): listening opens only once the recognizer and the VAD
    // are built, so the first words after the start cue are recorded. Until then the press is
    // answered with the pill in its "Думаю" look. Other cars start at once, as before. ---

    /** warmUp() blocks until the test opens [warmGate]; [warmFails] leaves the engine cold. */
    private class WarmingAsr(private val requiresWarm: Boolean) : ContinuousAsr {
        val events = MutableSharedFlow<ContinuousAsrEvent>(extraBufferCapacity = 16)
        val warmGate = CountDownLatch(1)
        val warmUps = AtomicInteger(0)
        @Volatile var warm = false
        @Volatile var warmFails = false
        override fun isReady(): Boolean = true
        override fun isWarm(): Boolean = warm
        override fun requiresWarmBeforeListening(): Boolean = requiresWarm
        override fun warmUp() {
            warmUps.incrementAndGet()
            warmGate.await(5, TimeUnit.SECONDS)
            if (!warmFails) warm = true
        }
        override fun transcribe(pcm: Flow<ShortArray>): Flow<ContinuousAsrEvent> = events
    }

    /** The warm-up job has started the session and is done: presses count again from here. */
    private fun awaitStartedAfterWarmUp(controller: VoiceController) {
        awaitTrue { controller.listening.value }
        awaitTrue { controller.warmupJobForTest()?.isActive != true }
    }

    @Test fun `android 10 - listening waits for the warm-up and starts right after it`() {
        val asr = WarmingAsr(requiresWarm = true)
        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val controller = makeController(asr, mockk(relaxed = true), earcon = earcon, context = stubbedContext())
        val shown = Collections.synchronizedList(mutableListOf<String>())
        val updates = Collections.synchronizedList(mutableListOf<String>())
        controller.showListeningOverlay = { text -> shown.add(text) }
        controller.updateListeningOverlay = { text -> updates.add(text) }

        controller.onPttPressed()
        awaitTrue { asr.warmUps.get() == 1 }

        assertEquals(listOf("Думаю"), shown)
        assertFalse(controller.listening.value)
        verify(exactly = 0) { earcon.ok() }

        asr.warmGate.countDown()
        awaitStartedAfterWarmUp(controller)
        awaitSubscribed(asr.events)

        assertEquals("Слушаю", updates.first())
        verify(exactly = 1) { earcon.ok() }
        controller.onPttPressed()
        awaitTrue { !controller.listening.value }
    }

    @Test fun `android 10 - an already warm engine starts listening at once`() {
        val asr = WarmingAsr(requiresWarm = true).apply { warm = true }
        val controller = makeController(asr, mockk(relaxed = true))

        controller.onPttPressed()

        assertTrue(controller.listening.value)
        assertEquals(0, asr.warmUps.get())
    }

    @Test fun `android 10 - a second press during the warm-up is ignored`() {
        val asr = WarmingAsr(requiresWarm = true)
        val controller = makeController(asr, mockk(relaxed = true))

        controller.onPttPressed()
        awaitTrue { asr.warmUps.get() == 1 }
        controller.onPttPressed()
        asr.warmGate.countDown()
        awaitStartedAfterWarmUp(controller)

        assertEquals(1, asr.warmUps.get())
        controller.onPttPressed()
        awaitTrue { !controller.listening.value }
    }

    @Test fun `android 10 - a warm-up that could not finish still starts the session`() {
        val asr = WarmingAsr(requiresWarm = true).apply { warmFails = true }
        val controller = makeController(asr, mockk(relaxed = true))

        controller.onPttPressed()
        asr.warmGate.countDown()

        awaitStartedAfterWarmUp(controller)
        controller.onPttPressed()
        awaitTrue { !controller.listening.value }
    }

    @Test fun `other cars start listening at once without waiting for a warm-up`() {
        val asr = WarmingAsr(requiresWarm = false)
        val earcon = mockk<VoiceEarcon>(relaxed = true)
        val controller = makeController(asr, mockk(relaxed = true), earcon = earcon, context = stubbedContext())
        val shown = Collections.synchronizedList(mutableListOf<String>())
        controller.showListeningOverlay = { text -> shown.add(text) }

        controller.onPttPressed()

        // Same as before the Android 10 change: the cue and the listening state on the press
        // itself, no warm-up job, the pill opens as «Слушаю» and never shows «Думаю».
        assertTrue(controller.listening.value)
        verify(exactly = 1) { earcon.ok() }
        assertNull(controller.warmupJobForTest())
        awaitSubscribed(asr.events)
        awaitTrue { shown.isNotEmpty() }
        assertEquals(listOf("Слушаю"), shown)
        assertEquals(0, asr.warmUps.get())
        controller.onPttPressed()
        awaitTrue { !controller.listening.value }
    }
}
