package com.bydmate.app.agent

import android.content.Context
import android.content.SharedPreferences
import com.bydmate.app.cluster.ClusterMode
import com.bydmate.app.cluster.ClusterVoiceControl
import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.AutomationEngine
import com.bydmate.app.data.automation.DispatchResult
import com.bydmate.app.data.local.dao.ChargeDao
import com.bydmate.app.data.local.dao.RuleDao
import com.bydmate.app.data.local.dao.TripDao
import com.bydmate.app.data.local.entity.ActionDef
import com.bydmate.app.data.local.entity.PlaceEntity
import com.bydmate.app.data.remote.OpenRouterClient
import com.bydmate.app.data.repository.PlaceRepository
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.domain.battery.BatteryStateRepository
import com.bydmate.app.domain.calculator.RangeCalculator
import com.bydmate.app.voice.VoiceGate
import io.mockk.clearMocks
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentToolsLaunchTest {

    private val gate = mockk<VoiceGate>()
    private val battery = mockk<BatteryStateRepository>()
    private val range = mockk<RangeCalculator>()
    private val tripDao = mockk<TripDao>()
    private val chargeDao = mockk<ChargeDao>()
    private val dispatcher = mockk<ActionDispatcher>(relaxed = true)
        .also { io.mockk.every { it.willOpenPinned(any()) } returns null }
    private val ruleDao = mockk<RuleDao>()
    private val engine = mockk<AutomationEngine>()
    private val places = mockk<PlaceRepository>()
    private val weather = mockk<WeatherClient>()
    private val exa = mockk<ExaSearchClient>()
    private val openRouterClient = mockk<OpenRouterClient>()
    private val settingsRepository = mockk<SettingsRepository>()
    private val contactLookup = mockk<ContactLookup>()
    private val context = mockk<Context>(relaxed = true)
    private val clusterVoiceControl = mockk<ClusterVoiceControl>(relaxUnitFun = true)
    private val chargerSearchClient = mockk<ChargerSearchClient>(relaxed = true)

    private fun tools() = agentTools(
        gate = gate,
        batteryStateRepository = battery,
        rangeCalculator = range,
        tripDao = tripDao,
        chargeDao = chargeDao,
        actionDispatcher = dispatcher,
        ruleDao = ruleDao,
        automationEngine = engine,
        placeRepository = places,
        weatherClient = weather,
        exaSearchClient = exa,
        openRouterClient = openRouterClient,
        settingsRepository = settingsRepository,
        contactLookup = contactLookup,
        context = context,
        clusterVoiceControl = clusterVoiceControl,
        chargerSearchClient = chargerSearchClient,
    ).apply {
        naviForegroundCheck = { true }; naviVerifyAttempts = 1; naviVerifyIntervalMs = 1L
    }

    // (a) destination matches a saved place (case-insensitively) -> route by lat/lon.
    @Test fun navigate_to_saved_place_routes_by_coords() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        coEvery { places.getAllSnapshot() } returns listOf(
            PlaceEntity(name = "Дом", lat = 55.75, lon = 37.61, radiusM = 100),
        )
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "navigate_to", """{"destination":"дом"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("Дом", out.getString("place"))
        assertEquals("navigate", captured.captured.kind)
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals(55.75, payload.getDouble("lat"), 0.0001)
        assertEquals(37.61, payload.getDouble("lon"), 0.0001)
    }

    // (b) free-text address with no matching place -> search payload.
    @Test fun navigate_to_free_text_opens_search() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        coEvery { places.getAllSnapshot() } returns emptyList()
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "navigate_to", """{"destination":"улица Ленина 5"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("search", out.getString("mode"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("улица Ленина 5", payload.getString("query"))
    }

    // (c) placeRepository throwing must not surface as an exception; "Дом" resolves as a
    // home/work shortcut and falls through to Navigator's own saved Home -> mode=route.
    @Test fun navigate_to_survives_place_lookup_failure() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        coEvery { places.getAllSnapshot() } throws RuntimeException("db down")
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "navigate_to", """{"destination":"Дом"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("route", out.getString("mode"))
        assertEquals("Дом", out.getString("target"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("home", payload.getString("shortcut"))
    }

    // (e) go_home dispatches the go_home kind.
    @Test fun go_home_dispatches_go_home_kind() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(AgentToolCall("1", "go_home", "{}")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("go_home", captured.captured.kind)
    }

    // end_conversation only reports ok: the voice session closes itself.
    @Test fun end_conversation_returns_ok_and_dispatches_nothing() = runTest {
        coEvery { ruleDao.getEnabled() } returns emptyList()
        coEvery { settingsRepository.getString(SettingsRepository.KEY_EXA_API_KEY, "") } returns ""
        val schemas = tools().schemas()
        val names = (0 until schemas.length())
            .map { schemas.getJSONObject(it).getJSONObject("function").getString("name") }
        assertTrue("end_conversation" in names)
        val out = JSONObject(tools().execute(AgentToolCall("1", "end_conversation", "{}")))
        assertTrue(out.getBoolean("ok"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (f) dispatcher failure -> Russian error JSON.
    @Test fun navigate_to_dispatch_failure_reports_error() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "не получилось открыть Навигатор")
        coEvery { places.getAllSnapshot() } returns emptyList()
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "navigate_to", """{"destination":"Сочи"}""")))
        assertFalse(out.has("ok"))
        assertEquals("не получилось открыть Навигатор", out.getString("error"))
    }

    // (g) play_music without query -> Моя волна via mybeat mode.
    @Test fun play_music_without_query_plays_mybeat() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(AgentToolCall("1", "play_music", "{}")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("Моя волна", out.getString("playing"))
        assertEquals("yandex_music", captured.captured.kind)
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("mybeat", payload.getString("mode"))
    }

    // (h) play_music with query and no mode -> plays it directly (mode=play by default).
    @Test fun play_music_with_query_plays_by_default() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "play_music", """{"query":"Кино"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("Кино", out.getString("playing"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("play", payload.getString("mode"))
        assertEquals("Кино", payload.getString("query"))
    }

    // (h2) play_music with query and mode=search -> only opens the search screen.
    @Test fun play_music_with_query_and_search_mode_only_searches() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "play_music", """{"query":"Кино","mode":"search"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("Кино", out.getString("playing"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("search", payload.getString("mode"))
        assertEquals("Кино", payload.getString("query"))
    }

    // (i) dispatcher failure -> Russian error JSON.
    @Test fun play_music_dispatch_failure_reports_error() = runTest {
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "не получилось включить музыку")
        val out = JSONObject(tools().execute(AgentToolCall("1", "play_music", "{}")))
        assertFalse(out.has("ok"))
        assertEquals("не получилось включить музыку", out.getString("error"))
    }

    // --- youtube ---

    // (a) play mode (default) -> dispatches kind=youtube mode=play with query.
    @Test fun youtube_play_dispatches_youtube_kind() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "youtube", """{"query":"обзор leopard 3"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("обзор leopard 3", out.getString("playing"))
        assertEquals("youtube", captured.captured.kind)
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("play", payload.getString("mode"))
        assertEquals("обзор leopard 3", payload.getString("query"))
    }

    // (b) mode=search is forwarded as-is.
    @Test fun youtube_search_mode_is_forwarded() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "youtube", """{"query":"тест драйв","mode":"search"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("тест драйв", out.getString("searching"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("search", payload.getString("mode"))
        assertEquals("тест драйв", payload.getString("query"))
    }

    // (c) empty query -> BAD_ARGS_ERROR, dispatcher never called.
    @Test fun youtube_empty_query_reports_bad_args() = runTest {
        val out = JSONObject(tools().execute(AgentToolCall("1", "youtube", "{}")))
        assertTrue(out.has("error"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // --- launch_app ---

    // Four-app fixture: label -> package. Includes «Навигатор» and «Настройки».
    private val launcherFixture = listOf(
        "Навигатор" to "ru.yandex.yandexnavi",
        "Настройки" to "com.android.settings",
        "Яндекс Музыка" to "ru.yandex.music",
        "Телефон" to "com.android.dialer",
    )

    // (a) exact case-insensitive match -> app_launch with the app's packageName.
    @Test fun launch_app_exact_match_dispatches_package() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val t = tools().apply { launcherAppsProvider = { launcherFixture } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"навигатор"}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("app_launch", captured.captured.kind)
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("ru.yandex.yandexnavi", payload.getString("packageName"))
    }

    // --- #334: "навигатор" follows «Навигатор для маршрутов» ---

    private fun chooseNavigator(value: String) {
        val prefs = mockk<SharedPreferences>()
        every { prefs.getString("route_navigator", null) } returns value
        every { context.getSharedPreferences("voice", Context.MODE_PRIVATE) } returns prefs
    }

    private val navigatorFixture = launcherFixture + listOf(
        "Waze" to "com.waze",
        "2ГИС" to "ru.dublgis.dgismobile",
        "Яндекс Карты" to "ru.yandex.yandexmaps",
    )

    private suspend fun launchedPackage(name: String, apps: List<Pair<String, String>>): String {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val t = tools().apply { launcherAppsProvider = { apps } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"$name"}""")))
        assertTrue(out.toString(), out.getBoolean("ok"))
        return JSONObject(captured.captured.payload!!).getString("packageName")
    }

    // Fails today: the alias is hardcoded to ru.yandex.yandexnavi.
    @Test fun launch_app_navigator_opens_waze_when_waze_is_chosen() = runTest {
        chooseNavigator("waze")
        assertEquals("com.waze", launchedPackage("навигатор", navigatorFixture))
    }

    // Fails today for the same reason.
    @Test fun launch_app_navigator_opens_2gis_when_2gis_is_chosen() = runTest {
        chooseNavigator("dgis")
        assertEquals("ru.dublgis.dgismobile", launchedPackage("навигатор", navigatorFixture))
    }

    @Test fun launch_app_navigator_opens_yandex_maps_when_maps_is_chosen() = runTest {
        chooseNavigator("maps")
        assertEquals("ru.yandex.yandexmaps", launchedPackage("навигатор", navigatorFixture))
    }

    // Guard: the chosen app is not installed -> Yandex Navigator, like routes do.
    @Test fun launch_app_navigator_falls_back_to_yandex_when_chosen_app_is_missing() = runTest {
        chooseNavigator("waze")
        assertEquals("ru.yandex.yandexnavi", launchedPackage("навигатор", launcherFixture))
    }

    // Guard: the explicit name keeps meaning Yandex whatever is chosen.
    @Test fun launch_app_yandex_navigator_name_stays_yandex_when_waze_is_chosen() = runTest {
        chooseNavigator("waze")
        assertEquals("ru.yandex.yandexnavi", launchedPackage("яндекс навигатор", navigatorFixture))
    }

    // (b) partial unambiguous match -> launches Settings.
    @Test fun launch_app_partial_unambiguous_launches() = runTest {
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val t = tools().apply { launcherAppsProvider = { launcherFixture } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"настрой"}""")))
        assertTrue(out.getBoolean("ok"))
        val payload = JSONObject(captured.captured.payload!!)
        assertEquals("com.android.settings", payload.getString("packageName"))
    }

    // (c) ambiguous partial match -> error listing candidates, dispatcher never called.
    @Test fun launch_app_ambiguous_reports_candidates() = runTest {
        val fixture = listOf(
            "Карты" to "ru.yandex.yandexmaps",
            "Карточки" to "com.example.cards",
        )
        val t = tools().apply { launcherAppsProvider = { fixture } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"карт"}""")))
        assertFalse(out.has("ok"))
        assertTrue(out.getString("error").contains("Карты"))
        assertTrue(out.getString("error").contains("Карточки"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (d) no match -> not-found error.
    @Test fun launch_app_not_found_reports_error() = runTest {
        val t = tools().apply { launcherAppsProvider = { launcherFixture } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"калькулятор"}""")))
        assertFalse(out.has("ok"))
        assertTrue(out.getString("error").contains("приложение не найдено"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (e) throwing provider -> error JSON, not a raw exception.
    @Test fun launch_app_provider_throws_reports_error() = runTest {
        val t = tools().apply { launcherAppsProvider = { throw RuntimeException("pm down") } }
        val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"навигатор"}""")))
        assertTrue(out.has("error"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // RU aliases of launch_app: BYD stock-app labels and package priority lists, not label matches.
    private class AliasCase(
        val label: String,
        val name: String,
        val apps: List<Pair<String, String>>?, // null = launcherFixture
        val expectedPackage: String?,          // null = not-found error, nothing dispatched
        val expectedApp: String? = null,
    )

    @Test fun launch_app_aliases_resolve_to_the_installed_package() = runTest {
        val cases = listOf(
            // alias "камера" resolves to the Chinese label via com.byd.avc.
            AliasCase("camera resolves the Chinese label", "камера",
                listOf("全景影像" to "com.byd.avc"), "com.byd.avc", expectedApp = "全景影像"),
            // alias lookup is case-insensitive.
            AliasCase("camera alias is case-insensitive", "Камера",
                listOf("全景影像" to "com.byd.avc"), "com.byd.avc", expectedApp = "全景影像"),
            // alias "ютуб" has two candidate packages in priority order; only the second is installed.
            AliasCase("youtube falls back to the second candidate", "ютуб",
                listOf("YouTube" to "com.google.android.youtube"), "com.google.android.youtube"),
            // alias "видеорегистратор" has no candidate installed and no label match -> not-found error.
            AliasCase("dashcam not installed reports not found", "видеорегистратор", null, null),
            // alias "яндекс карты" picks the first installed candidate of the Maps package list.
            AliasCase("yandex maps resolves the installed package", "яндекс карты",
                listOf("Яндекс Карты" to "ru.yandex.yandexmaps.rustore"), "ru.yandex.yandexmaps.rustore"),
            // alias "телефон" points at the BYD bluetooth dialer, not at a label match.
            AliasCase("phone resolves the BYD dialer", "телефон",
                listOf("Телефон" to "com.android.dialer", "蓝牙电话" to "com.byd.bluetoothcall"),
                "com.byd.bluetoothcall"),
            // alias "медиацентр" resolves the stock media app.
            AliasCase("mediacenter resolves the stock player", "медиацентр",
                listOf("多媒体" to "com.byd.mediacenter"), "com.byd.mediacenter"),
        )
        for (c in cases) {
            clearMocks(dispatcher)
            val captured = slot<ActionDef>()
            coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
            val fixture = c.apps ?: launcherFixture
            val t = tools().apply { launcherAppsProvider = { fixture } }
            val out = JSONObject(t.execute(AgentToolCall("1", "launch_app", """{"name":"${c.name}"}""")))
            if (c.expectedPackage == null) {
                assertFalse("case: ${c.label}: $out", out.has("ok"))
                assertTrue("case: ${c.label}: $out", out.getString("error").contains("приложение не найдено"))
                coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
            } else {
                assertTrue("case: ${c.label}: $out", out.getBoolean("ok"))
                c.expectedApp?.let { assertEquals("case: ${c.label}", it, out.getString("app")) }
                assertEquals("case: ${c.label}", "app_launch", captured.captured.kind)
                val payload = JSONObject(captured.captured.payload!!)
                assertEquals("case: ${c.label}", c.expectedPackage, payload.getString("packageName"))
            }
        }
    }

    // --- set_cluster_projection ---

    // (a) on=true, before=OFF -> dispatched as a cluster_projection action, ok:true with label.
    // The dispatcher owns the mode poll, so the tool never polls a second time.
    @Test fun cluster_projection_on_dispatches_and_confirms() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.OFF
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":true}""")))
        assertTrue(out.getBoolean("ok"))
        assertFalse(out.has("note"))
        assertEquals("Навигатор", out.getString("app"))
        assertEquals("cluster_projection", captured.captured.kind)
        assertEquals("1", captured.captured.payload)
        verify(exactly = 0) { clusterVoiceControl.apply(any()) }
    }

    // (b) on=true, before=FULLSCREEN -> nothing dispatched, ok:true "already" note with label.
    @Test fun cluster_projection_on_when_already_on_is_noop() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.FULLSCREEN
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":true}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("Навигатор уже на приборке", out.getString("note"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (c) the dispatcher reports the projection never came up -> retry hint. Wave P: the
    // compositor is powered automatically around projection, so the old manual "Full + Navi"
    // precondition hint is gone; the honest advice is to retry in a few seconds.
    @Test fun cluster_projection_on_stuck_reports_retry_hint() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.OFF
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "проекция на приборку не включилась")
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":true}""")))
        assertFalse(out.has("ok"))
        val error = out.getString("error")
        assertTrue(error.contains("Попробуй повторить"))
        assertFalse(error.contains("Navi"))
    }

    // (c2) the dispatcher blames the restarting daemon -> honest note, not a plain failure.
    @Test fun cluster_projection_on_stuck_daemon_down_reports_honest_note() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.OFF
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "служебный процесс перезапускается", daemonRestarting = true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":true}""")))
        assertFalse(out.getBoolean("ok"))
        val note = out.getString("note")
        assertTrue(note.contains("попробуй ещё раз"))
        assertFalse(note.contains("Navi"))
    }

    // (d) on=false, before=FULLSCREEN -> dispatched with payload "0", ok:true.
    @Test fun cluster_projection_off_dispatches_and_confirms() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.FULLSCREEN
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        val captured = slot<ActionDef>()
        coEvery { dispatcher.dispatch(capture(captured), any()) } returns DispatchResult(true)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":false}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("0", captured.captured.payload)
    }

    // (e) on=false, before=OFF -> nothing dispatched, note "проекции уже нет".
    @Test fun cluster_projection_off_when_already_off_is_noop() = runTest {
        every { clusterVoiceControl.projectionMode() } returns ClusterMode.OFF
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":false}""")))
        assertTrue(out.getBoolean("ok"))
        assertEquals("проекции уже нет на приборке", out.getString("note"))
        coVerify(exactly = 0) { dispatcher.dispatch(any(), any()) }
    }

    // (f) projectionMode() throws -> treated as OFF, not propagated; on=true still dispatches.
    @Test fun cluster_projection_unreadable_state_treated_as_off_and_still_actuates() = runTest {
        every { clusterVoiceControl.projectionMode() } throws RuntimeException("boom")
        every { clusterVoiceControl.projectedAppLabel() } returns "Навигатор"
        coEvery { dispatcher.dispatch(any(), any()) } returns
            DispatchResult(false, "проекция на приборку не включилась")
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", """{"on":true}""")))
        assertTrue(out.has("error"))
        coVerify { dispatcher.dispatch(match { it.kind == "cluster_projection" }, any()) }
    }

    // missing "on" argument -> error, apply not called.
    @Test fun cluster_projection_missing_on_reports_error() = runTest {
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "set_cluster_projection", "{}")))
        assertTrue(out.has("error"))
        verify(exactly = 0) { clusterVoiceControl.apply(any()) }
    }
}
