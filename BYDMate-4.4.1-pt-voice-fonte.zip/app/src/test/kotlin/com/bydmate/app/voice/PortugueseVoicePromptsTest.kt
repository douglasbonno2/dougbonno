package com.bydmate.app.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class PortugueseVoicePromptsTest {
    @Test fun `successful and failed commands remain distinguishable`() {
        assertEquals("Pronto.", PortugueseVoicePrompts.outcome("Готово"))
        assertEquals("Não foi possível executar a ação.", PortugueseVoicePrompts.outcome("Не получилось"))
    }
    @Test fun `Portuguese replies including distances pass through unchanged`() {
        val text = "Você percorreu 12,5 quilômetros."
        assertEquals(text, PortugueseVoicePrompts.outcome(text))
    }
    @Test fun `untranslated details do not become a spoken success claim`() {
        assertEquals("Consulte os detalhes da resposta na tela.",
            PortugueseVoicePrompts.outcome("Нет связи с автомобилем"))
    }
}
