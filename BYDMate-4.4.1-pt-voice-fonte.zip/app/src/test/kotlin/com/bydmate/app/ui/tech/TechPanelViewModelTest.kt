package com.bydmate.app.ui.tech

import com.bydmate.app.data.autoservice.Pm25
import com.bydmate.app.data.autoservice.Pm25Reader
import com.bydmate.app.data.carstatus.CarServiceStatus
import com.bydmate.app.data.carstatus.CarStatusReader
import com.bydmate.app.data.dtc.DtcScanPhase
import com.bydmate.app.data.dtc.DtcScanRepository
import com.bydmate.app.data.dtc.DtcScanState
import com.bydmate.app.data.nativestack.HybridTechFixture
import com.bydmate.app.data.nativestack.MotorSplit
import com.bydmate.app.data.nativestack.motorSplitPercent
import com.bydmate.app.domain.battery.AvgSoc
import com.bydmate.app.domain.battery.AvgSocProvider
import com.bydmate.app.domain.battery.BatteryState
import com.bydmate.app.data.local.entity.ChargeEntity
import com.bydmate.app.data.repository.ChargeRepository
import com.bydmate.app.data.repository.LifetimeChargingStats
import com.bydmate.app.data.remote.DiParsData
import com.bydmate.app.data.remote.diParsData
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.domain.battery.BatteryStateRepository
import com.bydmate.app.service.TrackingService
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import io.mockk.coVerify
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class TechPanelViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    /** Owns every view model built here so @After cancels their collectors on the static
     *  TrackingService flows — resetMain() alone would leave them running across tests. */
    private val store = ViewModelStore()

    @Before fun setUp() {
        Dispatchers.setMain(testDispatcher)
        savedOrder = ""
        hintSeen = false
        hintFlagWrites = 0
        chargeLog.value = emptyList()
        dtcScanState = MutableStateFlow(DtcScanState())
    }

    @After fun tearDown() {
        store.clear()
        connectedFlow().value = true
        liveDataFlow().value = null
        runningFlow().value = false
        Dispatchers.resetMain()
    }

    /** The service publishes its transport flag from inside the service; tests reach the
     *  backing MutableStateFlow directly, the way the cluster tests reach their singletons. */
    private fun connectedFlow(): MutableStateFlow<Boolean> {
        @Suppress("UNCHECKED_CAST")
        return TrackingService::class.java
            .getDeclaredField("_vehicleDataConnected")
            .apply { isAccessible = true }
            .get(null) as MutableStateFlow<Boolean>
    }

    /** The poll snapshot the screen reads, reached the same way as the transport flag above. */
    private fun liveDataFlow(): MutableStateFlow<DiParsData?> {
        @Suppress("UNCHECKED_CAST")
        return TrackingService::class.java
            .getDeclaredField("_lastData")
            .apply { isAccessible = true }
            .get(null) as MutableStateFlow<DiParsData?>
    }

    /** The scan repository the Diagnostics card reads; [dtcScanState] is the state it reports. */
    private var dtcScanState = MutableStateFlow(DtcScanState())

    private fun dtcRepo(): DtcScanRepository = mockk<DtcScanRepository>(relaxed = true).also {
        every { it.state } returns dtcScanState
        every { it.last } returns MutableStateFlow(null)
    }

    /** The service's own running flag, reached the same way as the transport flag. */
    private fun runningFlow(): MutableStateFlow<Boolean> {
        @Suppress("UNCHECKED_CAST")
        return TrackingService::class.java
            .getDeclaredField("_isRunning")
            .apply { isAccessible = true }
            .get(null) as MutableStateFlow<Boolean>
    }

    /** Scoped so [store] can clear it; a bare constructor call leaks its viewModelScope. */
    private fun scoped(vm: TechPanelViewModel): TechPanelViewModel {
        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = vm as T
        }
        return ViewModelProvider(store, factory)[TechPanelViewModel::class.java]
    }

    /** The two settings rows the card order lives in, kept in memory across reads and writes. */
    private var savedOrder = ""
    private var hintSeen = false
    private var hintFlagWrites = 0

    /** The live charge log the calibration rows observe. */
    private val chargeLog = MutableStateFlow<List<ChargeEntity>>(emptyList())

    private fun settings(): SettingsRepository = mockk<SettingsRepository>(relaxed = true).also { r ->
        coEvery { r.getTechCardOrder() } answers { savedOrder }
        coEvery { r.setTechCardOrder(any()) } answers { savedOrder = firstArg() }
        coEvery { r.isTechOrderHintSeen() } answers { hintSeen }
        coEvery { r.setTechOrderHintSeen() } answers { hintFlagWrites++; hintSeen = true }
    }

    /** The stock provider as the screen sees it: a snapshot, or null when the car has none. */
    private fun carStatusReader(snapshot: CarServiceStatus?): CarStatusReader = mockk<CarStatusReader>().also {
        coEvery { it.read() } returns snapshot
        every { it.changes() } returns emptyFlow()
    }

    /** The on-demand PM2.5 read: [answer] is what every call returns (null = no sensor). */
    private fun pm25Reader(answer: Pm25?): Pm25Reader = mockk<Pm25Reader>().also {
        coEvery { it.read() } returns answer
    }

    @Suppress("LongParameterList") // test factory: every override is optional
    private fun buildViewModel(
        battery: BatteryState? = null,
        avg: AvgSoc = AvgSoc(null, null),
        lifetimeCharged: LifetimeChargingStats? = null,
        capacityKwh: Double = 72.9,
        kind: com.bydmate.app.data.nativestack.VehicleKind = com.bydmate.app.data.nativestack.VehicleKind.EV,
        carStatus: CarServiceStatus? = null,
        pm25: Pm25Reader = pm25Reader(null),
    ): TechPanelViewModel {
        val repo = mockk<BatteryStateRepository>()
        coEvery { repo.refresh() } returns (
            battery ?: BatteryState(null, null, null, null, autoserviceAvailable = false)
            )
        val avgProvider = mockk<AvgSocProvider>()
        coEvery { avgProvider.compute(any()) } returns avg
        val charges = mockk<ChargeRepository>()
        coEvery { charges.getLifetimeStats() } returns (
            lifetimeCharged ?: LifetimeChargingStats(0.0, 0.0, 0.0, 0)
            )
        every { charges.getAllCharges() } returns chargeLog
        val settings = settings().also { coEvery { it.getBatteryCapacity() } returns capacityKwh }
        return scoped(TechPanelViewModel(repo, avgProvider, settings, charges, com.bydmate.app.data.nativestack.kindMonitor(kind), carStatusReader(carStatus), dtcRepo(), pm25))
    }

    // --- null mapping -------------------------------------------------------

    /** A firmware that answers nothing leaves every card hidden, which is what drives the
     *  «Машина не отдаёт эти данные» placeholder. */
    @Test
    fun `without any live value every card is hidden`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        val state = vm.uiState.value
        assertFalse(state.showBatteryNow)
        assertFalse(state.showLimitsAndCells)
        assertFalse(state.showMotors)
        assertFalse(state.showClimate)
        assertFalse(state.showTyres)
        assertFalse(state.showHistory)
        assertFalse(state.hasAnyCard)
    }

    /** The header cue follows the live transport flag, both ways — it must not stay on the
     *  value the on-open autoservice read happened to see. */
    @Test
    fun `online flag follows the live connection flag`() = runTest {
        val vm = buildViewModel(
            battery = BatteryState(
                socNow = 43f, sohPercent = 99f,
                lifetimeKm = 3802f, lifetimeKwh = 1240f, autoserviceAvailable = true,
            ),
        )
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(true, vm.uiState.value.autoserviceOnline)

        connectedFlow().value = false
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(false, vm.uiState.value.autoserviceOnline)

        connectedFlow().value = true
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(true, vm.uiState.value.autoserviceOnline)
    }

    /** SoH and the lifetime counters come from the one-shot autoservice read on open. */
    @Test
    fun `battery state read on open fills SoH, lifetime and the online flag`() = runTest {
        val vm = buildViewModel(
            battery = BatteryState(
                socNow = 43f, sohPercent = 99f,
                lifetimeKm = 3802f, lifetimeKwh = 1240f, autoserviceAvailable = true,
            ),
            avg = AvgSoc(sinceCharge = 52, allTime = 58),
        )
        testDispatcher.scheduler.advanceUntilIdle()

        val state = vm.uiState.value
        assertEquals(99f, state.soh)
        assertEquals(3802f, state.lifetimeKm)
        assertEquals(1240f, state.lifetimeKwh)
        assertEquals(52, state.avgSocSinceCharge)
        assertEquals(58, state.avgSocAllTime)
        assertEquals(true, state.autoserviceOnline)
        assertTrue("SoH alone must open the battery card", state.showBatteryNow)
        assertTrue(state.showHistory)
        assertTrue(state.hasAnyCard)
        // Nothing live arrived, so the vehicle-side cards stay hidden.
        assertFalse(state.showMotors)
        assertFalse(state.showTyres)
    }

    /** The BMS remaining energy rides the poll snapshot, and alone it opens the battery card. */
    @Test
    fun `remaining energy from the poll snapshot reaches the battery card`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertNull(vm.uiState.value.remainKwh)

        liveDataFlow().value = diParsData().copy(batteryRemainKwh = 72.0)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(72.0, vm.uiState.value.remainKwh!!, 0.001)
        assertTrue("remaining energy alone must open the battery card", vm.uiState.value.showBatteryNow)
    }

    /**
     * The row follows the snapshot, it does not hold the last number: a car that stops
     * answering the fid must show «—», not a reading taken minutes ago.
     */
    @Test
    fun `remaining energy goes back to null when the fid stops answering`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        liveDataFlow().value = diParsData().copy(batteryRemainKwh = 72.0)
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(72.0, vm.uiState.value.remainKwh!!, 0.001)

        liveDataFlow().value = diParsData(soc = 95)
        testDispatcher.scheduler.advanceUntilIdle()
        assertNull(vm.uiState.value.remainKwh)
    }

    /**
     * Hybrid dump 2026-10-04: SoC 39% and the remaining-energy fid answers 0.0, never pushing an
     * event. A pack holding charge cannot be empty, so the row is «—»; the rear inverter's 202 °C
     * is «—» too, the rear motor's real 12 °C stays.
     */
    @Test
    fun `hybrid dump shows a dash for zero remaining energy and the impossible inverter temp`() = runTest {
        val vm = buildViewModel(capacityKwh = 31.8)
        testDispatcher.scheduler.advanceUntilIdle()

        liveDataFlow().value = HybridTechFixture.snapshot()
        testDispatcher.scheduler.advanceUntilIdle()

        val state = vm.uiState.value
        assertEquals(39, state.soc)
        assertNull(state.remainKwh)
        assertNull(state.inverterTempRear)
        assertEquals(12, state.motorTempRear)
        assertTrue(state.showBatteryNow)
    }

    /** Leopard 3, 2026-09-23 on the car: SoC 63%, the BMS reports 42.9 kWh — shown as is. */
    @Test
    fun `a real remaining energy still reaches the battery card`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        liveDataFlow().value = diParsData(soc = 63).copy(batteryRemainKwh = 42.9)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(42.9, vm.uiState.value.remainKwh!!, 0.001)
    }

    /** At SoC 0 an empty pack is the truth, so 0 kWh is a reading, not a placeholder. */
    @Test
    fun `zero remaining energy at zero SoC is shown as zero`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        liveDataFlow().value = diParsData(soc = 0).copy(batteryRemainKwh = 0.0)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(0.0, vm.uiState.value.remainKwh!!, 0.0)
    }

    /**
     * A failing autoservice read must not blank the screen. It reports offline, and once the
     * live transport flag speaks that flag has the last word — a read that failed while the
     * bus is up must not leave the header stuck on «offline».
     */
    @Test
    fun `failed battery read reports offline while the transport is down`() = runTest {
        connectedFlow().value = false
        val repo = mockk<BatteryStateRepository>()
        coEvery { repo.refresh() } throws IllegalStateException("adb down")
        val avgProvider = mockk<AvgSocProvider>()
        coEvery { avgProvider.compute(any()) } returns AvgSoc(null, null)

        val vm = scoped(TechPanelViewModel(repo, avgProvider, settings(), mockk(relaxed = true), com.bydmate.app.data.nativestack.kindMonitor(), carStatusReader(null), dtcRepo(), pm25Reader(null)))
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(false, vm.uiState.value.autoserviceOnline)

        connectedFlow().value = true
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(true, vm.uiState.value.autoserviceOnline)
    }

    // --- hints --------------------------------------------------------------

    @Test
    fun `only one hint is open at a time`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertNull(vm.uiState.value.openHint)
        vm.toggleHint("insulation")
        assertEquals("insulation", vm.uiState.value.openHint)
        vm.toggleHint("cells")
        assertEquals("cells", vm.uiState.value.openHint)
        vm.toggleHint("cells")
        assertNull("tapping the open hint closes it", vm.uiState.value.openHint)
    }

    // --- derived values -----------------------------------------------------

    /** 1% of a 72.9 kWh pack is 729 W·h, so 1458 W drains 2%/h. */
    @Test
    fun `percent per hour follows power over capacity`() {
        val state = TechPanelUiState(batteryPowerW = 1458.0, batteryCapacityKwh = 72.9)
        assertEquals(2.0, state.percentPerHour!!, 0.0001)
    }

    /** Charging is negative power (#153) and keeps its sign in %/h. */
    @Test
    fun `percent per hour keeps the charging sign`() {
        val state = TechPanelUiState(batteryPowerW = -7290.0, batteryCapacityKwh = 72.9)
        assertEquals(-10.0, state.percentPerHour!!, 0.0001)
    }

    @Test
    fun `percent per hour is unknown without a capacity or without power`() {
        assertNull(TechPanelUiState(batteryPowerW = 1458.0).percentPerHour)
        assertNull(TechPanelUiState(batteryPowerW = 1458.0, batteryCapacityKwh = 0.0).percentPerHour)
        assertNull(TechPanelUiState(batteryCapacityKwh = 72.9).percentPerHour)
    }

    @Test
    fun `cell delta needs both ends`() {
        assertEquals(0.011, TechPanelUiState(cellMin = 3.301, cellMax = 3.312).cellDelta!!, 0.0001)
        assertNull(TechPanelUiState(cellMin = 3.301).cellDelta)
        assertNull(TechPanelUiState(cellMax = 3.312).cellDelta)
    }

    /** One live reading is enough to draw its card; the others stay hidden. */
    @Test
    fun `a single live reading opens only its own card`() {
        val state = TechPanelUiState(compressorW = 576)
        assertTrue(state.showClimate)
        assertFalse(state.showBatteryNow)
        assertFalse(state.showMotors)
        assertTrue(state.hasAnyCard)
    }

    /** Idle reads -1 from the front motor fid; reverse really is negative and must survive. */
    @Test
    fun `idle rpm shows as zero and reverse keeps its sign`() {
        assertEquals("0", rpmForDisplay(-1)?.toString())
        assertEquals("0", rpmForDisplay(0)?.toString())
        assertEquals("-370", rpmForDisplay(-370)?.toString())
        assertEquals("1200", rpmForDisplay(1200)?.toString())
        assertNull(rpmForDisplay(null))
    }

    /** #403: the car never reports the inverter below 30 (cold start at 4° outside, motors 8-11°,
     *  inverters 30), so 30 means "30 or colder" and shows as a dash; 31+ is a real reading. */
    @Test
    fun `inverter temperature at the 30 degree floor shows as unknown`() {
        assertNull(inverterTempForDisplay(30))
        assertEquals(31, inverterTempForDisplay(31))
        assertEquals(37, inverterTempForDisplay(37))
        assertEquals(25, inverterTempForDisplay(25))
        assertNull(inverterTempForDisplay(null))
    }

    /** Measured on the car: the split follows the two motor currents on a shared bus. */
    @Test
    fun `motor split follows the current ratio`() {
        assertEquals(MotorSplit.Share(15, 85), motorSplitPercent(7.9f, 45.3f))
        assertEquals(MotorSplit.Share(12, 88), motorSplitPercent(0.6f, 4.5f))
        assertEquals(MotorSplit.Share(0, 100), motorSplitPercent(0.0f, 5.7f))
        assertEquals(MotorSplit.Share(100, 0), motorSplitPercent(5.7f, 0.0f))
    }

    /** Regeneration sign is unverified, so only the magnitudes decide the split. */
    @Test
    fun `motor split ignores the sign of the currents`() {
        assertEquals(MotorSplit.Share(15, 85), motorSplitPercent(-7.9f, -45.3f))
        assertEquals(MotorSplit.Share(15, 85), motorSplitPercent(7.9f, -45.3f))
    }

    /** Parked: both motors idle, so the row shows dashes instead of an invented 50/50. */
    @Test
    fun `motor split is idle while the car draws nothing`() {
        assertEquals(MotorSplit.Idle, motorSplitPercent(0.0f, 0.0f))
        assertEquals(MotorSplit.Idle, motorSplitPercent(0.2f, 0.2f))
    }

    /** A car that does not report the pair (single motor) hides the row entirely. */
    @Test
    fun `motor split is null when either current is missing`() {
        assertNull(motorSplitPercent(null, null))
        assertNull(motorSplitPercent(1.0f, null))
        assertNull(motorSplitPercent(null, 1.0f))
    }

    /** The motor currents alone are enough to draw the motors card. */
    @Test
    fun `motor currents open the motors card`() {
        assertTrue(TechPanelUiState(motorCurrentFront = 7.9f, motorCurrentRear = 45.3f).showMotors)
    }

    // --- card order ---------------------------------------------------------

    @Test
    fun `without a saved order the cards keep their factory places`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(TechCardOrder.DEFAULT, vm.uiState.value.cardOrder)
        assertTrue("first open must explain the gesture", vm.uiState.value.showOrderHint)
    }

    @Test
    fun `a saved order is restored on open`() = runTest {
        savedOrder = "tyres,motors,battery_now,limits,history,climate"
        hintSeen = true
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(
            listOf(
                TechCard.CAR_STATE, TechCard.MOTORS, TechCard.BATTERY_NOW,
                TechCard.LIMITS, TechCard.HISTORY, TechCard.DIAGNOSTICS,
            ),
            vm.uiState.value.cardOrder,
        )
        assertFalse("the hint is retired once a drag has happened", vm.uiState.value.showOrderHint)
    }

    /** A version that adds a card must not drop it just because the stored order predates it;
     *  an id that no longer exists must not crash the screen either. */
    @Test
    fun `cards missing from the saved order are appended, unknown ids ignored`() = runTest {
        savedOrder = "tyres,ghost_card,motors"
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(
            listOf(
                TechCard.CAR_STATE, TechCard.MOTORS, TechCard.BATTERY_NOW,
                TechCard.LIMITS, TechCard.HISTORY, TechCard.DIAGNOSTICS,
            ),
            vm.uiState.value.cardOrder,
        )
    }

    @Test
    fun `a drag persists the new order and retires the hint`() = runTest {
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()

        vm.moveCard(TechCard.CAR_STATE, TechCard.BATTERY_NOW)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(TechCard.CAR_STATE, vm.uiState.value.cardOrder.first())
        assertEquals("climate,battery_now,limits,history,motors,diagnostics", savedOrder)
        assertTrue(hintSeen)
        assertFalse(vm.uiState.value.showOrderHint)

        // The flag is already set: a second drag must not write it again.
        vm.moveCard(TechCard.DIAGNOSTICS, TechCard.CAR_STATE)
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(1, hintFlagWrites)
    }

    /** Hidden cards drop out of the grid but keep their place in the stored order. */
    @Test
    fun `only the cards with data are laid out`() {
        val state = TechPanelUiState(
            cardOrder = listOf(
                TechCard.CAR_STATE, TechCard.MOTORS, TechCard.BATTERY_NOW,
                TechCard.LIMITS, TechCard.HISTORY, TechCard.DIAGNOSTICS,
            ),
            motorRpmFront = 1200,
            soc = 43,
        )
        assertEquals(listOf(TechCard.MOTORS, TechCard.BATTERY_NOW), state.visibleCards)
    }

    /** DM-i (#184): a hybrid gets the fuel card appended to an order saved before it, and a drag stores it. */
    @Test
    fun `a hybrid appends the fuel card to the saved order and persists it`() = runTest {
        savedOrder = "tyres,motors,battery_now,limits,history,climate"
        val vm = buildViewModel(kind = com.bydmate.app.data.nativestack.VehicleKind.HYBRID)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(TechCard.FUEL, vm.uiState.value.cardOrder.last())
        vm.moveCard(TechCard.FUEL, TechCard.CAR_STATE)
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals("fuel,climate,motors,battery_now,limits,history,diagnostics", savedOrder)
    }

    /** DM-i (#184): the fuel card needs a confirmed hybrid; an EV never lays it out. */
    @Test
    fun `the fuel card shows only on a hybrid with a fuel reading`() {
        val withFuel = TechPanelUiState(fuelPercent = 54, fuelRangeKm = 512)
        assertFalse(withFuel.copy(vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.EV).showFuel)
        assertFalse(withFuel.copy(vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.UNKNOWN).showFuel)
        assertTrue(withFuel.copy(vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.HYBRID).showFuel)
        assertFalse(TechPanelUiState(vehicleKind = com.bydmate.app.data.nativestack.VehicleKind.HYBRID).showFuel)
    }

    @Test
    fun `an EV keeps today's visible cards`() {
        val state = TechPanelUiState(motorRpmFront = 1200, soc = 43)
        assertEquals(listOf(TechCard.BATTERY_NOW, TechCard.MOTORS), state.visibleCards)
    }

    // --- full cycles --------------------------------------------------------

    /** The fallback divisor of the row: the logged charging sum and the pack size from settings. */
    @Test
    fun `lifetime charged kWh and the pack size reach the state`() = runTest {
        val vm = buildViewModel(
            lifetimeCharged = LifetimeChargingStats(totalKwhAdded = 6340.0, acKwh = 6000.0, dcKwh = 340.0, sessionCount = 90),
            capacityKwh = 72.9,
        )
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(6340.0, vm.uiState.value.lifetimeChargedKwh!!, 1e-9)
        assertEquals(72.9, vm.uiState.value.nominalCapacityKwh, 1e-9)
    }

    /** The row moved into «Батарея · история», so a car whose only number is the logged sum
     *  must still open that card — otherwise the cycles would disappear with it. */
    @Test
    fun `logged charges alone open the history card`() = runTest {
        val vm = buildViewModel(
            lifetimeCharged = LifetimeChargingStats(totalKwhAdded = 1557.0, acKwh = 1557.0, dcKwh = 0.0, sessionCount = 40),
        )
        testDispatcher.scheduler.advanceUntilIdle()

        val state = vm.uiState.value
        assertNull(state.lifetimeKwh)
        assertTrue(state.showHistory)
    }

    /** The unplug catch-up lands the charge row up to ~30 s after the gun comes out; a screen
     *  opened in that window must pick the row up instead of keeping the previous full charge. */
    @Test
    fun `a full charge logged while the screen is open updates the marks`() = runTest {
        val dayMs = 86_400_000L
        val older = ChargeEntity(startTs = 10 * dayMs, endTs = 10 * dayMs, socStart = 30, socEnd = 100, status = "COMPLETED")
        chargeLog.value = listOf(older)
        val vm = buildViewModel()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(10 * dayMs, vm.uiState.value.lastFullChargeTs)

        val fresh = ChargeEntity(startTs = 15 * dayMs, endTs = 15 * dayMs, socStart = 25, socEnd = 100, status = "COMPLETED")
        chargeLog.value = listOf(fresh, older)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(15 * dayMs, vm.uiState.value.lastFullChargeTs)
    }

    // --- «Состояние машины» and «Диагностика» ------------------------------------

    private val noData get() = diParsData()

    private suspend fun TestScope.openWith(data: DiParsData?, carStatus: CarServiceStatus? = null): TechPanelUiState {
        liveDataFlow().value = data
        val vm = buildViewModel(carStatus = carStatus)
        testDispatcher.scheduler.advanceUntilIdle()
        return vm.uiState.value
    }

    @Test
    fun `car-state card shows from tyres alone or climate alone`() = runTest {
        val cases = listOf(
            "tyres alone" to noData.copy(tirePressFL = 245),
            "climate alone" to noData.copy(insideTemp = 22),
        )
        for ((label, data) in cases) {
            assertTrue("case: $label", openWith(data).isVisible(TechCard.CAR_STATE))
        }
    }

    @Test
    fun `car-state card shows from pm25 alone`() = runTest {
        liveDataFlow().value = noData
        val vm = buildViewModel(pm25 = pm25Reader(Pm25(8, null, 1, null)))
        backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        val state = vm.uiState.value
        assertEquals(8, state.pm25InShown)
        assertTrue(state.isVisible(TechCard.CAR_STATE))
    }

    @Test
    fun `no sensor - the reader is asked once and never again while the screen stays open`() = runTest {
        val reader = pm25Reader(null)
        val vm = buildViewModel(pm25 = reader)
        backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(5 * 60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 1) { reader.read() }
        assertNull(vm.uiState.value.pm25InShown)
        assertNull(vm.uiState.value.pm25OutShown)
    }

    @Test
    fun `sensor present - shown at once and refreshed once a minute`() = runTest {
        val reader = pm25Reader(Pm25(8, null, 2, null))
        val vm = buildViewModel(pm25 = reader)
        backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        assertEquals(8, vm.uiState.value.pm25InShown)
        coVerify(exactly = 1) { reader.read() }
        testDispatcher.scheduler.advanceTimeBy(60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 2) { reader.read() }
        testDispatcher.scheduler.advanceTimeBy(60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 3) { reader.read() }
    }

    @Test
    fun `a failed read after a sensor was seen clears the values and polling goes on`() = runTest {
        val reader = mockk<Pm25Reader>()
        coEvery { reader.read() } returnsMany listOf(Pm25(8, null, 2, null), null)
        val vm = buildViewModel(pm25 = reader)
        backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        assertEquals(8, vm.uiState.value.pm25InShown)
        testDispatcher.scheduler.advanceTimeBy(60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 2) { reader.read() }
        assertNull(vm.uiState.value.pm25InShown)
        testDispatcher.scheduler.advanceTimeBy(60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 3) { reader.read() }
    }

    @Test
    fun `back on the screen, a failed first read clears a sensor seen before and polling goes on`() = runTest {
        val reader = mockk<Pm25Reader>()
        coEvery { reader.read() } returnsMany listOf(Pm25(8, null, 2, null), null, Pm25(9, null, 2, null))
        val vm = buildViewModel(pm25 = reader)
        val first = backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        assertEquals(8, vm.uiState.value.pm25InShown)
        first.cancel()

        backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        assertNull(vm.uiState.value.pm25InShown)
        testDispatcher.scheduler.advanceTimeBy(60_000L)
        testDispatcher.scheduler.runCurrent()
        assertEquals(9, vm.uiState.value.pm25InShown)
    }

    @Test
    fun `nothing reads pm25 until the screen is shown, and leaving it stops the refresh`() = runTest {
        val reader = pm25Reader(Pm25(8, null, 2, null))
        val vm = buildViewModel(pm25 = reader)
        coVerify(exactly = 0) { reader.read() }
        val shown = backgroundScope.launch { vm.pollPm25() }
        testDispatcher.scheduler.advanceTimeBy(1)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 1) { reader.read() }
        shown.cancel()
        testDispatcher.scheduler.advanceTimeBy(5 * 60_000L)
        testDispatcher.scheduler.runCurrent()
        coVerify(exactly = 1) { reader.read() }
    }

    @Test
    fun `pm25 value is shown only with a valid level`() {
        val state = TechPanelUiState(pm25In = 8, pm25LevelIn = 1, pm25Out = 0, pm25LevelOut = 0)
        assertEquals(8, state.pm25InShown)
        assertNull(state.pm25OutShown)
        assertNull(TechPanelUiState(pm25In = 8).pm25InShown)
        assertEquals(40, TechPanelUiState(pm25Out = 40, pm25LevelOut = 6).pm25OutShown)
    }

    @Test
    fun `pm25 with level zero hides the row`() {
        assertNull(TechPanelUiState(pm25In = 0, pm25LevelIn = 0).pm25InShown)
        assertNull(TechPanelUiState(pm25In = 12, pm25LevelIn = 0).pm25InShown)
    }

    @Test
    fun `diagnostics card shows with provider rows and zero warnings`() = runTest {
        val state = openWith(null, CarServiceStatus(faults = 0, daysLeft = null, kmLeft = null))
        assertEquals(0, state.faultCount)
        assertTrue(state.isVisible(TechCard.DIAGNOSTICS))
    }

    @Test
    fun `diagnostics card carries the service countdown`() = runTest {
        val state = openWith(null, CarServiceStatus(faults = 2, daysLeft = 278, kmLeft = 27609))
        assertEquals(2, state.faultCount)
        assertEquals(278, state.serviceDaysLeft)
        assertEquals(27609, state.serviceKmLeft)
    }

    @Test
    fun `diagnostics card is hidden when the provider is absent`() = runTest {
        val state = openWith(null, null)
        assertNull(state.faultCount)
        assertFalse(state.isVisible(TechCard.DIAGNOSTICS))
    }

    @Test
    fun `the service row needs at least one half`() {
        assertFalse(TechPanelUiState(serviceDaysLeft = null, serviceKmLeft = null).hasServiceRow)
        assertTrue(TechPanelUiState(serviceDaysLeft = 90).hasServiceRow)
        assertTrue(TechPanelUiState(serviceKmLeft = 3500).hasServiceRow)
    }

    // --- «Сканировать» button ---------------------------------------------------------

    private suspend fun TestScope.openScan(gear: Int?, running: Boolean = true): TechPanelUiState {
        runningFlow().value = running
        return openWith(noData.copy(gear = gear))
    }

    @Test
    fun `the scan button is enabled in P on a running service`() = runTest {
        val state = openScan(gear = 1)
        assertTrue(state.canScan)
        assertEquals(DtcScanLabel.SCAN, state.scanLabel)
    }

    @Test
    fun `the scan button is disabled outside P with the park caption`() = runTest {
        for (gear in intArrayOf(2, 3, 4)) {
            val state = openScan(gear = gear)
            assertFalse("gear $gear", state.canScan)
            assertEquals("gear $gear", DtcScanLabel.ONLY_PARK, state.scanLabel)
        }
    }

    @Test
    fun `the scan button is disabled when the gear is unknown`() = runTest {
        val state = openScan(gear = null)
        assertFalse(state.canScan)
        assertEquals(DtcScanLabel.ONLY_PARK, state.scanLabel)
    }

    @Test
    fun `the scan button is disabled when the service is not running`() = runTest {
        val state = openScan(gear = 1, running = false)
        assertFalse(state.canScan)
        assertEquals(DtcScanLabel.ONLY_PARK, state.scanLabel)
    }

    @Test
    fun `while scanning the button is disabled and says so`() = runTest {
        dtcScanState.value = DtcScanState(phase = DtcScanPhase.SCANNING, done = 4, total = 18)
        val state = openScan(gear = 1)
        assertFalse(state.canScan)
        assertEquals(DtcScanLabel.SCANNING, state.scanLabel)
    }
}
