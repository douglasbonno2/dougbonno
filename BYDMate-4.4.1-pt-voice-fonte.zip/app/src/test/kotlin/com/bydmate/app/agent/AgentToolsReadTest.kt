package com.bydmate.app.agent

import android.content.Context
import com.bydmate.app.data.automation.ActionDispatcher
import com.bydmate.app.data.automation.AutomationEngine
import com.bydmate.app.data.local.dao.ChargeDao
import com.bydmate.app.data.local.dao.ChargeSummary
import com.bydmate.app.data.local.dao.RuleDao
import com.bydmate.app.data.local.dao.TripDao
import com.bydmate.app.data.local.dao.TripSummary
import com.bydmate.app.data.local.entity.PlaceEntity
import com.bydmate.app.data.repository.PlaceRepository
import com.bydmate.app.data.remote.DynamicMetric
import com.bydmate.app.data.remote.InsightsManager
import com.bydmate.app.data.remote.OpenRouterClient
import com.bydmate.app.data.repository.SettingsRepository
import com.bydmate.app.domain.battery.BatteryState
import com.bydmate.app.domain.battery.BatteryStateRepository
import com.bydmate.app.domain.calculator.RangeCalculator
import com.bydmate.app.domain.calculator.RangeEstimate
import com.bydmate.app.data.vehicle.HelperClient
import com.bydmate.app.data.vehicle.WriteAllowlist
import com.bydmate.app.voice.VoiceGate
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentToolsReadTest {

    // snapshotAgeMs defaults to "unknown" so existing vehicle_state tests stay age-agnostic.
    private val gate = mockk<VoiceGate>().also { every { it.snapshotAgeMs() } returns null }
    private val battery = mockk<BatteryStateRepository>()
    private val range = mockk<RangeCalculator>()
    private val tripDao = mockk<TripDao>()
    private val chargeDao = mockk<ChargeDao>()
    private val dispatcher = mockk<ActionDispatcher>(relaxed = true)
    private val ruleDao = mockk<RuleDao>()
    private val engine = mockk<AutomationEngine>()
    private val places = mockk<PlaceRepository>()
    private val weather = mockk<WeatherClient>()
    private val exa = mockk<ExaSearchClient>()
    private val openRouterClient = mockk<OpenRouterClient>()
    private val settingsRepository = mockk<SettingsRepository>()
    private val contactLookup = mockk<ContactLookup>()
    private val insightsManager = mockk<InsightsManager>(relaxed = true)

    private val context = mockk<Context>(relaxed = true)

    private fun tools() = agentTools(
        gate = gate,
        batteryStateRepository = battery,
        rangeCalculator = range,
        tripDao = tripDao,
        chargeDao = chargeDao,
        actionDispatcher = dispatcher,
        ruleDao = ruleDao,
        automationEngine = engine,
        placeRepository = places,
        weatherClient = weather,
        exaSearchClient = exa,
        openRouterClient = openRouterClient,
        settingsRepository = settingsRepository,
        contactLookup = contactLookup,
        context = context,
        insightsManager = insightsManager,
    ).also { it.nowMs = { 1_000_000_000_000L } }

    @Test fun vehicle_state_null_snapshot_reports_error() = runTest {
        every { gate.vehicleSnapshot() } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("error"))
    }

    @Test fun vehicle_state_maps_fields() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(
            soc = 80, speed = 0, gear = 1, seatHeatDriver = 2, totalElec = 1234.5,
        )
        coEvery { battery.refresh() } returns
            BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimateDetailed(80, 1234.5) } returns
            RangeEstimate(rangeKm = 321.4, avgKwhPer100 = 18.0, capacityKwh = 72.9, remainingKwh = 200.0)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(80, out.getInt("soc_percent"))
        assertEquals("P", out.getString("gear"))
        assertEquals(2, out.getInt("seat_heat_driver_level"))
        assertEquals(321, out.getInt("range_km"))
        assertEquals(100.0, out.getDouble("soh_percent"), 0.01)
    }

    @Test fun vehicle_state_reports_snapshot_age_in_seconds() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 50)
        every { gate.snapshotAgeMs() } returns 7_400L
        coEvery { battery.refresh() } returns
            BatteryState(50f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimateDetailed(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(7L, out.getLong("age_s"))
    }

    @Test fun vehicle_state_omits_age_when_unknown() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 50)
        coEvery { battery.refresh() } returns
            BatteryState(50f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimateDetailed(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(!out.has("age_s"))
    }

    @Test fun vehicle_state_survives_battery_refresh_failure() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 50)
        coEvery { battery.refresh() } throws RuntimeException("daemon down")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(50, out.getInt("soc_percent"))
        assertTrue(!out.has("soh_percent"))
    }

    @Test fun vehicle_state_includes_gps_and_place_inside_radius() = runTest {
        val t = tools()
        t.locationProvider = { 55.751244 to 37.618423 }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        coEvery { places.getAllSnapshot() } returns listOf(
            PlaceEntity(name = "Дом", lat = 55.751244, lon = 37.618423, radiusM = 100),
        )
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(55.751244, out.getDouble("gps_lat"), 0.0001)
        assertEquals(37.618423, out.getDouble("gps_lon"), 0.0001)
        assertEquals("Дом", out.getString("place"))
    }

    @Test fun vehicle_state_gps_without_places_omits_place() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        coEvery { places.getAllSnapshot() } returns emptyList()
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("gps_lat"))
        assertTrue(out.has("gps_lon"))
        assertTrue(!out.has("place"))
    }

    @Test fun vehicle_state_without_gps_omits_gps_and_place() = runTest {
        val t = tools()
        t.locationProvider = { null }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(!out.has("gps_lat"))
        assertTrue(!out.has("gps_lon"))
        assertTrue(!out.has("place"))
    }

    @Test fun vehicle_state_outside_place_radius_omits_place() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        coEvery { places.getAllSnapshot() } returns listOf(
            PlaceEntity(name = "Далеко", lat = 56.0, lon = 38.0, radiusM = 50),
        )
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("gps_lat"))
        assertTrue(!out.has("place"))
    }

    @Test fun vehicle_state_survives_place_lookup_failure() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        coEvery { places.getAllSnapshot() } throws RuntimeException("db down")
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(80, out.getInt("soc_percent"))
        assertTrue(out.has("gps_lat"))
        assertTrue(out.has("gps_lon"))
        assertTrue(!out.has("place"))
    }

    // Honest sensors: absent door data must be ABSENT, not "0 doors open" — the LLM
    // reads a missing key as unknown, but a literal 0 as "all doors closed".
    @Test fun doors_open_omitted_when_all_door_sensors_unknown() = runTest {
        val t = tools()
        t.locationProvider = { null }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(!out.has("doors_open"))
    }

    @Test fun doors_open_counts_when_sensors_present() = runTest {
        val t = tools()
        t.locationProvider = { null }
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80, doorFL = 1, doorFR = 0)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(t.execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(1, out.getInt("doors_open"))
    }

    // Deterministic low-pressure flag: any wheel below TIRE_WARN_MIN_KPA (210) must
    // surface a Russian warning the model reliably voices.
    @Test fun vehicle_state_flags_low_tire_pressure() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(
            soc = 80, tirePressFL = 250, tirePressFR = 190, tirePressRL = 255, tirePressRR = 252)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("tire_pressure_warning"))
        assertEquals(190, out.getInt("tire_press_fr_kpa"))
    }

    @Test fun vehicle_state_no_tire_warning_when_normal() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(
            soc = 80, tirePressFL = 250, tirePressFR = 248, tirePressRL = 255, tirePressRR = 252)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("tire_pressure_warning"))
    }

    @Test fun vehicle_state_no_tire_warning_when_unknown() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("tire_pressure_warning"))
    }

    @Test fun vehicle_state_gun_value_1_means_not_connected() = runTest {
        // fid 876609586 returns 1 (=NONE) when no gun is plugged in, not 0.
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80, chargeGunState = 1)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.getBoolean("charging_gun_connected"))
    }

    @Test fun vehicle_state_gun_value_2_means_connected() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80, chargeGunState = 2)
        coEvery { battery.refresh() } throws RuntimeException("n/a")
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.getBoolean("charging_gun_connected"))
    }

    // (д) get_weather without GPS and without city -> error-JSON, no HTTP call.
    @Test fun get_weather_without_gps_and_city_reports_error() = runTest {
        val t = tools()
        t.locationProvider = { null }
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", "{}")))
        assertEquals("нет GPS и не указан город", out.getString("error"))
        coVerify(exactly = 0) { weather.forecast(any(), any()) }
        coVerify(exactly = 0) { weather.geocode(any()) }
    }

    @Test fun get_weather_uses_gps_when_no_city_given() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.forecast(55.0, 37.0) } returns Result.success("""{"now":{}}""")
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", "{}")))
        assertTrue(out.has("now"))
    }

    @Test fun get_weather_geocodes_explicit_city() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.geocode("Сочи") } returns Result.success(WeatherClient.GeoPoint(43.6, 39.7, "Сочи"))
        coEvery { weather.forecast(43.6, 39.7) } returns Result.success("""{"now":{}}""")
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", """{"city":"Сочи"}""")))
        assertTrue(out.has("now"))
    }

    // (a) City path names the place from the geocoder result.
    @Test fun get_weather_city_path_reports_geocoded_name() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.geocode("Краснодар") } returns
            Result.success(WeatherClient.GeoPoint(45.035, 38.975, "Краснодар"))
        coEvery { weather.forecast(45.035, 38.975) } returns Result.success("""{"now":{}}""")
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", """{"city":"Краснодар"}""")))
        assertEquals("Краснодар", out.getString("location"))
    }

    // (b) GPS path inside a saved place names that place.
    @Test fun get_weather_gps_path_names_saved_place() = runTest {
        val t = tools()
        t.locationProvider = { 55.751244 to 37.618423 }
        coEvery { weather.forecast(55.751244, 37.618423) } returns Result.success("""{"now":{}}""")
        coEvery { places.getAllSnapshot() } returns listOf(
            PlaceEntity(name = "Дом", lat = 55.751244, lon = 37.618423, radiusM = 100),
        )
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", "{}")))
        assertEquals("Дом", out.getString("location"))
    }

    // (c) GPS path outside any saved place omits the location key entirely.
    @Test fun get_weather_gps_path_without_place_omits_location() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.forecast(55.0, 37.0) } returns Result.success("""{"now":{}}""")
        coEvery { places.getAllSnapshot() } returns emptyList()
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", "{}")))
        assertTrue(!out.has("location"))
    }

    // Pin: raw English exception messages ("timeout") must never leak into the error JSON.
    @Test fun get_weather_forecast_failure_reports_russian_error() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.forecast(55.0, 37.0) } returns Result.failure(RuntimeException("timeout"))
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", "{}")))
        assertEquals("погода недоступна", out.getString("error"))
    }

    // Pin: WeatherClient.UserError is the one failure whose Russian message passes through.
    @Test fun get_weather_city_not_found_passes_russian_message_through() = runTest {
        val t = tools()
        t.locationProvider = { 55.0 to 37.0 }
        coEvery { weather.geocode("Хзгородск") } returns
            Result.failure(WeatherClient.UserError("город не найден"))
        val out = JSONObject(t.execute(AgentToolCall("1", "get_weather", """{"city":"Хзгородск"}""")))
        assertEquals("город не найден", out.getString("error"))
    }

    @Test fun query_trips_computes_avg_consumption() = runTest {
        coEvery { tripDao.getPeriodSummary(any(), any()) } returns
            TripSummary(totalKm = 100.0, totalKwh = 18.0, tripCount = 3, totalCost = 90.0)
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "query_trips", """{"period":"week"}""")))
        assertEquals(3, out.getInt("trips"))
        assertEquals(18.0, out.getDouble("avg_kwh_per_100km"), 0.01)
    }

    @Test fun query_trips_bad_period_reports_error() = runTest {
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "query_trips", """{"period":"year"}""")))
        assertEquals("укажи period (day/week/month) или даты from и to в формате ГГГГ-ММ-ДД", out.getString("error"))
    }

    @Test fun query_charges_includes_ac_dc_split() = runTest {
        coEvery { chargeDao.getPeriodSummary(any(), any()) } returns
            ChargeSummary(sessionCount = 2, totalKwh = 40.0, totalCost = 200.0)
        coEvery { chargeDao.getCompletedSince(any()) } returns emptyList()
        val out = JSONObject(tools().execute(
            AgentToolCall("1", "query_charges", """{"period":"month"}""")))
        assertEquals(2, out.getInt("sessions"))
        assertEquals(0.0, out.getDouble("ac_kwh"), 0.01)
    }

    @Test fun unknown_tool_reports_error() = runTest {
        val out = JSONObject(tools().execute(AgentToolCall("1", "nope", "{}")))
        assertEquals("неизвестный инструмент nope", out.getString("error"))
    }

    // Pin: malformed tool-call JSON must report a fixed Russian error, never leak the
    // raw parser exception (which would be English).
    @Test fun malformed_arguments_json_reports_russian_error() = runTest {
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{not json")))
        assertEquals("некорректные аргументы", out.getString("error"))
    }

    @Test fun vehicle_state_maps_cabin_sensors() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot().copy(
            seatbeltFL = 1, seatbeltFR = 0,
            occupancyFL = 2, occupancyFR = 1,
            occupancyRL = 1, occupancyRM = 1, occupancyRR = 2,
            lightLevel = 2, keyBatteryStatus = 0, rain = 1,
        )
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.getBoolean("seatbelt_driver_fastened"))
        assertFalse(out.getBoolean("seatbelt_front_passenger_fastened"))
        assertTrue(out.getBoolean("seat_occupied_driver"))
        assertFalse(out.getBoolean("seat_occupied_front_passenger"))
        assertTrue(out.getBoolean("seat_occupied_rear_right"))
        assertEquals(2, out.getInt("ambient_light_level_1dark_5bright"))
        assertTrue(out.getBoolean("key_fob_battery_ok"))
        assertTrue(out.getBoolean("rain_detected"))
        // Passenger seat is free -> its unbuckled belt must NOT raise the warning.
        assertFalse(out.has("seatbelt_warning"))
    }

    @Test fun vehicle_state_absent_sensors_omit_keys() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 50)
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("seatbelt_front_passenger_fastened"))
        assertFalse(out.has("seat_occupied_front_passenger"))
        assertFalse(out.has("ambient_light_level_1dark_5bright"))
        assertFalse(out.has("key_fob_battery_ok"))
        assertFalse(out.has("rain_detected"))
        assertFalse(out.has("seatbelt_warning"))
    }

    @Test fun vehicle_state_warns_on_unbuckled_passenger_while_moving() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(speed = 40).copy(
            seatbeltFL = 1, seatbeltFR = 0, occupancyFR = 2,
        )
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("seatbelt_warning"))
    }

    @Test fun vehicle_state_warns_on_unbuckled_driver_while_moving() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(speed = 40).copy(seatbeltFL = 0)
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertTrue(out.has("seatbelt_warning"))
    }

    @Test fun vehicle_state_no_seatbelt_warning_when_parked() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(speed = 0).copy(
            seatbeltFL = 0, seatbeltFR = 0, occupancyFR = 2,
        )
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, null, null, autoserviceAvailable = true)
        coEvery { range.estimate(any(), any()) } returns null
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("seatbelt_warning"))
    }

    @Test fun `cell voltages projected with delta in millivolts`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(minCellVoltage = 3.212, maxCellVoltage = 3.245)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(3.212, out.getDouble("cell_voltage_min_v"), 0.0001)
        assertEquals(3.245, out.getDouble("cell_voltage_max_v"), 0.0001)
        assertEquals(33, out.getInt("cell_voltage_delta_mv"))
    }

    @Test fun `cell delta omitted when one side missing`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(maxCellVoltage = 3.245)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("cell_voltage_delta_mv"))
        assertFalse(out.has("cell_voltage_min_v"))
    }

    @Test fun `work mode mapped to a label, power state not reported`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(powerState = 2, workMode = 1)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertFalse(out.has("power_state"))
        assertEquals("EV", out.getString("work_mode"))
    }

    @Test fun `drive mode 4 is snow`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot().copy(driveMode = 4)
        assertEquals("SNOW", JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}"))).getString("drive_mode"))
    }

    @Test fun `drive mode reports sand from the target fid, not the stale dev 1006 mapping`() = runTest {
        // dev=1006 (driveMode) never leaves NORMAL for sand -- the real mode comes from the target fid.
        every { gate.vehicleSnapshot() } returns snapshot().copy(driveMode = 3)
        val helper = mockk<HelperClient>()
        coEvery { helper.read(WriteAllowlist.DRIVE_MODE_DEV, WriteAllowlist.DRIVE_MODE_TARGET_FID, any()) } returns 5L
        val out = JSONObject(
            tools().also { it.injectHelperClient(helper) }.execute(AgentToolCall("1", "get_vehicle_state", "{}")),
        )
        assertEquals("SAND", out.getString("drive_mode"))
    }

    @Test fun `drive mode falls back to the dev 1006 mapping when the target read fails`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot().copy(driveMode = 4)
        val helper = mockk<HelperClient>()
        coEvery { helper.read(WriteAllowlist.DRIVE_MODE_DEV, WriteAllowlist.DRIVE_MODE_TARGET_FID, any()) } throws RuntimeException("daemon down")
        val out = JSONObject(
            tools().also { it.injectHelperClient(helper) }.execute(AgentToolCall("1", "get_vehicle_state", "{}")),
        )
        assertEquals("SNOW", out.getString("drive_mode"))
    }

    @Test fun `drl 1 is on 2 is off 0 omitted`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(drl = 1)
        assertTrue(JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}"))).getBoolean("light_drl_on"))
        every { gate.vehicleSnapshot() } returns snapshot(drl = 2)
        assertFalse(JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}"))).getBoolean("light_drl_on"))
        every { gate.vehicleSnapshot() } returns snapshot(drl = 0)
        assertFalse(JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}"))).has("light_drl_on"))
    }

    @Test fun `battery temp min max projected`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(maxBatTemp = 31, minBatTemp = 27)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(31, out.getInt("battery_temp_max_c"))
        assertEquals(27, out.getInt("battery_temp_min_c"))
    }

    @Test fun `lifetime km and kwh from battery state`() = runTest {
        every { gate.vehicleSnapshot() } returns snapshot(soc = 80)
        coEvery { battery.refresh() } returns BatteryState(80f, 100f, 24513.5f, 4321.25f, autoserviceAvailable = true)
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_vehicle_state", "{}")))
        assertEquals(24513.5, out.getDouble("lifetime_km"), 0.01)
        assertEquals(4321.25, out.getDouble("lifetime_kwh"), 0.01)
    }

    @Test fun stats_summary_week_serializes_metrics() = runTest {
        coEvery { insightsManager.dynamicsFor(7) } returns listOf(
            DynamicMetric(label = "Расход", current = "18.2 кВтч/100", previous = "19.0",
                changePct = -4.2, sentiment = "good", section = null, kind = "consumption"))
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_stats_summary", "{}")))
        val arr = out.getJSONArray("metrics")
        assertEquals(1, arr.length())
        assertEquals("Расход", arr.getJSONObject(0).getString("label"))
        assertEquals("18.2 кВтч/100", arr.getJSONObject(0).getString("current"))
        assertEquals(-4.2, arr.getJSONObject(0).getDouble("change_pct"), 0.01)
    }

    @Test fun stats_summary_month_uses_30_days() = runTest {
        coEvery { insightsManager.dynamicsFor(30) } returns emptyList()
        val out = JSONObject(tools().execute(AgentToolCall("1", "get_stats_summary", """{"period":"month"}""")))
        assertTrue(out.has("error"))   // empty -> honest "no data" error
        coVerify { insightsManager.dynamicsFor(30) }
    }

    companion object {
        /** Minimal DiParsData with every field null except the named overrides. */
        internal fun snapshot(
            soc: Int? = null, speed: Int? = null, gear: Int? = null,
            seatHeatDriver: Int? = null, totalElec: Double? = null,
            doorFL: Int? = null, doorFR: Int? = null,
            tirePressFL: Int? = null, tirePressFR: Int? = null,
            tirePressRL: Int? = null, tirePressRR: Int? = null,
            chargeGunState: Int? = null,
            minCellVoltage: Double? = null, maxCellVoltage: Double? = null,
            powerState: Int? = null, drl: Int? = null,
            maxBatTemp: Int? = null, minBatTemp: Int? = null,
            workMode: Int? = null,
        ) = com.bydmate.app.data.remote.DiParsData(
            soc = soc, speed = speed, mileage = null, power = null, chargeGunState = chargeGunState,
            maxBatTemp = maxBatTemp, avgBatTemp = null, minBatTemp = minBatTemp, chargingStatus = null,
            batteryCapacityKwh = null, totalElecConsumption = totalElec, voltage12v = null,
            maxCellVoltage = maxCellVoltage, minCellVoltage = minCellVoltage, exteriorTemp = null,
            gear = gear, powerState = powerState, insideTemp = null, acStatus = null, acTemp = null,
            fanLevel = null, acCirc = null, doorFL = doorFL, doorFR = doorFR, doorRL = null,
            doorRR = null, windowFL = null, windowFR = null, windowRL = null, windowRR = null,
            sunroof = null, trunk = null, hood = null, seatbeltFL = null, lockFL = null,
            tirePressFL = tirePressFL, tirePressFR = tirePressFR,
            tirePressRL = tirePressRL, tirePressRR = tirePressRR,
            driveMode = null, workMode = workMode, autoPark = null, rain = null,
            lightLow = null, drl = drl, seatHeatDriver = seatHeatDriver,
        )
    }
}
